-- YİĞİT OS · initial schema
-- Run in the Supabase SQL editor, or with `supabase db push`.
-- Every table is owned by a user and protected by row-level security.

create extension if not exists "pgcrypto";

-- ───────────────────────── users (profile) ─────────────────────────
create table public.users (
  id uuid primary key references auth.users (id) on delete cascade,
  name text not null default '',
  afs_date date,
  weekly_italian_goal_min integer not null default 360,
  italian_level text not null default 'A1' check (italian_level in ('A0','A1','A1+','A2','A2+','B1')),
  italian_vocab integer not null default 0,
  italian_skills jsonb not null default '{"listening":0,"speaking":0,"reading":0,"writing":0}',
  google_calendar_id text,
  google_last_sync_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.users (id, name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ───────────────────────── shared types ─────────────────────────
create type public.task_category as enum
  ('class','school','exam','italian','research','itu','planning','event','personal');
create type public.topic_status as enum ('not_started','in_progress','completed');

-- ───────────────────────── weekly template ─────────────────────────
create table public.template_blocks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6), -- 0 = Monday
  title text not null,
  category public.task_category not null,
  start_time time not null,
  end_time time not null check (end_time > start_time),
  notes text,
  created_at timestamptz not null default now()
);

-- ───────────────────────── tasks ─────────────────────────
create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  title text not null,
  category public.task_category not null,
  date date not null,
  start_time time not null,
  end_time time not null check (end_time > start_time),
  notes text,
  done boolean not null default false,
  done_at timestamptz,
  template_block_id uuid references public.template_blocks (id) on delete set null,
  calendar_event_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index tasks_user_date on public.tasks (user_id, date);

-- ───────────────────────── calendar_events (external mirror) ─────────────────────────
create table public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  provider text not null default 'google' check (provider in ('google')),
  calendar_id text not null default 'primary',
  external_id text not null,
  etag text,
  title text not null,
  description text,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  all_day boolean not null default false,
  task_id uuid references public.tasks (id) on delete set null,
  remote_updated_at timestamptz not null,
  synced_at timestamptz not null default now(),
  deleted boolean not null default false,
  unique (user_id, provider, calendar_id, external_id)
);
alter table public.tasks
  add constraint tasks_calendar_event_fk foreign key (calendar_event_id)
  references public.calendar_events (id) on delete set null;

-- ───────────────────────── focus_sessions ─────────────────────────
create table public.focus_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  category public.task_category not null,
  label text not null,
  task_id uuid references public.tasks (id) on delete set null,
  started_at timestamptz not null,
  ended_at timestamptz not null,
  minutes integer not null check (minutes > 0),
  planned_minutes integer not null check (planned_minutes > 0)
);
create index focus_sessions_user_time on public.focus_sessions (user_id, started_at);

-- ───────────────────────── italian ─────────────────────────
create table public.italian_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  date date not null,
  kind text not null check (kind in ('grammar','vocabulary','listening','speaking','reading','writing','test')),
  minutes integer not null default 0,
  words_learned integer not null default 0,
  test_label text,
  test_score numeric,
  test_max numeric,
  notes text,
  focus_session_id uuid references public.focus_sessions (id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.italian_topics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  title text not null,
  kind text not null default 'grammar' check (kind in ('grammar','vocabulary','skill')),
  status public.topic_status not null default 'not_started',
  updated_at timestamptz not null default now()
);

-- ───────────────────────── school catch-up ─────────────────────────
create table public.school_topics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  subject text not null check (subject in (
    'Mathematics','Physics','Chemistry','Biology','Italian Literature',
    'Italian Language','Latin','Philosophy','History')),
  title text not null,
  status public.topic_status not null default 'not_started',
  updated_at timestamptz not null default now()
);

create table public.school_progress_snapshots (
  user_id uuid not null references public.users (id) on delete cascade,
  date date not null,
  percent smallint not null check (percent between 0 and 100),
  primary key (user_id, date)
);

-- ───────────────────────── research ─────────────────────────
create table public.research_sprints (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  week integer not null,
  start_date date not null,
  objective text not null default '',
  experiments text not null default '',
  code text not null default '',
  results text not null default '',
  notes text not null default '',
  github_url text not null default '',
  next_step text not null default '',
  status text not null default 'active' check (status in ('active','completed')),
  completed_at timestamptz,
  unique (user_id, week)
);

create table public.research_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  sprint_id uuid not null references public.research_sprints (id) on delete cascade,
  title text not null,
  done boolean not null default false,
  position integer not null default 0
);

-- ───────────────────────── internship ─────────────────────────
create table public.internship_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  title text not null,
  done boolean not null default false,
  due_date date,
  created_at timestamptz not null default now()
);

create table public.internship_attendance (
  user_id uuid not null references public.users (id) on delete cascade,
  date date not null,
  primary key (user_id, date)
);

create table public.internship_people (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  name text not null,
  role text not null default '',
  note text not null default ''
);

create table public.internship_learnings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  date date not null default current_date,
  text text not null
);

-- ───────────────────────── AFS ─────────────────────────
create table public.afs_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  "group" text not null check ("group" in ('documents','preparation')),
  title text not null,
  done boolean not null default false
);

-- ───────────────────────── weekly reviews ─────────────────────────
create table public.weekly_reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  week_start date not null,
  italian_min integer not null default 0,
  school_min integer not null default 0,
  research_min integer not null default 0,
  internship_min integer not null default 0,
  tasks_completed integer not null default 0,
  focus_sessions integer not null default 0,
  school_progress smallint,
  wins text not null default '',
  blockers text not null default '',
  next_week_focus text not null default '',
  created_at timestamptz not null default now(),
  unique (user_id, week_start)
);

-- ───────────────────────── updated_at trigger ─────────────────────────
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create trigger users_touch before update on public.users for each row execute function public.touch_updated_at();
create trigger tasks_touch before update on public.tasks for each row execute function public.touch_updated_at();
create trigger italian_topics_touch before update on public.italian_topics for each row execute function public.touch_updated_at();
create trigger school_topics_touch before update on public.school_topics for each row execute function public.touch_updated_at();

-- ───────────────────────── row level security ─────────────────────────
alter table public.users enable row level security;
create policy "own profile" on public.users for all using (auth.uid() = id) with check (auth.uid() = id);

do $$
declare t text;
begin
  foreach t in array array[
    'template_blocks','tasks','calendar_events','focus_sessions','italian_sessions','italian_topics',
    'school_topics','school_progress_snapshots','research_sprints','research_tasks','internship_tasks',
    'internship_attendance','internship_people','internship_learnings','afs_items','weekly_reviews'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format(
      'create policy "own rows" on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
  end loop;
end $$;
