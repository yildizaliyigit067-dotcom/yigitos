# YİĞİT OS

Personal operating system for school, Italian, research at İTÜ, the İTÜ Çekirdek internship and AFS preparation.

Next.js 14 · TypeScript · Tailwind CSS · Framer Motion · Recharts · Lucide · Zustand · Supabase (optional)

## What works today

- **Overview** – greeting, live clock, today’s plan, next task, weekly Italian time, school catch-up, research sprint, AFS countdown and readiness.
- **Today** – chronological timeline; tick blocks off, start focus from any block, move between days.
- **Planner** – Monday–Sunday grid built from your base program. Drag blocks to another time or day (mouse and touch). Click empty space to add.
- **Italian** – Oct → Jan roadmap, weekly time ring, streak, level, vocabulary, skills, grammar topics, test score chart, today’s Italian.
- **Classroom** – assignments from your school Google Classroom with due dates, status and grades; plan a study block for any of them.
- **School** – nine subjects, every topic Not started / In progress / Completed, progress over time.
- **Research** – weekly sprints with objective, tasks, experiments, code, results, notes, GitHub link, next step, streak and the completion animation.
- **İTÜ Çekirdek** – attendance heatmap, tasks, people, learnings, notes, upcoming İTÜ work from the planner.
- **Focus** – full-screen timer, 20/30/45/60/90 min, pause, survives refresh and phone lock, logs into stats.
- **Analytics** – hours by area per day or per 8 weeks, deltas vs last week, monthly summary sentence.
- **⌘K / Ctrl+K** – command palette: `add physics exam`, `start italian 30`, `open research`.
- **Settings** – edit the weekly base program, AFS date and checklist, Italian goal, backup export/import, Google Calendar.
- **PWA** – installable on iPhone/iPad, works offline.

Data is stored in the browser (localStorage). Use *Settings → Export backup* now and then.

## Run locally

```bash
npm install
npm run dev
# open http://localhost:3000
```

## Put it on GitHub

```bash
git remote add origin https://github.com/<your-username>/yigit-os.git
git push -u origin main
```

(The project already contains an initial commit.)

## Deploy on Vercel

1. vercel.com → *Add New → Project* → import the `yigit-os` repository.
2. Framework is detected as Next.js. Click **Deploy**.
3. Every `git push` deploys again automatically.

## Install on iPhone

Open your Vercel URL in **Safari** → Share → **Add to Home Screen**. It opens full-screen like a native app.

## Google Classroom

Assignments, due dates, submission state and grades from your school account show up on the **Classroom** page, on Overview (due soon), on Today (due that day) and as “N due” markers in the Planner. Each assignment can be turned into a study block with one click; finishing that block ticks the assignment off in YİĞİT OS. Access is read-only: nothing is ever turned in or changed on Classroom.

Setup (once, about 10 minutes):

1. https://console.cloud.google.com → create a project (e.g. `yigit-os`).
2. *APIs & Services → Library* → enable **Google Classroom API**.
3. *OAuth consent screen* → User type **External** → app name YİĞİT OS → add scopes `classroom.courses.readonly` and `classroom.coursework.me.readonly` → keep the app in **Testing** and add your school email under **Test users**.
4. *Credentials → Create credentials → OAuth client ID* → **Web application**. Authorized JavaScript origins: `https://<your-app>.vercel.app` and `http://localhost:3000`. No redirect URI needed.
5. Copy the Client ID. In Vercel → *Settings → Environment Variables* add `NEXT_PUBLIC_GOOGLE_CLIENT_ID`, then redeploy (locally: put it in `.env.local`).
6. Open *Classroom* → **Connect Google Classroom** → pick your school account.

Google hands out one-hour tokens, so the app re-syncs automatically while that session is valid (every 15 minutes and when you reopen it). After that, one tap on **Sync** (or ⌘K → “Sync Google Classroom”) refreshes it.

**If your school blocks it:** Google Workspace for Education stops student accounts (especially under 18) from using outside apps unless the admin allows them. The Classroom page detects this and gives you a ready-to-send message for your school’s IT team with your Client ID. They allow it under *Admin console → Security → API controls → App access control*.

Code: `src/lib/classroom/` (`api.ts` Google Identity Services + REST, `sync.ts`, `helpers.ts`), `src/app/classroom/page.tsx`, `src/components/assignments.tsx`.

## Optional: Supabase + Google Calendar

1. Create a project at supabase.com.
2. SQL editor → run `supabase/migrations/0001_init.sql` (all tables with row-level security).
3. Authentication → Providers → Google: enable it with a Google Cloud OAuth client. In Google Cloud, enable the *Google Calendar API* and add the `https://www.googleapis.com/auth/calendar` scope.
4. In Vercel → Settings → Environment Variables add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`, then redeploy.
5. Settings → *Connect Google Calendar* → *Import next 3 weeks*.

Calendar code lives in `src/lib/calendar/`:
- `types.ts` – provider-agnostic `CalendarProvider` interface
- `google.ts` – Google Calendar REST implementation (list / create / update / delete)
- `sync.ts` – `planSync()` two-way reconciliation (last write wins) and `executePush()`

Import from Google is wired into the UI. Pushing local changes back to Google and moving the app’s storage from localStorage to the Supabase tables are the next steps; the schema and sync planner are ready for both.

## Structure

```
src/
  app/            pages (overview, today, planner, italian, school, research, itu, analytics, focus, settings)
  components/     shell, sidebar, mobile nav, command palette, focus overlay, timeline, UI primitives
  lib/
    store.ts      all data + actions (persisted)
    stats.ts      time logging, streaks, progress
    seed.ts       base weekly program, school topics, roadmap
    calendar/     Google Calendar provider + sync
    supabase/     client + auth helpers
supabase/migrations/0001_init.sql
```

## How time is counted

A finished focus session counts with its real length. A block you tick off without a focus session counts with its planned length. *Class* (school hours) and *Event* are not counted as study time.
