import type { Category } from '../types';

/** Provider-agnostic calendar event. Google, Apple, Outlook all map onto this. */
export interface ExternalEvent {
  externalId: string;
  title: string;
  description?: string;
  /** ISO date-time */
  start: string;
  end: string;
  allDay: boolean;
  updatedAt: string;
  etag?: string;
  /** Category we wrote into the event’s private extended properties, if any. */
  category?: Category;
  /** Local task id this event mirrors, if it was created from YİĞİT OS. */
  localId?: string;
}

export interface CalendarProvider {
  readonly id: 'google';
  listEvents(timeMin: Date, timeMax: Date): Promise<ExternalEvent[]>;
  createEvent(e: Omit<ExternalEvent, 'externalId' | 'updatedAt' | 'etag'>): Promise<ExternalEvent>;
  updateEvent(externalId: string, e: Partial<ExternalEvent>): Promise<ExternalEvent>;
  deleteEvent(externalId: string): Promise<void>;
}
