import { format } from 'date-fns';
import type { Task } from '../types';
import type { TaskInput } from '../store';
import type { CalendarProvider, ExternalEvent } from './types';

/** External event → local task input (timed events only; all-day events are skipped). */
export function eventToTask(e: ExternalEvent): TaskInput | null {
  if (e.allDay) return null;
  const s = new Date(e.start);
  const en = new Date(e.end);
  return {
    title: e.title,
    notes: e.description,
    category: e.category ?? 'event',
    date: format(s, 'yyyy-MM-dd'),
    start: format(s, 'HH:mm'),
    end: format(en, 'HH:mm'),
    externalId: e.externalId,
    source: 'google',
  };
}

export function taskToEvent(t: Task): Omit<ExternalEvent, 'externalId' | 'updatedAt' | 'etag'> {
  return {
    title: t.title,
    description: t.notes,
    start: new Date(`${t.date}T${t.start}:00`).toISOString(),
    end: new Date(`${t.date}T${t.end}:00`).toISOString(),
    allDay: false,
    category: t.category,
    localId: t.id,
  };
}

export interface SyncPlan {
  pullCreate: ExternalEvent[];
  pullUpdate: { task: Task; event: ExternalEvent }[];
  pushCreate: Task[];
  pushUpdate: { task: Task; event: ExternalEvent }[];
}

/**
 * Two-way reconciliation, last-write-wins on `updatedAt`.
 * `lastSyncAt` stops tasks that were pushed before from being pushed again.
 */
export function planSync(tasks: Task[], events: ExternalEvent[], lastSyncAt: string | null): SyncPlan {
  const byExternal = new Map(tasks.filter((t) => t.externalId).map((t) => [t.externalId!, t]));
  const plan: SyncPlan = { pullCreate: [], pullUpdate: [], pushCreate: [], pushUpdate: [] };

  for (const e of events) {
    const t = byExternal.get(e.externalId) ?? tasks.find((x) => x.id === e.localId);
    if (!t) plan.pullCreate.push(e);
    else if (e.updatedAt > t.updatedAt) plan.pullUpdate.push({ task: t, event: e });
    else if (t.updatedAt > e.updatedAt && (!lastSyncAt || t.updatedAt > lastSyncAt)) plan.pushUpdate.push({ task: t, event: e });
  }
  for (const t of tasks) {
    if (!t.externalId && t.category !== 'class' && (!lastSyncAt || t.updatedAt > lastSyncAt)) plan.pushCreate.push(t);
  }
  return plan;
}

export async function executePush(provider: CalendarProvider, plan: SyncPlan) {
  const created: { taskId: string; externalId: string }[] = [];
  for (const t of plan.pushCreate) {
    const e = await provider.createEvent(taskToEvent(t));
    created.push({ taskId: t.id, externalId: e.externalId });
  }
  for (const { task, event } of plan.pushUpdate) await provider.updateEvent(event.externalId, taskToEvent(task));
  return created;
}
