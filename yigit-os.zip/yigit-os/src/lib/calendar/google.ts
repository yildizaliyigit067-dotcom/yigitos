import type { Category } from '../types';
import type { CalendarProvider, ExternalEvent } from './types';

const API = 'https://www.googleapis.com/calendar/v3/calendars';

interface GoogleEvent {
  id: string;
  etag?: string;
  summary?: string;
  description?: string;
  status?: string;
  updated: string;
  start: { dateTime?: string; date?: string };
  end: { dateTime?: string; date?: string };
  extendedProperties?: { private?: Record<string, string> };
}

const fromGoogle = (g: GoogleEvent): ExternalEvent => ({
  externalId: g.id,
  etag: g.etag,
  title: g.summary ?? '(No title)',
  description: g.description,
  start: g.start.dateTime ?? `${g.start.date}T00:00:00`,
  end: g.end.dateTime ?? `${g.end.date}T00:00:00`,
  allDay: !g.start.dateTime,
  updatedAt: g.updated,
  category: g.extendedProperties?.private?.yigitCategory as Category | undefined,
  localId: g.extendedProperties?.private?.yigitId,
});

const toGoogle = (e: Partial<ExternalEvent>) => {
  const body: Record<string, unknown> = {};
  if (e.title !== undefined) body.summary = e.title;
  if (e.description !== undefined) body.description = e.description;
  if (e.start) body.start = { dateTime: new Date(e.start).toISOString() };
  if (e.end) body.end = { dateTime: new Date(e.end).toISOString() };
  const priv: Record<string, string> = {};
  if (e.category) priv.yigitCategory = e.category;
  if (e.localId) priv.yigitId = e.localId;
  if (Object.keys(priv).length) body.extendedProperties = { private: priv };
  return body;
};

export class GoogleCalendarProvider implements CalendarProvider {
  readonly id = 'google' as const;
  constructor(
    private accessToken: string,
    private calendarId = 'primary',
  ) {}

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const res = await fetch(`${API}/${encodeURIComponent(this.calendarId)}${path}`, {
      ...init,
      headers: { Authorization: `Bearer ${this.accessToken}`, 'Content-Type': 'application/json', ...init?.headers },
    });
    if (res.status === 401) throw new Error('Google session expired. Connect Google Calendar again.');
    if (!res.ok) throw new Error(`Google Calendar request failed (${res.status}).`);
    return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
  }

  async listEvents(timeMin: Date, timeMax: Date) {
    const out: ExternalEvent[] = [];
    let pageToken: string | undefined;
    do {
      const q = new URLSearchParams({
        timeMin: timeMin.toISOString(),
        timeMax: timeMax.toISOString(),
        singleEvents: 'true',
        orderBy: 'startTime',
        maxResults: '250',
      });
      if (pageToken) q.set('pageToken', pageToken);
      const data = await this.request<{ items: GoogleEvent[]; nextPageToken?: string }>(`/events?${q}`);
      out.push(...data.items.filter((g) => g.status !== 'cancelled').map(fromGoogle));
      pageToken = data.nextPageToken;
    } while (pageToken);
    return out;
  }

  async createEvent(e: Omit<ExternalEvent, 'externalId' | 'updatedAt' | 'etag'>) {
    return fromGoogle(await this.request<GoogleEvent>('/events', { method: 'POST', body: JSON.stringify(toGoogle(e)) }));
  }

  async updateEvent(externalId: string, e: Partial<ExternalEvent>) {
    return fromGoogle(
      await this.request<GoogleEvent>(`/events/${encodeURIComponent(externalId)}`, {
        method: 'PATCH',
        body: JSON.stringify(toGoogle(e)),
      }),
    );
  }

  async deleteEvent(externalId: string) {
    await this.request<void>(`/events/${encodeURIComponent(externalId)}`, { method: 'DELETE' });
  }
}
