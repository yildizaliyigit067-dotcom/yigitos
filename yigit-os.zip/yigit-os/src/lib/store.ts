'use client';

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { addDays } from 'date-fns';
import type {
  ActiveFocus,
  AfsItem,
  Category,
  FocusSession,
  ItalianSkills,
  ItalianState,
  ItalianTest,
  ItuState,
  Person,
  ResearchSprint,
  SchoolTopic,
  Settings,
  Subject,
  Task,
  TemplateBlock,
  TopicStatus,
  ItalianTopic,
  ClassroomAssignment,
  ClassroomState,
} from './types';
import { uid } from './utils';
import { dayKey, duration, fromMin, parseDay, toMin, todayKey, weekdayIndex } from './date';
import { TEMPLATE, seedAfs, seedItalianTopics, seedSchoolTopics, seedSprint } from './seed';
import { schoolProgress } from './stats';

const nowIso = () => new Date().toISOString();

const NEXT_STATUS: Record<TopicStatus, TopicStatus> = {
  not_started: 'in_progress',
  in_progress: 'completed',
  completed: 'not_started',
};

export const focusElapsed = (a: ActiveFocus, now: number) => (a.pausedAt ?? now) - a.startedAt - a.pausedMs;

function initialData() {
  const schoolTopics = seedSchoolTopics();
  return {
    settings: {
      name: 'Ali Yiğit',
      afsDate: '2027-01-31',
      weeklyItalianGoalMin: 360,
      startDate: todayKey(),
    } as Settings,
    template: TEMPLATE as TemplateBlock[],
    tasks: [] as Task[],
    materialized: {} as Record<string, true>,
    focusSessions: [] as FocusSession[],
    activeFocus: null as ActiveFocus | null,
    schoolTopics,
    schoolHistory: { [todayKey()]: Math.round(schoolProgress(schoolTopics)) } as Record<string, number>,
    italian: {
      level: 'A1',
      vocab: 0,
      skills: { listening: 10, speaking: 10, reading: 15, writing: 10 },
      tests: [],
    } as ItalianState,
    italianTopics: seedItalianTopics(),
    sprints: [seedSprint()] as ResearchSprint[],
    itu: { attendance: [], tasks: [], people: [], notes: '', learnings: [] } as ItuState,
    afs: seedAfs(),
    classroom: {
      connected: false,
      email: null,
      lastSyncAt: null,
      assignments: [],
      courseSubjects: {},
      hiddenCourses: [],
    } as ClassroomState,
    sidebarCollapsed: false,
  };
}

export type Data = ReturnType<typeof initialData>;
const DATA_KEYS = Object.keys(initialData()) as (keyof Data)[];

export type TaskInput = Pick<Task, 'title' | 'category' | 'date' | 'start' | 'end'> & Partial<Pick<Task, 'notes' | 'done' | 'source' | 'externalId' | 'assignmentId'>>;

interface Actions {
  materialize: (keys: string[]) => void;
  addTask: (t: TaskInput) => string;
  updateTask: (id: string, patch: Partial<Task>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  moveTask: (id: string, dayDelta: number, minuteDelta: number) => void;
  mergeExternal: (tasks: TaskInput[]) => number;

  startFocus: (o: { category: Category; label: string; minutes: number; taskId?: string }) => void;
  pauseFocus: () => void;
  resumeFocus: () => void;
  completeFocus: (markTaskDone: boolean) => FocusSession | null;
  cancelFocus: () => void;
  deleteSession: (id: string) => void;

  addSchoolTopic: (subject: Subject, title: string) => void;
  cycleSchoolTopic: (id: string) => void;
  setSchoolStatus: (id: string, status: TopicStatus) => void;
  deleteSchoolTopic: (id: string) => void;

  setItalianLevel: (level: ItalianState['level']) => void;
  addVocab: (n: number) => void;
  setVocab: (n: number) => void;
  setSkill: (k: keyof ItalianSkills, v: number) => void;
  addTest: (t: Omit<ItalianTest, 'id'>) => void;
  deleteTest: (id: string) => void;
  addItalianTopic: (title: string) => void;
  cycleItalianTopic: (id: string) => void;
  deleteItalianTopic: (id: string) => void;

  updateSprint: (id: string, patch: Partial<ResearchSprint>) => void;
  addSprintTask: (id: string, title: string) => void;
  toggleSprintTask: (id: string, taskId: string) => void;
  deleteSprintTask: (id: string, taskId: string) => void;
  completeSprint: (id: string) => void;
  reopenSprint: (id: string) => void;
  startNextSprint: () => string;

  toggleAttendance: (date: string) => void;
  addItuTask: (title: string) => void;
  toggleItuTask: (id: string) => void;
  deleteItuTask: (id: string) => void;
  addPerson: (p: Omit<Person, 'id'>) => void;
  deletePerson: (id: string) => void;
  setItuNotes: (notes: string) => void;
  addLearning: (text: string) => void;
  deleteLearning: (id: string) => void;

  toggleAfs: (id: string) => void;
  addAfs: (group: AfsItem['group'], title: string) => void;
  deleteAfs: (id: string) => void;

  updateSettings: (patch: Partial<Settings>) => void;
  addTemplateBlock: (b: Omit<TemplateBlock, 'id'>) => void;
  updateTemplateBlock: (id: string, patch: Partial<TemplateBlock>) => void;
  deleteTemplateBlock: (id: string) => void;
  applyTemplateFromToday: () => void;

  applyClassroomSync: (assignments: Omit<ClassroomAssignment, 'localDone'>[], email: string | null) => void;
  toggleAssignmentDone: (id: string) => void;
  setCourseSubject: (courseId: string, subject: Subject | 'none') => void;
  toggleCourseHidden: (courseId: string) => void;
  disconnectClassroom: () => void;

  setSidebarCollapsed: (v: boolean) => void;
  exportData: () => string;
  importData: (json: string) => void;
  resetAll: () => void;
}

export type AppState = Data & Actions;

const withSchool = (s: Data, topics: SchoolTopic[]) => ({
  schoolTopics: topics,
  schoolHistory: { ...s.schoolHistory, [todayKey()]: Math.round(schoolProgress(topics)) },
});

const mapSprint = (s: Data, id: string, fn: (sp: ResearchSprint) => ResearchSprint) => ({
  sprints: s.sprints.map((sp) => (sp.id === id ? fn(sp) : sp)),
});

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      ...initialData(),

      materialize: (keys) =>
        set((s) => {
          const added: Task[] = [];
          const mat = { ...s.materialized };
          let changed = false;
          for (const k of keys) {
            if (mat[k] || k < s.settings.startDate) continue;
            const wd = weekdayIndex(parseDay(k));
            for (const b of s.template) {
              if (b.weekday !== wd) continue;
              added.push({
                id: uid(),
                title: b.title,
                category: b.category,
                date: k,
                start: b.start,
                end: b.end,
                notes: b.notes,
                done: false,
                templateId: b.id,
                source: 'local',
                updatedAt: nowIso(),
              });
            }
            mat[k] = true;
            changed = true;
          }
          return changed ? { tasks: [...s.tasks, ...added], materialized: mat } : s;
        }),

      addTask: (input) => {
        const t: Task = { done: false, source: 'local', ...input, id: uid(), updatedAt: nowIso() };
        set((s) => ({ tasks: [...s.tasks, t] }));
        return t.id;
      },
      updateTask: (id, patch) =>
        set((s) => ({ tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...patch, updatedAt: nowIso() } : t)) })),
      toggleTask: (id) =>
        set((s) => {
          const task = s.tasks.find((t) => t.id === id);
          const nowDone = task ? !task.done : false;
          return {
            tasks: s.tasks.map((t) =>
              t.id === id ? { ...t, done: nowDone, doneAt: nowDone ? nowIso() : undefined, updatedAt: nowIso() } : t,
            ),
            classroom:
              task?.assignmentId && nowDone
                ? {
                    ...s.classroom,
                    assignments: s.classroom.assignments.map((a) => (a.id === task.assignmentId ? { ...a, localDone: true } : a)),
                  }
                : s.classroom,
          };
        }),
      deleteTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
      moveTask: (id, dayDelta, minuteDelta) =>
        set((s) => ({
          tasks: s.tasks.map((t) => {
            if (t.id !== id) return t;
            const d = duration(t.start, t.end);
            const start = Math.max(0, Math.min(24 * 60 - 1 - d, toMin(t.start) + minuteDelta));
            return {
              ...t,
              date: dayKey(addDays(parseDay(t.date), dayDelta)),
              start: fromMin(start),
              end: fromMin(start + d),
              updatedAt: nowIso(),
            };
          }),
        })),
      mergeExternal: (incoming) => {
        let count = 0;
        set((s) => {
          const tasks = [...s.tasks];
          for (const inc of incoming) {
            if (!inc.externalId) continue;
            const i = tasks.findIndex((t) => t.externalId === inc.externalId);
            if (i >= 0) tasks[i] = { ...tasks[i], ...inc, updatedAt: nowIso() };
            else tasks.push({ done: false, ...inc, source: 'google', id: uid(), updatedAt: nowIso() });
            count++;
          }
          return { tasks };
        });
        return count;
      },

      startFocus: ({ category, label, minutes, taskId }) =>
        set({
          activeFocus: { category, label, taskId, plannedMinutes: minutes, startedAt: Date.now(), pausedAt: null, pausedMs: 0 },
        }),
      pauseFocus: () =>
        set((s) => (s.activeFocus && !s.activeFocus.pausedAt ? { activeFocus: { ...s.activeFocus, pausedAt: Date.now() } } : s)),
      resumeFocus: () =>
        set((s) => {
          const a = s.activeFocus;
          if (!a?.pausedAt) return s;
          return { activeFocus: { ...a, pausedMs: a.pausedMs + Date.now() - a.pausedAt, pausedAt: null } };
        }),
      completeFocus: (markTaskDone) => {
        const a = get().activeFocus;
        if (!a) return null;
        const now = Date.now();
        const minutes = Math.min(a.plannedMinutes, Math.max(1, Math.round(focusElapsed(a, now) / 60000)));
        const session: FocusSession = {
          id: uid(),
          category: a.category,
          label: a.label,
          taskId: a.taskId,
          date: todayKey(),
          startedAt: new Date(a.startedAt).toISOString(),
          endedAt: new Date(now).toISOString(),
          minutes,
          plannedMinutes: a.plannedMinutes,
        };
        set((s) => ({
          focusSessions: [...s.focusSessions, session],
          activeFocus: null,
          tasks:
            markTaskDone && a.taskId
              ? s.tasks.map((t) => (t.id === a.taskId ? { ...t, done: true, doneAt: nowIso(), updatedAt: nowIso() } : t))
              : s.tasks,
        }));
        return session;
      },
      cancelFocus: () => set({ activeFocus: null }),
      deleteSession: (id) => set((s) => ({ focusSessions: s.focusSessions.filter((x) => x.id !== id) })),

      addSchoolTopic: (subject, title) =>
        set((s) =>
          withSchool(s, [...s.schoolTopics, { id: uid(), subject, title, status: 'not_started', updatedAt: nowIso() }]),
        ),
      cycleSchoolTopic: (id) =>
        set((s) =>
          withSchool(
            s,
            s.schoolTopics.map((t) => (t.id === id ? { ...t, status: NEXT_STATUS[t.status], updatedAt: nowIso() } : t)),
          ),
        ),
      setSchoolStatus: (id, status) =>
        set((s) =>
          withSchool(
            s,
            s.schoolTopics.map((t) => (t.id === id ? { ...t, status, updatedAt: nowIso() } : t)),
          ),
        ),
      deleteSchoolTopic: (id) => set((s) => withSchool(s, s.schoolTopics.filter((t) => t.id !== id))),

      setItalianLevel: (level) => set((s) => ({ italian: { ...s.italian, level } })),
      addVocab: (n) => set((s) => ({ italian: { ...s.italian, vocab: Math.max(0, s.italian.vocab + n) } })),
      setVocab: (n) => set((s) => ({ italian: { ...s.italian, vocab: Math.max(0, Math.round(n)) } })),
      setSkill: (k, v) =>
        set((s) => ({ italian: { ...s.italian, skills: { ...s.italian.skills, [k]: Math.max(0, Math.min(100, v)) } } })),
      addTest: (t) =>
        set((s) => ({
          italian: {
            ...s.italian,
            tests: [...s.italian.tests, { ...t, id: uid() }].sort((a, b) => a.date.localeCompare(b.date)),
          },
        })),
      deleteTest: (id) => set((s) => ({ italian: { ...s.italian, tests: s.italian.tests.filter((t) => t.id !== id) } })),
      addItalianTopic: (title) =>
        set((s) => ({ italianTopics: [...s.italianTopics, { id: uid(), title, status: 'not_started' } as ItalianTopic] })),
      cycleItalianTopic: (id) =>
        set((s) => ({
          italianTopics: s.italianTopics.map((t) => (t.id === id ? { ...t, status: NEXT_STATUS[t.status] } : t)),
        })),
      deleteItalianTopic: (id) => set((s) => ({ italianTopics: s.italianTopics.filter((t) => t.id !== id) })),

      updateSprint: (id, patch) => set((s) => mapSprint(s, id, (sp) => ({ ...sp, ...patch }))),
      addSprintTask: (id, title) =>
        set((s) => mapSprint(s, id, (sp) => ({ ...sp, tasks: [...sp.tasks, { id: uid(), title, done: false }] }))),
      toggleSprintTask: (id, taskId) =>
        set((s) =>
          mapSprint(s, id, (sp) => ({
            ...sp,
            tasks: sp.tasks.map((t) => (t.id === taskId ? { ...t, done: !t.done } : t)),
          })),
        ),
      deleteSprintTask: (id, taskId) =>
        set((s) => mapSprint(s, id, (sp) => ({ ...sp, tasks: sp.tasks.filter((t) => t.id !== taskId) }))),
      completeSprint: (id) =>
        set((s) => mapSprint(s, id, (sp) => ({ ...sp, status: 'completed', completedAt: nowIso() }))),
      reopenSprint: (id) => set((s) => mapSprint(s, id, (sp) => ({ ...sp, status: 'active', completedAt: undefined }))),
      startNextSprint: () => {
        const s = get();
        const last = [...s.sprints].sort((a, b) => b.week - a.week)[0];
        const sp: ResearchSprint = {
          ...seedSprint(),
          week: (last?.week ?? 0) + 1,
          objective: last?.nextStep ?? '',
          githubUrl: last?.githubUrl ?? '',
        };
        set({ sprints: [...s.sprints, sp] });
        return sp.id;
      },

      toggleAttendance: (date) =>
        set((s) => ({
          itu: {
            ...s.itu,
            attendance: s.itu.attendance.includes(date)
              ? s.itu.attendance.filter((d) => d !== date)
              : [...s.itu.attendance, date].sort(),
          },
        })),
      addItuTask: (title) => set((s) => ({ itu: { ...s.itu, tasks: [...s.itu.tasks, { id: uid(), title, done: false }] } })),
      toggleItuTask: (id) =>
        set((s) => ({ itu: { ...s.itu, tasks: s.itu.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)) } })),
      deleteItuTask: (id) => set((s) => ({ itu: { ...s.itu, tasks: s.itu.tasks.filter((t) => t.id !== id) } })),
      addPerson: (p) => set((s) => ({ itu: { ...s.itu, people: [...s.itu.people, { ...p, id: uid() }] } })),
      deletePerson: (id) => set((s) => ({ itu: { ...s.itu, people: s.itu.people.filter((p) => p.id !== id) } })),
      setItuNotes: (notes) => set((s) => ({ itu: { ...s.itu, notes } })),
      addLearning: (text) =>
        set((s) => ({ itu: { ...s.itu, learnings: [{ id: uid(), text, date: todayKey() }, ...s.itu.learnings] } })),
      deleteLearning: (id) => set((s) => ({ itu: { ...s.itu, learnings: s.itu.learnings.filter((l) => l.id !== id) } })),

      toggleAfs: (id) => set((s) => ({ afs: s.afs.map((i) => (i.id === id ? { ...i, done: !i.done } : i)) })),
      addAfs: (group, title) => set((s) => ({ afs: [...s.afs, { id: uid(), title, done: false, group }] })),
      deleteAfs: (id) => set((s) => ({ afs: s.afs.filter((i) => i.id !== id) })),

      updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      addTemplateBlock: (b) => set((s) => ({ template: [...s.template, { ...b, id: `tpl-${uid()}` }] })),
      updateTemplateBlock: (id, patch) =>
        set((s) => ({ template: s.template.map((b) => (b.id === id ? { ...b, ...patch } : b)) })),
      deleteTemplateBlock: (id) => set((s) => ({ template: s.template.filter((b) => b.id !== id) })),
      applyTemplateFromToday: () =>
        set((s) => {
          const today = todayKey();
          const materialized: Record<string, true> = {};
          for (const k of Object.keys(s.materialized)) if (k < today) materialized[k] = true;
          return {
            tasks: s.tasks.filter((t) => !(t.templateId && !t.done && t.date >= today)),
            materialized,
          };
        }),

      applyClassroomSync: (incoming, email) =>
        set((s) => {
          const prev = new Map(s.classroom.assignments.map((a) => [a.id, a]));
          return {
            classroom: {
              ...s.classroom,
              connected: true,
              email: email ?? s.classroom.email,
              lastSyncAt: nowIso(),
              assignments: incoming.map((a) => ({ ...a, localDone: prev.get(a.id)?.localDone ?? false })),
            },
          };
        }),
      toggleAssignmentDone: (id) =>
        set((s) => ({
          classroom: {
            ...s.classroom,
            assignments: s.classroom.assignments.map((a) => (a.id === id ? { ...a, localDone: !a.localDone } : a)),
          },
        })),
      setCourseSubject: (courseId, subject) =>
        set((s) => ({ classroom: { ...s.classroom, courseSubjects: { ...s.classroom.courseSubjects, [courseId]: subject } } })),
      toggleCourseHidden: (courseId) =>
        set((s) => ({
          classroom: {
            ...s.classroom,
            hiddenCourses: s.classroom.hiddenCourses.includes(courseId)
              ? s.classroom.hiddenCourses.filter((c) => c !== courseId)
              : [...s.classroom.hiddenCourses, courseId],
          },
        })),
      disconnectClassroom: () => set({ classroom: initialData().classroom }),

      setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
      exportData: () => {
        const s = get();
        const data: Record<string, unknown> = {};
        for (const k of DATA_KEYS) data[k] = s[k];
        return JSON.stringify({ app: 'yigit-os', version: 1, exportedAt: nowIso(), data }, null, 2);
      },
      importData: (json) => {
        const parsed = JSON.parse(json);
        const data = parsed?.data;
        if (parsed?.app !== 'yigit-os' || !data || typeof data !== 'object') {
          throw new Error('This file is not a YİĞİT OS backup.');
        }
        const patch: Partial<Data> = {};
        for (const k of DATA_KEYS) if (k in data) (patch as Record<string, unknown>)[k] = data[k];
        set({ ...patch, activeFocus: null });
      },
      resetAll: () => set({ ...initialData() }),
    }),
    {
      name: 'yigit-os',
      version: 1,
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => {
        const out: Record<string, unknown> = {};
        for (const k of DATA_KEYS) out[k] = s[k];
        return out as Partial<AppState>;
      },
    },
  ),
);
