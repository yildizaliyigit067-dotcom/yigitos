export type Category =
  | 'class'
  | 'school'
  | 'exam'
  | 'italian'
  | 'research'
  | 'itu'
  | 'planning'
  | 'event'
  | 'personal';

export type TopicStatus = 'not_started' | 'in_progress' | 'completed';

export type Subject =
  | 'Mathematics'
  | 'Physics'
  | 'Chemistry'
  | 'Biology'
  | 'Italian Literature'
  | 'Italian Language'
  | 'Latin'
  | 'Philosophy'
  | 'History';

export type ItalianLevel = 'A0' | 'A1' | 'A1+' | 'A2' | 'A2+' | 'B1';

export interface CheckItem {
  id: string;
  title: string;
  done: boolean;
}

export interface Task {
  id: string;
  title: string;
  category: Category;
  /** yyyy-MM-dd */
  date: string;
  /** HH:mm */
  start: string;
  /** HH:mm */
  end: string;
  notes?: string;
  done: boolean;
  doneAt?: string;
  templateId?: string;
  source: 'local' | 'google';
  externalId?: string;
  /** Google Classroom coursework this block was planned for. */
  assignmentId?: string;
  updatedAt: string;
}

export interface TemplateBlock {
  id: string;
  /** 0 = Monday … 6 = Sunday */
  weekday: number;
  title: string;
  category: Category;
  start: string;
  end: string;
  notes?: string;
}

export interface FocusSession {
  id: string;
  category: Category;
  label: string;
  taskId?: string;
  date: string;
  startedAt: string;
  endedAt: string;
  minutes: number;
  plannedMinutes: number;
}

export interface ActiveFocus {
  category: Category;
  label: string;
  taskId?: string;
  plannedMinutes: number;
  startedAt: number;
  pausedAt: number | null;
  pausedMs: number;
}

export interface SchoolTopic {
  id: string;
  subject: Subject;
  title: string;
  status: TopicStatus;
  updatedAt: string;
}

export interface ItalianTopic {
  id: string;
  title: string;
  status: TopicStatus;
}

export interface ItalianTest {
  id: string;
  date: string;
  label: string;
  score: number;
  max: number;
}

export interface ItalianSkills {
  listening: number;
  speaking: number;
  reading: number;
  writing: number;
}

export interface ItalianState {
  level: ItalianLevel;
  vocab: number;
  skills: ItalianSkills;
  tests: ItalianTest[];
}

export interface ResearchSprint {
  id: string;
  week: number;
  startDate: string;
  objective: string;
  tasks: CheckItem[];
  experiments: string;
  code: string;
  results: string;
  notes: string;
  githubUrl: string;
  nextStep: string;
  status: 'active' | 'completed';
  completedAt?: string;
}

export interface Person {
  id: string;
  name: string;
  role: string;
  note: string;
}

export interface Learning {
  id: string;
  text: string;
  date: string;
}

export interface ItuState {
  attendance: string[];
  tasks: CheckItem[];
  people: Person[];
  notes: string;
  learnings: Learning[];
}

export interface AfsItem extends CheckItem {
  group: 'documents' | 'preparation';
}

export interface Settings {
  name: string;
  afsDate: string;
  weeklyItalianGoalMin: number;
  /** Planner blocks are generated only from this date on. */
  startDate: string;
}

export type SubmissionState = 'NEW' | 'CREATED' | 'TURNED_IN' | 'RETURNED' | 'RECLAIMED_BY_STUDENT' | 'UNKNOWN';

export interface ClassroomAssignment {
  /** courseWork id */
  id: string;
  courseId: string;
  courseName: string;
  title: string;
  description?: string;
  link: string;
  /** Local time, yyyy-MM-ddTHH:mm. null = no due date. */
  due: string | null;
  maxPoints?: number;
  state: SubmissionState;
  late: boolean;
  grade?: number;
  createdAt: string;
  updatedAt: string;
  /** Ticked off inside YİĞİT OS (does not turn anything in on Classroom). */
  localDone: boolean;
}

export interface ClassroomState {
  connected: boolean;
  email: string | null;
  lastSyncAt: string | null;
  assignments: ClassroomAssignment[];
  courseSubjects: Record<string, Subject | 'none'>;
  hiddenCourses: string[];
}
