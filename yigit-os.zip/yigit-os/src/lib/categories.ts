import type { Category } from './types';

export const CATEGORIES: Record<Category, { label: string; color: string; study: boolean }> = {
  personal: { label: 'Task', color: '#9A9AA6', study: true },
  school: { label: 'School', color: '#F0B04A', study: true },
  exam: { label: 'Exam', color: '#F27474', study: true },
  italian: { label: 'Italian', color: '#45CF98', study: true },
  research: { label: 'Research', color: '#A58CFA', study: true },
  itu: { label: 'İTÜ Çekirdek', color: '#4CC0F2', study: true },
  planning: { label: 'Planning', color: '#B4B4BE', study: true },
  event: { label: 'Event', color: '#E28BEE', study: false },
  class: { label: 'Class', color: '#62626D', study: false },
};

export const CATEGORY_ORDER: Category[] = [
  'personal',
  'school',
  'exam',
  'italian',
  'research',
  'itu',
  'planning',
  'event',
  'class',
];

export const FOCUS_CATEGORIES: Category[] = ['italian', 'school', 'research', 'itu', 'personal'];

export type Bucket = 'italian' | 'school' | 'research' | 'itu';

export const BUCKETS: { key: Bucket; label: string; color: string }[] = [
  { key: 'italian', label: 'Italian', color: CATEGORIES.italian.color },
  { key: 'school', label: 'School', color: CATEGORIES.school.color },
  { key: 'research', label: 'Research', color: CATEGORIES.research.color },
  { key: 'itu', label: 'Internship', color: CATEGORIES.itu.color },
];

export function bucketOf(c: Category): Bucket | null {
  if (c === 'italian') return 'italian';
  if (c === 'school' || c === 'exam') return 'school';
  if (c === 'research') return 'research';
  if (c === 'itu') return 'itu';
  return null;
}

export const withAlpha = (hex: string, alpha: number) => {
  const a = Math.round(Math.max(0, Math.min(1, alpha)) * 255)
    .toString(16)
    .padStart(2, '0');
  return `${hex}${a}`;
};
