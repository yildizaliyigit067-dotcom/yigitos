import { subDays } from 'date-fns';
import type { AfsItem, FocusSession, ItalianState, ResearchSprint, SchoolTopic, Task } from './types';
import { bucketOf, type Bucket } from './categories';
import { dayKey, duration, todayKey } from './date';
import { LEVELS, VOCAB_TARGET } from './seed';
import { clamp, pct } from './utils';

export type BucketTotals = Record<Bucket, number>;
export const emptyTotals = (): BucketTotals => ({ italian: 0, school: 0, research: 0, itu: 0 });
export const totalOf = (t: BucketTotals) => t.italian + t.school + t.research + t.itu;

/**
 * Minutes worked per day per bucket.
 * Focus sessions count with their real length. A completed task without a focus
 * session counts with its planned length, so ticking a block off is enough.
 */
export function buildLog(tasks: Task[], sessions: FocusSession[]) {
  const linked = new Set(sessions.map((s) => s.taskId).filter(Boolean) as string[]);
  const log = new Map<string, BucketTotals>();
  const add = (key: string, bucket: Bucket | null, minutes: number) => {
    if (!bucket || minutes <= 0) return;
    const entry = log.get(key) ?? emptyTotals();
    entry[bucket] += minutes;
    log.set(key, entry);
  };
  for (const s of sessions) add(s.date, bucketOf(s.category), s.minutes);
  for (const t of tasks) if (t.done && !linked.has(t.id)) add(t.date, bucketOf(t.category), duration(t.start, t.end));
  return log;
}
export type Log = ReturnType<typeof buildLog>;

export function sumRange(log: Log, fromKey: string, toKey: string): BucketTotals {
  const out = emptyTotals();
  log.forEach((v, k) => {
    if (k >= fromKey && k <= toKey) {
      out.italian += v.italian;
      out.school += v.school;
      out.research += v.research;
      out.itu += v.itu;
    }
  });
  return out;
}

export const countDone = (tasks: Task[], fromKey: string, toKey: string) =>
  tasks.filter((t) => t.done && t.date >= fromKey && t.date <= toKey && t.category !== 'class').length;

export const countSessions = (sessions: FocusSession[], fromKey: string, toKey: string) =>
  sessions.filter((s) => s.date >= fromKey && s.date <= toKey).length;

export function schoolProgress(topics: SchoolTopic[]) {
  if (!topics.length) return 0;
  const score = topics.reduce((a, t) => a + (t.status === 'completed' ? 1 : t.status === 'in_progress' ? 0.5 : 0), 0);
  return (score / topics.length) * 100;
}

export function italianStreak(log: Log) {
  let d = new Date();
  if (!(log.get(todayKey())?.italian ?? 0)) d = subDays(d, 1);
  let n = 0;
  while ((log.get(dayKey(d))?.italian ?? 0) > 0) {
    n++;
    d = subDays(d, 1);
  }
  return n;
}

export function researchStreak(sprints: ResearchSprint[]) {
  const sorted = [...sprints].sort((a, b) => b.week - a.week);
  let i = 0;
  if (sorted[0]?.status === 'active') i = 1;
  let n = 0;
  for (; i < sorted.length && sorted[i].status === 'completed'; i++) n++;
  return n;
}

export function italianReadiness(it: ItalianState) {
  const level = pct(LEVELS.indexOf(it.level), LEVELS.length - 1);
  const vocab = clamp(pct(it.vocab, VOCAB_TARGET));
  const s = it.skills;
  const skills = (s.listening + s.speaking + s.reading + s.writing) / 4;
  return clamp(level * 0.4 + vocab * 0.3 + skills * 0.3);
}

export const afsGroupPct = (items: AfsItem[], group: AfsItem['group']) => {
  const g = items.filter((i) => i.group === group);
  return pct(g.filter((i) => i.done).length, g.length);
};
