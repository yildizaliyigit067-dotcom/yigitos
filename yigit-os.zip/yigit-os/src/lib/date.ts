import { addDays, differenceInCalendarDays, format, parseISO, startOfWeek } from 'date-fns';

export const dayKey = (d: Date) => format(d, 'yyyy-MM-dd');
export const parseDay = (key: string) => parseISO(key);
export const todayKey = () => dayKey(new Date());

export const weekStartOf = (d: Date) => startOfWeek(d, { weekStartsOn: 1 });
export const weekDays = (start: Date) => Array.from({ length: 7 }, (_, i) => addDays(start, i));
export const weekKeys = (start: Date) => weekDays(start).map(dayKey);

/** Monday = 0 … Sunday = 6 */
export const weekdayIndex = (d: Date) => (d.getDay() + 6) % 7;

export const toMin = (hm: string) => {
  const [h, m] = hm.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
};

export const fromMin = (min: number) => {
  const c = Math.max(0, Math.min(24 * 60 - 1, Math.round(min)));
  return `${String(Math.floor(c / 60)).padStart(2, '0')}:${String(c % 60).padStart(2, '0')}`;
};

export const duration = (start: string, end: string) => Math.max(0, toMin(end) - toMin(start));

export const nowMin = (d = new Date()) => d.getHours() * 60 + d.getMinutes();

export const fmtDur = (minutes: number) => {
  const m = Math.max(0, Math.round(minutes));
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (!h) return `${r}m`;
  if (!r) return `${h}h`;
  return `${h}h ${r}m`;
};

export const fmtHours = (minutes: number) => {
  const h = minutes / 60;
  return `${h >= 10 ? Math.round(h) : Math.round(h * 10) / 10}h`;
};

export const daysUntil = (key: string) => differenceInCalendarDays(parseDay(key), new Date());
