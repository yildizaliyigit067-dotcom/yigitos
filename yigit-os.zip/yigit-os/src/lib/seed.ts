import type {
  AfsItem,
  Category,
  ItalianLevel,
  ItalianTopic,
  ResearchSprint,
  SchoolTopic,
  Subject,
  TemplateBlock,
} from './types';
import { uid } from './utils';
import { todayKey } from './date';

export const SUBJECTS: Subject[] = [
  'Mathematics',
  'Physics',
  'Chemistry',
  'Biology',
  'Italian Literature',
  'Italian Language',
  'Latin',
  'Philosophy',
  'History',
];

const block = (
  weekday: number,
  start: string,
  end: string,
  title: string,
  category: Category,
  notes?: string,
): TemplateBlock => ({ id: `tpl-${weekday}-${start.replace(':', '')}`, weekday, start, end, title, category, notes });

/** Base weekly program. Monday = 0. */
export const TEMPLATE: TemplateBlock[] = [
  ...[0, 1, 2, 3, 4].map((d) => block(d, '07:50', '15:30', 'School', 'class')),

  block(0, '16:45', '17:30', 'School review', 'school', 'Review today’s lessons'),
  block(0, '17:45', '18:30', 'Italian', 'italian', 'Grammar + vocabulary'),
  block(0, '18:45', '19:30', 'Missed school topics', 'school', 'One topic from the catch-up list'),

  block(1, '17:00', '19:00', 'İTÜ Çekirdek internship', 'itu'),
  block(1, '19:00', '19:30', 'Light Italian', 'italian', 'Listening or flashcards'),

  block(2, '18:00', '20:00', 'School review', 'school'),
  block(2, '20:15', '20:45', 'Light Italian', 'italian'),

  block(3, '17:00', '19:00', 'Optional İTÜ / flexible block', 'itu', 'Use for İTÜ or whatever is most behind'),

  block(4, '16:00', '19:00', 'İTÜ Çekirdek internship', 'itu'),
  block(4, '19:00', '19:30', 'Light Italian', 'italian'),

  block(5, '10:30', '13:00', 'Research sprint', 'research'),
  block(5, '15:00', '16:00', 'School catch-up', 'school'),
  block(5, '16:10', '17:10', 'Italian', 'italian'),

  block(6, '11:00', '12:30', 'Italian weekly check + speaking', 'italian'),
  block(6, '16:00', '17:30', 'Weekly planning', 'planning'),

  ...[6, 0, 1, 2, 3].map((d) => block(d, '21:00', '21:15', 'Tomorrow prep', 'planning', 'Bag, schedule, first task')),
];

const SCHOOL_SEED: Record<Subject, string[]> = {
  Mathematics: ['Second-degree equations', 'Inequalities', 'Systems of equations', 'The line in analytic geometry', 'Parabola'],
  Physics: ['Motion in two dimensions', 'Newton’s laws', 'Work and energy', 'Momentum'],
  Chemistry: ['Atomic structure', 'Periodic table', 'Chemical bonds', 'Stoichiometry'],
  Biology: ['Cell structure', 'Membrane transport', 'Mitosis and meiosis', 'Mendelian genetics'],
  'Italian Literature': ['Dolce Stil Novo', 'Dante – Inferno, canti I–III', 'Petrarca', 'Boccaccio'],
  'Italian Language': ['Analisi logica', 'Analisi del periodo', 'Testo argomentativo'],
  Latin: ['Third declension', 'Perfect system', 'Ablative absolute', 'Translation practice'],
  Philosophy: ['Presocratics', 'Socrates', 'Plato'],
  History: ['Crisis of the Roman Republic', 'Augustus and the Principate', 'Fall of the Western Empire'],
};

export const seedSchoolTopics = (): SchoolTopic[] =>
  SUBJECTS.flatMap((subject) =>
    SCHOOL_SEED[subject].map((title) => ({
      id: uid(),
      subject,
      title,
      status: 'not_started' as const,
      updatedAt: new Date().toISOString(),
    })),
  );

export const seedItalianTopics = (): ItalianTopic[] =>
  [
    'Articles and nouns',
    'Presente indicativo',
    'Essere / avere',
    'Prepositions (semplici e articolate)',
    'Passato prossimo',
    'Imperfetto',
    'Direct and indirect pronouns',
    'Futuro semplice',
    'Condizionale presente',
    'Congiuntivo presente',
  ].map((title) => ({ id: uid(), title, status: 'not_started' as const }));

export const seedAfs = (): AfsItem[] => [
  ...['Passport (6+ months validity)', 'Student visa application', 'Medical forms', 'School enrollment documents', 'Travel insurance', 'Parental consent forms'].map(
    (title) => ({ id: uid(), title, done: false, group: 'documents' as const }),
  ),
  ...['AFS orientation sessions', 'Letter to host family', 'Packing list', 'Budget and banking plan', 'Plan for school subjects in Italy'].map(
    (title) => ({ id: uid(), title, done: false, group: 'preparation' as const }),
  ),
];

export const seedSprint = (): ResearchSprint => ({
  id: uid(),
  week: 1,
  startDate: todayKey(),
  objective: '',
  tasks: [],
  experiments: '',
  code: '',
  results: '',
  notes: '',
  githubUrl: '',
  nextStep: '',
  status: 'active',
});

export const LEVELS: ItalianLevel[] = ['A0', 'A1', 'A1+', 'A2', 'A2+', 'B1'];

export const ROADMAP = [
  { month: 9, name: 'October', phase: 'Foundation', goal: 'Core grammar, pronunciation, first 500 words', vocab: 500 },
  { month: 10, name: 'November', phase: 'A2', goal: 'Past tenses, everyday situations, 1,000 words', vocab: 1000 },
  { month: 11, name: 'December', phase: 'Active Italian', goal: 'Speak daily, read short texts, 1,500 words', vocab: 1500 },
  { month: 0, name: 'January', phase: 'Functional B1', goal: 'Hold real conversations before AFS, 2,000 words', vocab: 2000 },
];

export const VOCAB_TARGET = 2000;
