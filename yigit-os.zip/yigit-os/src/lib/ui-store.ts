'use client';

import { create } from 'zustand';
import type { Category } from './types';
import { uid } from './utils';

export interface TaskPreset {
  title?: string;
  category?: Category;
  date?: string;
  start?: string;
  end?: string;
  notes?: string;
  assignmentId?: string;
}

type DialogState = { mode: 'create'; preset?: TaskPreset } | { mode: 'edit'; taskId: string };

interface Toast {
  id: string;
  message: string;
}

interface UIState {
  palette: boolean;
  setPalette: (v: boolean) => void;
  dialog: DialogState | null;
  openCreate: (preset?: TaskPreset) => void;
  openEdit: (taskId: string) => void;
  closeDialog: () => void;
  moreOpen: boolean;
  setMoreOpen: (v: boolean) => void;
  focusMinimized: boolean;
  setFocusMinimized: (v: boolean) => void;
  toasts: Toast[];
  toast: (message: string) => void;
  dismissToast: (id: string) => void;
}

export const useUI = create<UIState>()((set, get) => ({
  palette: false,
  setPalette: (palette) => set({ palette }),
  dialog: null,
  openCreate: (preset) => set({ dialog: { mode: 'create', preset }, palette: false }),
  openEdit: (taskId) => set({ dialog: { mode: 'edit', taskId } }),
  closeDialog: () => set({ dialog: null }),
  moreOpen: false,
  setMoreOpen: (moreOpen) => set({ moreOpen }),
  focusMinimized: false,
  setFocusMinimized: (focusMinimized) => set({ focusMinimized }),
  toasts: [],
  toast: (message) => {
    const id = uid();
    set((s) => ({ toasts: [...s.toasts.slice(-2), { id, message }] }));
    setTimeout(() => get().dismissToast(id), 2800);
  },
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}));
