'use client';

import { useStore } from '../store';
import { cachedToken, clearToken, fetchClassroom, requestToken } from './api';

let running: Promise<{ count: number } | null> | null = null;

/**
 * interactive = true: may open the Google window (call from a click).
 * interactive = false: only syncs if a valid token is already cached this session.
 */
export function syncClassroom(interactive: boolean) {
  if (running) return running;
  running = (async () => {
    const st = useStore.getState().classroom;
    let token = cachedToken();
    if (!token) {
      if (!interactive) return null;
      token = await requestToken(st.email ?? undefined, st.connected ? '' : 'select_account');
    }
    const { assignments, email } = await fetchClassroom(token);
    useStore.getState().applyClassroomSync(assignments, email);
    return { count: assignments.length };
  })().finally(() => {
    running = null;
  });
  return running;
}

export function disconnectClassroom() {
  clearToken();
  useStore.getState().disconnectClassroom();
}
