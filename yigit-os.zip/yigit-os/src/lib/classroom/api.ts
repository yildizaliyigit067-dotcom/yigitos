'use client';

import { format } from 'date-fns';
import type { ClassroomAssignment, SubmissionState } from '../types';

/**
 * Google Classroom, read-only, straight from the browser.
 * Auth uses Google Identity Services (token model): no backend, no stored refresh token.
 * Needs NEXT_PUBLIC_GOOGLE_CLIENT_ID (a "Web application" OAuth client).
 */

const API = 'https://classroom.googleapis.com/v1';
const SCOPES = [
  'https://www.googleapis.com/auth/classroom.courses.readonly',
  'https://www.googleapis.com/auth/classroom.coursework.me.readonly',
  'email',
].join(' ');
const TOKEN_KEY = 'yigit-os:classroom-token';

export const classroomClientId = () => process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ?? '';
export const isClassroomConfigured = () => Boolean(classroomClientId());

export type ClassroomErrorKind = 'auth' | 'blocked' | 'api-disabled' | 'popup' | 'network' | 'other';

export class ClassroomError extends Error {
  constructor(
    message: string,
    public kind: ClassroomErrorKind = 'other',
  ) {
    super(message);
  }
}

interface TokenResponse {
  access_token?: string;
  expires_in?: number;
  error?: string;
  error_description?: string;
}
interface TokenClient {
  requestAccessToken(o?: { prompt?: string; hint?: string }): void;
}
declare global {
  interface Window {
    google?: {
      accounts: {
        oauth2: {
          initTokenClient(cfg: {
            client_id: string;
            scope: string;
            hint?: string;
            prompt?: string;
            callback: (r: TokenResponse) => void;
            error_callback?: (e: { type: string; message?: string }) => void;
          }): TokenClient;
          revoke(token: string, done?: () => void): void;
        };
      };
    };
  }
}

let gis: Promise<void> | null = null;
function loadGis() {
  if (window.google?.accounts?.oauth2) return Promise.resolve();
  if (gis) return gis;
  gis = new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => {
      gis = null;
      reject(new ClassroomError('Could not load Google sign-in. Check your connection.', 'network'));
    };
    document.head.appendChild(s);
  });
  return gis;
}

export function cachedToken(): string | null {
  try {
    const raw = sessionStorage.getItem(TOKEN_KEY);
    if (!raw) return null;
    const t = JSON.parse(raw) as { token: string; exp: number };
    return t.exp > Date.now() + 60_000 ? t.token : null;
  } catch {
    return null;
  }
}
function saveToken(token: string, expiresIn: number) {
  try {
    sessionStorage.setItem(TOKEN_KEY, JSON.stringify({ token, exp: Date.now() + expiresIn * 1000 }));
  } catch {
    /* private mode */
  }
}
export function clearToken() {
  try {
    const t = cachedToken();
    if (t) window.google?.accounts.oauth2.revoke(t);
    sessionStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
}

const explainOAuth = (code?: string) => {
  if (code === 'access_denied')
    return new ClassroomError(
      'Access was not granted. If you allowed it and still see this, your school may block outside apps for student accounts.',
      'blocked',
    );
  if (code === 'admin_policy_enforced' || code === 'org_internal')
    return new ClassroomError('Your school’s Google admin blocks this app for student accounts.', 'blocked');
  return new ClassroomError(`Google sign-in failed${code ? ` (${code})` : ''}.`, 'auth');
};

/** Must be called from a click/tap so the Google pop-up is allowed. */
export async function requestToken(hint?: string, prompt: '' | 'select_account' | 'consent' = ''): Promise<string> {
  if (!isClassroomConfigured()) throw new ClassroomError('Google Client ID is missing.', 'other');
  await loadGis();
  return new Promise((resolve, reject) => {
    const client = window.google!.accounts.oauth2.initTokenClient({
      client_id: classroomClientId(),
      scope: SCOPES,
      hint,
      prompt,
      callback: (r) => {
        if (r.error || !r.access_token) return reject(explainOAuth(r.error));
        saveToken(r.access_token, r.expires_in ?? 3600);
        resolve(r.access_token);
      },
      error_callback: (e) =>
        reject(
          new ClassroomError(
            e.type === 'popup_failed_to_open'
              ? 'The Google window was blocked. Allow pop-ups for this site and try again.'
              : e.type === 'popup_closed'
                ? 'The Google window was closed before finishing.'
                : 'Google sign-in failed.',
            'popup',
          ),
        ),
    });
    client.requestAccessToken({ prompt, hint });
  });
}

async function get<T>(token: string, url: string): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url.startsWith('http') ? url : API + url, { headers: { Authorization: `Bearer ${token}` } });
  } catch {
    throw new ClassroomError('No connection to Google. Try again when you are online.', 'network');
  }
  if (res.status === 401) {
    clearToken();
    throw new ClassroomError('Your Google session expired. Sync again.', 'auth');
  }
  if (res.status === 403) {
    const body = await res.json().catch(() => null);
    const msg: string = body?.error?.message ?? '';
    if (/has not been used|is disabled|not enabled/i.test(msg))
      throw new ClassroomError('The Google Classroom API is not enabled in your Google Cloud project.', 'api-disabled');
    throw new ClassroomError('Your school account does not let this app read Classroom.', 'blocked');
  }
  if (!res.ok) throw new ClassroomError(`Classroom request failed (${res.status}).`, 'other');
  return (await res.json()) as T;
}

async function list<T>(token: string, path: string, key: string, maxPages = 4): Promise<T[]> {
  const out: T[] = [];
  let pageToken: string | undefined;
  let pages = 0;
  do {
    const sep = path.includes('?') ? '&' : '?';
    const data = await get<Record<string, unknown>>(token, `${path}${pageToken ? `${sep}pageToken=${pageToken}` : ''}`);
    out.push(...((data[key] as T[]) ?? []));
    pageToken = data.nextPageToken as string | undefined;
    pages++;
  } while (pageToken && pages < maxPages);
  return out;
}

interface Course {
  id: string;
  name: string;
  section?: string;
}
interface CourseWork {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  alternateLink: string;
  state?: string;
  dueDate?: { year: number; month: number; day: number };
  dueTime?: { hours?: number; minutes?: number };
  maxPoints?: number;
  creationTime: string;
  updateTime: string;
}
interface Submission {
  courseWorkId: string;
  state?: SubmissionState;
  late?: boolean;
  assignedGrade?: number;
}

const pad = (n: number) => String(n).padStart(2, '0');

/** Classroom stores due date/time in UTC; convert to local wall time. */
function localDue(w: CourseWork): string | null {
  if (!w.dueDate) return null;
  const { year, month, day } = w.dueDate;
  if (w.dueTime) {
    const d = new Date(Date.UTC(year, month - 1, day, w.dueTime.hours ?? 0, w.dueTime.minutes ?? 0));
    return format(d, "yyyy-MM-dd'T'HH:mm");
  }
  return `${year}-${pad(month)}-${pad(day)}T23:59`;
}

export async function fetchClassroom(token: string) {
  const [courses, email] = await Promise.all([
    list<Course>(token, '/courses?studentId=me&courseStates=ACTIVE&pageSize=100', 'courses'),
    get<{ email?: string }>(token, 'https://www.googleapis.com/oauth2/v3/userinfo')
      .then((u) => u.email ?? null)
      .catch(() => null),
  ]);

  const cutoffDue = format(new Date(Date.now() - 45 * 86400000), "yyyy-MM-dd'T'HH:mm");
  const cutoffCreated = new Date(Date.now() - 120 * 86400000).toISOString();

  const perCourse = await Promise.all(
    courses.map(async (c) => {
      const [work, subs] = await Promise.all([
        list<CourseWork>(token, `/courses/${c.id}/courseWork?pageSize=100&orderBy=updateTime%20desc`, 'courseWork'),
        list<Submission>(token, `/courses/${c.id}/courseWork/-/studentSubmissions?userId=me&pageSize=100`, 'studentSubmissions'),
      ]);
      const sub = new Map(subs.map((s) => [s.courseWorkId, s]));
      return work
        .map((w): Omit<ClassroomAssignment, 'localDone'> => {
          const s = sub.get(w.id);
          return {
            id: w.id,
            courseId: c.id,
            courseName: c.name,
            title: w.title,
            description: w.description,
            link: w.alternateLink,
            due: localDue(w),
            maxPoints: w.maxPoints,
            state: s?.state ?? 'UNKNOWN',
            late: Boolean(s?.late),
            grade: s?.assignedGrade,
            createdAt: w.creationTime,
            updatedAt: w.updateTime,
          };
        })
        .filter((a) => (a.due ? a.due >= cutoffDue : a.createdAt >= cutoffCreated));
    }),
  );

  return { assignments: perCourse.flat(), email, courseCount: courses.length };
}
