import { differenceInCalendarDays, format, parseISO } from 'date-fns';
import type { ClassroomAssignment, ClassroomState, Subject } from '../types';

const RULES: [RegExp, Subject][] = [
  [/matem|math|matematik/i, 'Mathematics'],
  [/fisic|fizik|physic/i, 'Physics'],
  [/chimic|kimya|chem/i, 'Chemistry'],
  [/biolog|biyoloj|scienz|science/i, 'Biology'],
  [/latin/i, 'Latin'],
  [/filosof|felsefe|philos/i, 'Philosophy'],
  [/storia|tarih|histor/i, 'History'],
  [/letteratura|literat|edebiyat/i, 'Italian Literature'],
  [/italian|grammatica|lingua/i, 'Italian Language'],
];

export const guessSubject = (courseName: string): Subject | null => RULES.find(([re]) => re.test(courseName))?.[1] ?? null;

export const subjectOf = (a: ClassroomAssignment, c: ClassroomState): Subject | null => {
  const set = c.courseSubjects[a.courseId];
  if (set === 'none') return null;
  return set ?? guessSubject(a.courseName);
};

export const isDone = (a: ClassroomAssignment) => a.localDone || a.state === 'TURNED_IN' || a.state === 'RETURNED';

export const dueKey = (a: ClassroomAssignment) => a.due?.slice(0, 10) ?? null;

export const isOverdue = (a: ClassroomAssignment, now = new Date()) =>
  !isDone(a) && !!a.due && parseISO(a.due).getTime() < now.getTime();

export function statusOf(a: ClassroomAssignment, now = new Date()): { label: string; color: string } {
  if (a.state === 'RETURNED')
    return {
      label: a.grade != null ? `Graded ${a.grade}${a.maxPoints ? `/${a.maxPoints}` : ''}` : 'Returned',
      color: '#3FCF8E',
    };
  if (a.state === 'TURNED_IN') return { label: a.late ? 'Turned in late' : 'Turned in', color: '#3FCF8E' };
  if (a.localDone) return { label: 'Done · not turned in', color: '#9A9AA6' };
  if (isOverdue(a, now)) return { label: 'Missing', color: '#F27474' };
  return { label: 'Assigned', color: '#F0B04A' };
}

export function dueLabel(due: string | null, now = new Date()) {
  if (!due) return 'No due date';
  const d = parseISO(due);
  const time = due.endsWith('23:59') ? '' : ` ${format(d, 'HH:mm')}`;
  const diff = differenceInCalendarDays(d, now);
  if (diff === 0) return `Today${time}`;
  if (diff === 1) return `Tomorrow${time}`;
  if (diff === -1) return `Yesterday${time}`;
  if (diff > 1 && diff < 7) return `${format(d, 'EEEE')}${time}`;
  return `${format(d, 'd MMM')}${time}`;
}

export const visibleAssignments = (c: ClassroomState) => c.assignments.filter((a) => !c.hiddenCourses.includes(a.courseId));
