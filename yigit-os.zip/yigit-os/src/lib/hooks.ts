'use client';

import { useEffect, useMemo, useState } from 'react';
import { useStore } from './store';
import { buildLog } from './stats';

export function useMounted() {
  const [m, setM] = useState(false);
  useEffect(() => setM(true), []);
  return m;
}

export function useNow(intervalMs = 30_000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** Makes sure the weekly template has been turned into real tasks for these days. */
export function useMaterialize(keys: string[]) {
  const materialize = useStore((s) => s.materialize);
  const sig = keys.join(',');
  useEffect(() => {
    materialize(sig.split(','));
  }, [sig, materialize]);
}

export function useLog() {
  const tasks = useStore((s) => s.tasks);
  const sessions = useStore((s) => s.focusSessions);
  return useMemo(() => buildLog(tasks, sessions), [tasks, sessions]);
}
