'use client';

import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { format } from 'date-fns';
import { Check, ExternalLink, Flame, Github, Play, Plus, RotateCcw, Trash2 } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useLog } from '@/lib/hooks';
import { CATEGORIES } from '@/lib/categories';
import { fmtDur, parseDay } from '@/lib/date';
import { researchStreak } from '@/lib/stats';
import type { ResearchSprint } from '@/lib/types';
import { cn, pct } from '@/lib/utils';
import { Bar, Button, Card, CardHeader, Checkbox, Input, Stat, Textarea } from '@/components/ui';

const VIOLET = CATEGORIES.research.color;

function SprintCompleted({ week, onDone }: { week: number | null; onDone: () => void }) {
  useEffect(() => {
    if (week === null) return;
    const id = setTimeout(onDone, 2600);
    return () => clearTimeout(id);
  }, [week, onDone]);
  if (typeof document === 'undefined') return null;
  return createPortal(
    <AnimatePresence>
      {week !== null && (
        <motion.div
          className="fixed inset-0 z-[75] grid place-items-center bg-black/70 backdrop-blur-md"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onDone}
        >
          <div className="relative grid place-items-center">
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="absolute h-24 w-24 rounded-full border"
                style={{ borderColor: VIOLET }}
                initial={{ scale: 0.6, opacity: 0.7 }}
                animate={{ scale: 3.2, opacity: 0 }}
                transition={{ duration: 1.8, delay: 0.25 + i * 0.3, ease: 'easeOut' }}
              />
            ))}
            <motion.div
              className="grid h-24 w-24 place-items-center rounded-full"
              style={{ background: VIOLET, boxShadow: `0 0 60px ${VIOLET}88` }}
              initial={{ scale: 0, rotate: -30 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', bounce: 0.45, duration: 0.7 }}
            >
              <Check className="h-11 w-11 text-white" strokeWidth={3} />
            </motion.div>
            <motion.div className="absolute top-32 whitespace-nowrap text-center" initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.35 }}>
              <div className="text-[26px] font-semibold tracking-[-0.02em]">Sprint completed</div>
              <div className="mt-1 text-[14px] text-muted">Week {week} is in the books</div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}

function Field({ label, value, onChange, placeholder, rows = 4, mono }: { label: string; value: string; onChange: (v: string) => void; placeholder: string; rows?: number; mono?: boolean }) {
  return (
    <label className="block">
      <span className="label">{label}</span>
      <Textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={rows} className={cn('mt-1.5', mono && 'font-mono text-[12.5px]')} />
    </label>
  );
}

export default function ResearchPage() {
  const sprints = useStore((s) => s.sprints);
  const update = useStore((s) => s.updateSprint);
  const addTask = useStore((s) => s.addSprintTask);
  const toggleTask = useStore((s) => s.toggleSprintTask);
  const delTask = useStore((s) => s.deleteSprintTask);
  const complete = useStore((s) => s.completeSprint);
  const reopen = useStore((s) => s.reopenSprint);
  const startNext = useStore((s) => s.startNextSprint);
  const startFocus = useStore((s) => s.startFocus);
  const log = useLog();

  const sorted = useMemo(() => [...sprints].sort((a, b) => b.week - a.week), [sprints]);
  const [selected, setSelected] = useState<string>(sorted[0]?.id);
  const sp: ResearchSprint | undefined = sprints.find((x) => x.id === selected) ?? sorted[0];
  const [newTask, setNewTask] = useState('');
  const [celebrate, setCelebrate] = useState<number | null>(null);

  let totalResearch = 0;
  log.forEach((v) => (totalResearch += v.research));
  const streak = researchStreak(sprints);
  const completed = sprints.filter((s) => s.status === 'completed').length;

  if (!sp) return null;
  const done = sp.tasks.filter((t) => t.done).length;
  const set = (patch: Partial<ResearchSprint>) => update(sp.id, patch);
  const latest = sorted[0];

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Research</h1>
          <p className="mt-1 text-[14px] text-muted">One sprint per week. Objective, experiments, results, next step.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => startFocus({ category: 'research', label: `Research · week ${sp.week}`, minutes: 90 })}>
            <Play className="h-4 w-4" /> Deep work
          </Button>
          {latest.status === 'completed' && (
            <Button variant="primary" onClick={() => setSelected(startNext())}>
              <Plus className="h-4 w-4" /> Start week {latest.week + 1}
            </Button>
          )}
        </div>
      </div>

      <div className="mb-6 grid grid-cols-3 gap-3">
        <Card className="p-4">
          <Stat label="Research streak" value={<span className="flex items-center gap-1.5">{streak}<Flame className="h-5 w-5 text-[#A58CFA]" /></span>} sub="weeks in a row" />
        </Card>
        <Card className="p-4">
          <Stat label="Sprints completed" value={completed} sub={`of ${sprints.length}`} />
        </Card>
        <Card className="p-4">
          <Stat label="Time logged" value={fmtDur(totalResearch)} sub="all time" />
        </Card>
      </div>

      <div className="mb-4 flex gap-1.5 overflow-x-auto no-scrollbar">
        {sorted.map((x) => (
          <button
            key={x.id}
            onClick={() => setSelected(x.id)}
            className={cn(
              'flex h-8 shrink-0 items-center gap-1.5 rounded-lg border px-3 text-[13px] font-medium transition-colors',
              x.id === sp.id ? 'border-line-strong bg-white/[0.08] text-fg' : 'border-line text-muted hover:text-fg',
            )}
          >
            {x.status === 'completed' && <Check className="h-3.5 w-3.5" style={{ color: VIOLET }} />}
            Week {x.week}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <Card className="space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <span className="label">Week {sp.week} objective</span>
              <Input
                value={sp.objective}
                onChange={(e) => set({ objective: e.target.value })}
                placeholder="What will be true at the end of this week?"
                className="mt-1.5 h-12 text-[16px] font-medium"
              />
            </div>
          </div>
          <p className="-mt-2 text-[12px] text-faint">Started {format(parseDay(sp.startDate), 'd MMMM')}</p>
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Experiments" value={sp.experiments} onChange={(v) => set({ experiments: v })} placeholder="What you ran, with what settings" />
            <Field label="Results" value={sp.results} onChange={(v) => set({ results: v })} placeholder="Numbers, plots, what changed" />
            <Field label="Code" value={sp.code} onChange={(v) => set({ code: v })} placeholder="Key snippets, commands, file paths" mono />
            <Field label="Notes" value={sp.notes} onChange={(v) => set({ notes: v })} placeholder="Papers read, ideas, questions for your supervisor" />
          </div>
          <label className="block">
            <span className="label">GitHub</span>
            <div className="mt-1.5 flex gap-2">
              <div className="relative flex-1">
                <Github className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
                <Input value={sp.githubUrl} onChange={(e) => set({ githubUrl: e.target.value })} placeholder="https://github.com/…" className="pl-9" />
              </div>
              {/^https?:\/\//.test(sp.githubUrl) && (
                <a href={sp.githubUrl} target="_blank" rel="noreferrer" className="grid h-10 w-10 place-items-center rounded-xl border border-line text-muted hover:text-fg" aria-label="Open repository">
                  <ExternalLink className="h-4 w-4" />
                </a>
              )}
            </div>
          </label>
          <label className="block">
            <span className="label">Next step</span>
            <Input value={sp.nextStep} onChange={(e) => set({ nextStep: e.target.value })} placeholder="Becomes next week’s objective" className="mt-1.5" />
          </label>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Tasks" action={<span className="text-[12.5px] tabular text-faint">{done}/{sp.tasks.length}</span>} />
            <Bar value={sp.status === 'completed' ? 100 : pct(done, sp.tasks.length)} color={VIOLET} className="mb-3" />
            <ul className="space-y-0.5">
              {sp.tasks.map((t) => (
                <li key={t.id} className="group flex items-center gap-1 rounded-lg">
                  <Checkbox checked={t.done} onChange={() => toggleTask(sp.id, t.id)} color={VIOLET} size={18} />
                  <span className={cn('flex-1 text-[13.5px]', t.done && 'text-faint line-through')}>{t.title}</span>
                  <button onClick={() => delTask(sp.id, t.id)} className="hidden p-1 text-faint hover:text-rose-300 group-hover:block" aria-label="Delete task">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
            <form
              className="mt-2 flex items-center gap-2 border-t border-line pt-3"
              onSubmit={(e) => {
                e.preventDefault();
                if (newTask.trim()) addTask(sp.id, newTask.trim());
                setNewTask('');
              }}
            >
              <Plus className="h-3.5 w-3.5 text-faint" />
              <input value={newTask} onChange={(e) => setNewTask(e.target.value)} placeholder="Add a task" className="h-7 flex-1 bg-transparent text-[13.5px] placeholder:text-faint focus:outline-none" />
            </form>
          </Card>

          {sp.status === 'active' ? (
            <Button
              variant="primary"
              size="lg"
              className="w-full"
              style={{ background: VIOLET }}
              onClick={() => {
                complete(sp.id);
                setCelebrate(sp.week);
              }}
            >
              <Check className="h-4 w-4" /> Complete sprint
            </Button>
          ) : (
            <div className="flex items-center justify-between rounded-2xl border border-line px-4 py-3">
              <span className="flex items-center gap-2 text-[13.5px] text-muted">
                <Check className="h-4 w-4" style={{ color: VIOLET }} /> Completed {sp.completedAt && format(new Date(sp.completedAt), 'd MMM')}
              </span>
              <Button size="sm" variant="ghost" onClick={() => reopen(sp.id)}>
                <RotateCcw className="h-3.5 w-3.5" /> Reopen
              </Button>
            </div>
          )}
        </div>
      </div>

      <SprintCompleted week={celebrate} onDone={() => setCelebrate(null)} />
    </div>
  );
}
