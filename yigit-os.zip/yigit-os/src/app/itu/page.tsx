'use client';

import { useMemo, useState } from 'react';
import { addDays, format, subDays } from 'date-fns';
import { CalendarCheck, Lightbulb, Plus, Trash2, Users } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { useLog } from '@/lib/hooks';
import { CATEGORIES } from '@/lib/categories';
import { dayKey, fmtDur, parseDay, todayKey } from '@/lib/date';
import { cn } from '@/lib/utils';
import { Button, Card, CardHeader, Checkbox, Empty, Input, Stat, Textarea } from '@/components/ui';

const SKY = CATEGORIES.itu.color;

export default function ItuPage() {
  const s = useStore();
  const openCreate = useUI((x) => x.openCreate);
  const log = useLog();
  const tk = todayKey();
  const [task, setTask] = useState('');
  const [learning, setLearning] = useState('');
  const [person, setPerson] = useState({ name: '', role: '', note: '' });

  let hours = 0;
  log.forEach((v) => (hours += v.itu));
  const attendedToday = s.itu.attendance.includes(tk);
  const upcoming = useMemo(() => {
    const until = dayKey(addDays(new Date(), 14));
    return s.tasks
      .filter((t) => t.category === 'itu' && !t.done && t.date >= tk && t.date <= until)
      .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start))
      .slice(0, 6);
  }, [s.tasks, tk]);

  const heat = Array.from({ length: 56 }, (_, i) => dayKey(subDays(new Date(), 55 - i)));

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">İTÜ Çekirdek</h1>
          <p className="mt-1 text-[14px] text-muted">Internship log: days, work, people, and what you learn.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => openCreate({ category: 'itu' })}>
            <Plus className="h-4 w-4" /> Schedule İTÜ work
          </Button>
          <Button variant={attendedToday ? 'secondary' : 'primary'} onClick={() => s.toggleAttendance(tk)}>
            <CalendarCheck className="h-4 w-4" /> {attendedToday ? 'Attended today' : 'Log today'}
          </Button>
        </div>
      </div>

      <div className="mb-6 grid grid-cols-3 gap-3">
        <Card className="p-4">
          <Stat label="Days attended" value={s.itu.attendance.length} />
        </Card>
        <Card className="p-4">
          <Stat label="Time logged" value={fmtDur(hours)} />
        </Card>
        <Card className="p-4">
          <Stat label="Tasks done" value={`${s.itu.tasks.filter((t) => t.done).length}/${s.itu.tasks.length}`} />
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Attendance, last 8 weeks" />
          <div className="grid grid-flow-col grid-rows-7 gap-1">
            {heat.map((k) => {
              const on = s.itu.attendance.includes(k);
              return (
                <button
                  key={k}
                  onClick={() => s.toggleAttendance(k)}
                  title={format(parseDay(k), 'EEE d MMM')}
                  className={cn('aspect-square rounded-[4px] transition-colors', on ? '' : 'bg-white/[0.04] hover:bg-white/[0.1]', k === tk && 'ring-1 ring-white/30')}
                  style={on ? { background: SKY } : undefined}
                />
              );
            })}
          </div>
          <p className="mt-3 text-[12px] text-faint">Click any day to mark or unmark it.</p>
        </Card>

        <Card>
          <CardHeader title="Upcoming work" />
          {upcoming.length ? (
            <ul className="space-y-1.5">
              {upcoming.map((t) => (
                <li key={t.id} className="flex items-center gap-3 rounded-xl border border-line bg-white/[0.02] px-3 py-2.5">
                  <span className="h-8 w-[3px] rounded-full" style={{ background: SKY }} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[14px] font-medium">{t.title}</div>
                    <div className="text-[12px] tabular text-faint">
                      {format(parseDay(t.date), 'EEE d MMM')} · {t.start}–{t.end}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="Nothing scheduled in the next two weeks" />
          )}
        </Card>

        <Card>
          <CardHeader title="Tasks" />
          <ul className="space-y-0.5">
            {s.itu.tasks.map((t) => (
              <li key={t.id} className="group flex items-center gap-1">
                <Checkbox checked={t.done} onChange={() => s.toggleItuTask(t.id)} color={SKY} size={18} />
                <span className={cn('flex-1 text-[13.5px]', t.done && 'text-faint line-through')}>{t.title}</span>
                <button onClick={() => s.deleteItuTask(t.id)} className="hidden p-1 text-faint hover:text-rose-300 group-hover:block" aria-label="Delete task">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
          <form
            className="mt-2 flex items-center gap-2 border-t border-line pt-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (task.trim()) s.addItuTask(task.trim());
              setTask('');
            }}
          >
            <Plus className="h-3.5 w-3.5 text-faint" />
            <input value={task} onChange={(e) => setTask(e.target.value)} placeholder="Add an internship task" className="h-7 flex-1 bg-transparent text-[13.5px] placeholder:text-faint focus:outline-none" />
          </form>
        </Card>

        <Card>
          <CardHeader title="People and mentors" icon={Users} />
          {s.itu.people.length > 0 && (
            <ul className="mb-4 divide-y divide-line">
              {s.itu.people.map((p) => (
                <li key={p.id} className="group flex items-start gap-3 py-2.5">
                  <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/[0.06] text-[12px] font-semibold">
                    {p.name
                      .split(' ')
                      .map((w) => w[0])
                      .join('')
                      .slice(0, 2)
                      .toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[14px] font-medium">{p.name}</div>
                    <div className="text-[12.5px] text-muted">{[p.role, p.note].filter(Boolean).join(' · ')}</div>
                  </div>
                  <button onClick={() => s.deletePerson(p.id)} className="hidden p-1 text-faint hover:text-rose-300 group-hover:block" aria-label="Remove person">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          )}
          <form
            className="grid grid-cols-2 gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!person.name.trim()) return;
              s.addPerson({ name: person.name.trim(), role: person.role.trim(), note: person.note.trim() });
              setPerson({ name: '', role: '', note: '' });
            }}
          >
            <Input value={person.name} onChange={(e) => setPerson({ ...person, name: e.target.value })} placeholder="Name" className="h-9" />
            <Input value={person.role} onChange={(e) => setPerson({ ...person, role: e.target.value })} placeholder="Role" className="h-9" />
            <Input value={person.note} onChange={(e) => setPerson({ ...person, note: e.target.value })} placeholder="Note (e.g. helps with Python)" className="col-span-2 h-9" />
            <Button type="submit" size="sm" className="col-span-2">
              Add person
            </Button>
          </form>
        </Card>

        <Card>
          <CardHeader title="Things learned" icon={Lightbulb} />
          <form
            className="mb-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (learning.trim()) s.addLearning(learning.trim());
              setLearning('');
            }}
          >
            <Input value={learning} onChange={(e) => setLearning(e.target.value)} placeholder="One sentence, while it’s fresh" className="h-9" />
            <Button type="submit" size="icon" aria-label="Add learning">
              <Plus className="h-4 w-4" />
            </Button>
          </form>
          <ul className="max-h-[260px] space-y-2 overflow-y-auto">
            {s.itu.learnings.map((l) => (
              <li key={l.id} className="group flex gap-3 text-[13.5px]">
                <span className="w-12 shrink-0 pt-px text-[12px] tabular text-faint">{format(parseDay(l.date), 'd MMM')}</span>
                <span className="flex-1 leading-relaxed">{l.text}</span>
                <button onClick={() => s.deleteLearning(l.id)} className="hidden self-start text-faint hover:text-rose-300 group-hover:block" aria-label="Delete">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader title="Notes" />
          <Textarea value={s.itu.notes} onChange={(e) => s.setItuNotes(e.target.value)} placeholder="Project details, links, meeting notes" className="min-h-[220px]" />
        </Card>
      </div>
    </div>
  );
}
