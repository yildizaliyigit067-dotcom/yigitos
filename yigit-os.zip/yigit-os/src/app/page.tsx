'use client';

import { useMemo } from 'react';
import Link from 'next/link';
import { format } from 'date-fns';
import { ArrowUpRight, Play, Plane } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useLog, useMaterialize, useNow } from '@/lib/hooks';
import { CATEGORIES } from '@/lib/categories';
import { daysUntil, parseDay, duration, fmtDur, nowMin, toMin, todayKey, weekKeys, weekStartOf } from '@/lib/date';
import { afsGroupPct, italianReadiness, schoolProgress, sumRange } from '@/lib/stats';
import { pct } from '@/lib/utils';
import { Timeline } from '@/components/timeline';
import { DueSoonCard } from '@/components/assignments';
import { Bar, Button, Card, CardHeader, Ring } from '@/components/ui';

const greeting = (h: number) => (h < 5 ? 'Good night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening');

export default function Overview() {
  const now = useNow(1000);
  const tk = todayKey();
  const keys = useMemo(() => weekKeys(weekStartOf(new Date())), []);
  useMaterialize(keys);

  const settings = useStore((s) => s.settings);
  const tasks = useStore((s) => s.tasks);
  const schoolTopics = useStore((s) => s.schoolTopics);
  const sprints = useStore((s) => s.sprints);
  const italian = useStore((s) => s.italian);
  const afs = useStore((s) => s.afs);
  const startFocus = useStore((s) => s.startFocus);
  const log = useLog();

  const today = tasks.filter((t) => t.date === tk).sort((a, b) => a.start.localeCompare(b.start));
  const countable = today;
  const planned = today.filter((t) => CATEGORIES[t.category].study).reduce((a, t) => a + duration(t.start, t.end), 0);
  const donePct = pct(countable.filter((t) => t.done).length, countable.length);

  const m = nowMin(now);
  const next = today.find((t) => !t.done && t.category !== 'class' && toMin(t.end) > m);
  const nextIsNow = next && toMin(next.start) <= m;

  const week = sumRange(log, keys[0], keys[6]);
  const goal = settings.weeklyItalianGoalMin;
  const school = schoolProgress(schoolTopics);
  const sprint = [...sprints].sort((a, b) => b.week - a.week)[0];
  const sprintDone = sprint?.tasks.filter((t) => t.done).length ?? 0;
  const afsDays = daysUntil(settings.afsDate);

  const readiness = [
    { label: 'Italian', value: italianReadiness(italian), color: CATEGORIES.italian.color },
    { label: 'School', value: school, color: CATEGORIES.school.color },
    { label: 'Documents', value: afsGroupPct(afs, 'documents'), color: '#C9CBD6' },
    { label: 'Preparation', value: afsGroupPct(afs, 'preparation'), color: '#C9CBD6' },
  ];

  return (
    <div>
      <header className="flex items-end justify-between gap-6">
        <div>
          <p className="text-[14px] text-muted">{format(now, 'EEEE, MMMM d')}</p>
          <h1 className="mt-1 text-[32px] font-semibold leading-[1.05] tracking-[-0.035em] sm:text-[44px] lg:text-[52px]">
            {greeting(now.getHours())}, {settings.name.split(' ')[0]}
            <span className="hidden sm:inline"> {settings.name.split(' ').slice(1).join(' ')}</span>
          </h1>
        </div>
        <div className="hidden text-right sm:block">
          <div className="text-[44px] font-extralight leading-none tracking-[-0.04em] tabular lg:text-[52px]">
            {format(now, 'HH:mm')}
            <span className="text-faint">:{format(now, 'ss')}</span>
          </div>
        </div>
      </header>

      <div className="mt-7 flex flex-wrap items-baseline gap-x-5 gap-y-1 text-[15px]">
        <span className="font-semibold text-fg">Today</span>
        <span className="text-muted">
          <span className="text-fg tabular">{countable.length}</span> tasks
        </span>
        <span className="text-muted">
          <span className="text-fg tabular">{fmtDur(planned)}</span> planned
        </span>
        <span className="text-muted">
          <span className="text-fg tabular">{Math.round(donePct)}%</span> done
        </span>
      </div>
      <Bar value={donePct} className="mt-3 h-1" />

      <section className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Link href="/italian" className="card group p-4 transition-colors hover:border-line-strong sm:p-5">
          <div className="flex items-center justify-between text-[13px] text-muted">
            Italian this week
            <ArrowUpRight className="h-3.5 w-3.5 text-faint opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
          <div className="mt-3 text-[26px] font-semibold tracking-[-0.03em] tabular sm:text-[30px]">{fmtDur(week.italian)}</div>
          <div className="mt-0.5 text-[12.5px] text-faint">of {fmtDur(goal)} goal</div>
          <Bar value={pct(week.italian, goal)} color={CATEGORIES.italian.color} className="mt-4" />
        </Link>

        <Link href="/school" className="card group flex items-center justify-between gap-3 p-4 transition-colors hover:border-line-strong sm:p-5">
          <div>
            <div className="text-[13px] text-muted">School catch-up</div>
            <div className="mt-3 text-[26px] font-semibold tracking-[-0.03em] tabular sm:text-[30px]">{Math.round(school)}%</div>
            <div className="mt-0.5 text-[12.5px] text-faint">
              {schoolTopics.filter((t) => t.status === 'completed').length}/{schoolTopics.length} topics
            </div>
          </div>
          <Ring value={school} size={56} color={CATEGORIES.school.color} className="hidden sm:block" />
        </Link>

        <Link href="/research" className="card group p-4 transition-colors hover:border-line-strong sm:p-5">
          <div className="text-[13px] text-muted">Research</div>
          <div className="mt-3 text-[26px] font-semibold tracking-[-0.03em] sm:text-[30px]">Week {sprint?.week ?? 1}</div>
          <div className="mt-0.5 flex items-center gap-1.5 text-[12.5px]">
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: sprint?.status === 'completed' ? '#3FCF8E' : CATEGORIES.research.color }}
            />
            <span className="text-faint">
              {sprint?.status === 'completed' ? 'Sprint completed' : `${sprintDone}/${sprint?.tasks.length ?? 0} tasks`}
            </span>
          </div>
          <Bar value={sprint?.status === 'completed' ? 100 : pct(sprintDone, sprint?.tasks.length ?? 0)} color={CATEGORIES.research.color} className="mt-4" />
        </Link>

        <Link href="/settings" className="card group relative overflow-hidden p-4 transition-colors hover:border-line-strong sm:p-5">
          <div className="flex items-center gap-1.5 text-[13px] text-muted">
            <Plane className="h-3.5 w-3.5" /> AFS departure
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-[40px] font-semibold leading-none tracking-[-0.05em] tabular sm:text-[48px]">{Math.max(0, afsDays)}</span>
            <span className="text-[13px] font-medium text-muted">days</span>
          </div>
          <div className="mt-1.5 text-[12.5px] text-faint">{format(parseDay(settings.afsDate), 'd MMMM yyyy')}</div>
        </Link>
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-[1fr_340px]">
        <Card className="p-3 sm:p-4">
          <CardHeader
            className="px-2 pt-1"
            title="Today’s timeline"
            action={
              <Link href="/today" className="text-[12.5px] text-faint hover:text-muted">
                Open Today
              </Link>
            }
          />
          <Timeline dateKey={tk} />
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title={nextIsNow ? 'Happening now' : 'Up next'} />
            {next ? (
              <>
                <div className="flex items-start gap-3">
                  <span className="mt-1 h-10 w-[3px] rounded-full" style={{ background: CATEGORIES[next.category].color }} />
                  <div className="min-w-0">
                    <p className="truncate text-[17px] font-semibold tracking-[-0.01em]">{next.title}</p>
                    <p className="mt-0.5 text-[13px] text-muted tabular">
                      {next.start}–{next.end}
                      {!nextIsNow && ` · in ${fmtDur(toMin(next.start) - m)}`}
                    </p>
                  </div>
                </div>
                <Button
                  variant="primary"
                  className="mt-5 w-full"
                  onClick={() =>
                    startFocus({
                      category: next.category,
                      label: next.title,
                      minutes: Math.min(90, Math.max(20, duration(next.start, next.end))),
                      taskId: next.id,
                    })
                  }
                >
                  <Play className="h-4 w-4" /> Start focus
                </Button>
              </>
            ) : (
              <p className="text-[14px] text-muted">Nothing left today. Tomorrow starts at {tasks.filter((t) => t.date > tk).sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start))[0]?.start ?? '—'}.</p>
            )}
          </Card>

          <DueSoonCard />

          <Card>
            <CardHeader title="AFS readiness" icon={Plane} />
            <div className="space-y-3.5">
              {readiness.map((r) => (
                <div key={r.label}>
                  <div className="mb-1.5 flex justify-between text-[13px]">
                    <span className="text-muted">{r.label}</span>
                    <span className="font-medium tabular">{Math.round(r.value)}%</span>
                  </div>
                  <Bar value={r.value} color={r.color} />
                </div>
              ))}
            </div>
          </Card>

          <p className="px-1 text-[12px] text-faint">
            {fmtDur(week.italian + week.school + week.research + week.itu)} logged this week. Press ⌘K for commands.
          </p>
        </div>
      </section>
    </div>
  );
}
