'use client';

import { useEffect, useRef, useState } from 'react';
import { addDays } from 'date-fns';
import { CalendarDays, Download, Plus, RotateCcw, Trash2, Upload } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { CATEGORIES, CATEGORY_ORDER } from '@/lib/categories';
import { toMin } from '@/lib/date';
import type { AfsItem, Category } from '@/lib/types';
import { cn } from '@/lib/utils';
import { GoogleCalendarProvider } from '@/lib/calendar/google';
import { eventToTask } from '@/lib/calendar/sync';
import { getGoogleAccessToken, getSupabase, isSupabaseConfigured, signInWithGoogle, signOut } from '@/lib/supabase/client';
import { Button, Card, CardHeader, Checkbox, Input } from '@/components/ui';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function AfsGroup({ group, title }: { group: AfsItem['group']; title: string }) {
  const items = useStore((s) => s.afs).filter((i) => i.group === group);
  const toggle = useStore((s) => s.toggleAfs);
  const del = useStore((s) => s.deleteAfs);
  const add = useStore((s) => s.addAfs);
  const [text, setText] = useState('');
  return (
    <div>
      <div className="mb-2 flex justify-between text-[13px]">
        <span className="font-medium">{title}</span>
        <span className="tabular text-faint">
          {items.filter((i) => i.done).length}/{items.length}
        </span>
      </div>
      <ul className="space-y-0.5">
        {items.map((i) => (
          <li key={i.id} className="group flex items-center gap-1">
            <Checkbox checked={i.done} onChange={() => toggle(i.id)} size={17} />
            <span className={cn('flex-1 text-[13.5px]', i.done && 'text-faint line-through')}>{i.title}</span>
            <button onClick={() => del(i.id)} className="hidden p-1 text-faint hover:text-rose-300 group-hover:block" aria-label="Delete">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </li>
        ))}
      </ul>
      <form
        className="mt-1 flex items-center gap-2 pl-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (text.trim()) add(group, text.trim());
          setText('');
        }}
      >
        <Plus className="h-3.5 w-3.5 text-faint" />
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Add item" className="h-8 flex-1 bg-transparent text-[13px] placeholder:text-faint focus:outline-none" />
      </form>
    </div>
  );
}

function TemplateEditor() {
  const template = useStore((s) => s.template);
  const update = useStore((s) => s.updateTemplateBlock);
  const del = useStore((s) => s.deleteTemplateBlock);
  const add = useStore((s) => s.addTemplateBlock);
  const apply = useStore((s) => s.applyTemplateFromToday);
  const toast = useUI((s) => s.toast);
  const [day, setDay] = useState(0);
  const blocks = template.filter((b) => b.weekday === day).sort((a, b) => a.start.localeCompare(b.start));

  return (
    <Card>
      <CardHeader
        title="Weekly base program"
        action={
          <Button
            size="sm"
            onClick={() => {
              if (!confirm('Rebuild the planner from today using this program? Unfinished blocks from the old program will be replaced; your own tasks stay.')) return;
              apply();
              toast('Planner rebuilt from today');
            }}
          >
            <RotateCcw className="h-3.5 w-3.5" /> Apply from today
          </Button>
        }
      />
      <div className="mb-4 flex gap-1 overflow-x-auto no-scrollbar">
        {DAYS.map((d, i) => (
          <button
            key={d}
            onClick={() => setDay(i)}
            className={cn('h-8 shrink-0 rounded-lg px-3 text-[13px] font-medium', day === i ? 'bg-white/[0.08] text-fg' : 'text-muted hover:text-fg')}
          >
            {d.slice(0, 3)}
          </button>
        ))}
      </div>
      <ul className="space-y-2">
        {blocks.map((b) => (
          <li key={b.id} className="grid grid-cols-[1fr_auto] items-center gap-2 rounded-xl border border-line bg-white/[0.015] p-2 sm:grid-cols-[84px_84px_1fr_150px_auto]">
            <input
              type="time"
              value={b.start}
              onChange={(e) => toMin(e.target.value) < toMin(b.end) && update(b.id, { start: e.target.value })}
              className="field h-9 px-2"
              aria-label="Start"
            />
            <input
              type="time"
              value={b.end}
              onChange={(e) => toMin(e.target.value) > toMin(b.start) && update(b.id, { end: e.target.value })}
              className="field h-9 px-2"
              aria-label="End"
            />
            <input value={b.title} onChange={(e) => update(b.id, { title: e.target.value })} className="field col-span-2 h-9 sm:col-span-1" aria-label="Title" />
            <select value={b.category} onChange={(e) => update(b.id, { category: e.target.value as Category })} className="field h-9 px-2" aria-label="Category">
              {CATEGORY_ORDER.map((c) => (
                <option key={c} value={c} className="bg-bg-card">
                  {CATEGORIES[c].label}
                </option>
              ))}
            </select>
            <Button size="icon" variant="danger" onClick={() => del(b.id)} aria-label="Delete block">
              <Trash2 className="h-4 w-4" />
            </Button>
          </li>
        ))}
      </ul>
      <Button
        size="sm"
        variant="ghost"
        className="mt-2"
        onClick={() => add({ weekday: day, start: '18:00', end: '18:45', title: 'New block', category: 'school' })}
      >
        <Plus className="h-3.5 w-3.5" /> Add block to {DAYS[day]}
      </Button>
    </Card>
  );
}

function Integrations() {
  const configured = isSupabaseConfigured();
  const mergeExternal = useStore((s) => s.mergeExternal);
  const toast = useUI((s) => s.toast);
  const [email, setEmail] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const sb = getSupabase();
    if (!sb) return;
    sb.auth.getSession().then(({ data }) => setEmail(data.session?.user.email ?? null));
    const { data } = sb.auth.onAuthStateChange((_e, session) => setEmail(session?.user.email ?? null));
    return () => data.subscription.unsubscribe();
  }, []);

  const importEvents = async () => {
    setBusy(true);
    setError('');
    try {
      const token = await getGoogleAccessToken();
      if (!token) throw new Error('Google access has expired. Connect again to refresh it.');
      const provider = new GoogleCalendarProvider(token);
      const events = await provider.listEvents(new Date(), addDays(new Date(), 21));
      const inputs = events.map(eventToTask).filter((x): x is NonNullable<typeof x> => !!x);
      const n = mergeExternal(inputs);
      toast(`${n} events imported from Google Calendar`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Import failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader title="Google Calendar" icon={CalendarDays} />
      {!configured ? (
        <div className="text-[13.5px] leading-relaxed text-muted">
          Everything works on this device right now. To pull in Google Calendar events and use an account, add your Supabase keys
          as environment variables in Vercel (see README). This button switches on automatically after that.
        </div>
      ) : email ? (
        <div className="space-y-3">
          <p className="text-[13.5px] text-muted">
            Signed in as <span className="text-fg">{email}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            <Button variant="primary" onClick={importEvents} disabled={busy}>
              {busy ? 'Importing…' : 'Import next 3 weeks'}
            </Button>
            <Button variant="ghost" onClick={() => signOut()}>
              Sign out
            </Button>
          </div>
        </div>
      ) : (
        <Button variant="primary" onClick={() => signInWithGoogle().catch((e) => setError(String(e.message ?? e)))}>
          Connect Google Calendar
        </Button>
      )}
      {error && <p className="mt-3 text-[13px] text-rose-300">{error}</p>}
    </Card>
  );
}

export default function SettingsPage() {
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const exportData = useStore((s) => s.exportData);
  const importData = useStore((s) => s.importData);
  const resetAll = useStore((s) => s.resetAll);
  const toast = useUI((s) => s.toast);
  const fileRef = useRef<HTMLInputElement>(null);

  const download = () => {
    const blob = new Blob([exportData()], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `yigit-os-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Settings</h1>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Profile and goals" />
          <div className="space-y-4">
            <label className="block space-y-1.5">
              <span className="label">Name</span>
              <Input value={settings.name} onChange={(e) => updateSettings({ name: e.target.value })} />
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label className="block space-y-1.5">
                <span className="label">AFS departure</span>
                <Input type="date" value={settings.afsDate} onChange={(e) => e.target.value && updateSettings({ afsDate: e.target.value })} />
              </label>
              <label className="block space-y-1.5">
                <span className="label">Weekly Italian goal (hours)</span>
                <Input
                  type="number"
                  min={1}
                  max={40}
                  value={Math.round(settings.weeklyItalianGoalMin / 6) / 10}
                  onChange={(e) => {
                    const h = Number(e.target.value);
                    if (h > 0) updateSettings({ weeklyItalianGoalMin: Math.round(h * 60) });
                  }}
                />
              </label>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader title="AFS checklist" />
          <div className="grid gap-6 sm:grid-cols-2">
            <AfsGroup group="documents" title="Documents" />
            <AfsGroup group="preparation" title="Preparation" />
          </div>
        </Card>

        <div className="lg:col-span-2">
          <TemplateEditor />
        </div>

        <Integrations />

        <Card>
          <CardHeader title="Your data" />
          <p className="mb-4 text-[13.5px] leading-relaxed text-muted">
            Data is saved in this browser. Export a backup now and then, and import it to move to another device.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button onClick={download}>
              <Download className="h-4 w-4" /> Export backup
            </Button>
            <Button onClick={() => fileRef.current?.click()}>
              <Upload className="h-4 w-4" /> Import backup
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                if (confirm('Erase all data on this device and start over? Export a backup first if you might need it.')) {
                  resetAll();
                  toast('All data erased');
                }
              }}
            >
              <Trash2 className="h-4 w-4" /> Erase all data
            </Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                importData(await f.text());
                toast('Backup imported');
              } catch (err) {
                alert(err instanceof Error ? err.message : 'Import failed.');
              }
              e.target.value = '';
            }}
          />
        </Card>
      </div>
    </div>
  );
}
