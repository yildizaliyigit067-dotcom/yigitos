'use client';

import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from 'react';
import { addWeeks, format, isSameMonth } from 'date-fns';
import { ChevronLeft, ChevronRight, GripVertical } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { useMaterialize, useNow } from '@/lib/hooks';
import { BUCKETS, CATEGORIES, bucketOf, withAlpha } from '@/lib/categories';
import { dayKey, duration, fmtDur, fromMin, nowMin, toMin, todayKey, weekDays, weekStartOf } from '@/lib/date';
import type { Task } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui';
import Link from 'next/link';
import { isDone, visibleAssignments } from '@/lib/classroom/helpers';

const START_H = 7;
const END_H = 23;
const PX = 0.95; // pixels per minute
const SNAP = 15;
const HEIGHT = (END_H - START_H) * 60 * PX;

function layoutDay(tasks: Task[]) {
  const sorted = [...tasks].sort((a, b) => a.start.localeCompare(b.start));
  const out = new Map<string, { lane: number; lanes: number }>();
  let cluster: Task[] = [];
  let lanesEnd: number[] = [];
  let clusterEnd = -1;
  const flush = () => {
    for (const t of cluster) out.get(t.id)!.lanes = lanesEnd.length;
    cluster = [];
    lanesEnd = [];
  };
  for (const t of sorted) {
    const s = toMin(t.start);
    const e = Math.max(toMin(t.end), s + 20);
    if (cluster.length && s >= clusterEnd) flush();
    let lane = lanesEnd.findIndex((le) => le <= s);
    if (lane === -1) {
      lane = lanesEnd.length;
      lanesEnd.push(e);
    } else lanesEnd[lane] = e;
    out.set(t.id, { lane, lanes: 1 });
    cluster.push(t);
    clusterEnd = Math.max(clusterEnd, e);
  }
  flush();
  return out;
}

function EventBlock({
  task,
  colWidth,
  lane,
  lanes,
}: {
  task: Task;
  colWidth: number;
  lane: number;
  lanes: number;
}) {
  const moveTask = useStore((s) => s.moveTask);
  const openEdit = useUI((s) => s.openEdit);
  const start = useRef<{ x: number; y: number } | null>(null);
  const [delta, setDelta] = useState<{ day: number; min: number } | null>(null);
  const moved = useRef(false);

  const cat = CATEGORIES[task.category];
  const top = Math.max(0, (toMin(task.start) - START_H * 60) * PX);
  const height = Math.max(22, duration(task.start, task.end) * PX - 2);
  const compact = height < 44;

  const onDown = (e: RPointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    start.current = { x: e.clientX, y: e.clientY };
    moved.current = false;
  };
  const onMove = (e: RPointerEvent<HTMLDivElement>) => {
    if (!start.current) return;
    const dx = e.clientX - start.current.x;
    const dy = e.clientY - start.current.y;
    if (!moved.current && Math.hypot(dx, dy) < 5) return;
    moved.current = true;
    setDelta({ day: colWidth ? Math.round(dx / colWidth) : 0, min: Math.round(dy / PX / SNAP) * SNAP });
  };
  const onUp = () => {
    if (!start.current) return;
    start.current = null;
    if (!moved.current) openEdit(task.id);
    else if (delta && (delta.day || delta.min)) moveTask(task.id, delta.day, delta.min);
    setDelta(null);
  };

  const previewStart = delta ? fromMin(toMin(task.start) + delta.min) : task.start;
  const previewEnd = delta ? fromMin(toMin(task.end) + delta.min) : task.end;

  return (
    <div
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={() => {
        start.current = null;
        setDelta(null);
      }}
      className={cn(
        'group absolute cursor-grab touch-none select-none overflow-hidden rounded-[9px] border-l-2 px-2 py-1 text-left transition-[box-shadow,opacity]',
        delta ? 'z-30 cursor-grabbing shadow-2xl ring-1 ring-white/20' : 'z-10 hover:z-20 hover:ring-1 hover:ring-white/10',
        task.done && !delta && 'opacity-45',
      )}
      style={{
        top,
        height,
        left: `calc(${(lane / lanes) * 100}% + 3px)`,
        width: `calc(${100 / lanes}% - 6px)`,
        background: withAlpha(cat.color, task.category === 'class' ? 0.08 : 0.15),
        borderColor: cat.color,
        transform: delta ? `translate(${delta.day * colWidth}px, ${delta.min * PX}px)` : undefined,
      }}
    >
      <div className={cn('flex items-start gap-1', compact && 'items-center')}>
        <div className="min-w-0 flex-1">
          <div className={cn('truncate text-[12px] font-semibold leading-tight text-fg', task.done && 'line-through')}>{task.title}</div>
          {!compact && (
            <div className="mt-0.5 truncate text-[11px] tabular text-muted">
              {previewStart}–{previewEnd}
            </div>
          )}
        </div>
        <GripVertical className="mt-0.5 hidden h-3 w-3 shrink-0 text-white/30 group-hover:block" />
      </div>
    </div>
  );
}

export default function PlannerPage() {
  const [anchor, setAnchor] = useState(() => weekStartOf(new Date()));
  const days = useMemo(() => weekDays(anchor), [anchor]);
  const keys = useMemo(() => days.map(dayKey), [days]);
  useMaterialize(keys);
  const tasks = useStore((s) => s.tasks);
  const classroom = useStore((s) => s.classroom);
  const openCreate = useUI((s) => s.openCreate);
  const now = useNow(60_000);
  const tk = todayKey();

  const gridRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [colWidth, setColWidth] = useState(0);
  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setColWidth(el.clientWidth / 7));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = Math.max(0, (Math.min(nowMin(), 17 * 60) - START_H * 60 - 120) * PX);
  }, []);

  const byDay = useMemo(() => {
    const map = new Map<string, Task[]>();
    for (const k of keys) map.set(k, []);
    for (const t of tasks) map.get(t.date)?.push(t);
    return map;
  }, [tasks, keys]);

  const plannedByBucket = useMemo(() => {
    const out: Record<string, number> = { italian: 0, school: 0, research: 0, itu: 0 };
    for (const k of keys)
      for (const t of byDay.get(k) ?? []) {
        const b = bucketOf(t.category);
        if (b) out[b] += duration(t.start, t.end);
      }
    return out;
  }, [byDay, keys]);

  const dueByDay = useMemo(() => {
    const m = new Map<string, number>();
    for (const a of visibleAssignments(classroom)) {
      if (!a.due || isDone(a)) continue;
      const k = a.due.slice(0, 10);
      m.set(k, (m.get(k) ?? 0) + 1);
    }
    return m;
  }, [classroom]);

  const label = isSameMonth(days[0], days[6])
    ? `${format(days[0], 'd')}–${format(days[6], 'd MMMM yyyy')}`
    : `${format(days[0], 'd MMM')} – ${format(days[6], 'd MMM yyyy')}`;

  const onColumnClick = (key: string, e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target !== e.currentTarget) return;
    const y = e.nativeEvent.offsetY;
    const start = START_H * 60 + Math.floor(y / PX / 30) * 30;
    openCreate({ date: key, start: fromMin(start), end: fromMin(start + 45) });
  };

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Planner</h1>
          <p className="mt-1 text-[14px] text-muted">{label}</p>
        </div>
        <div className="flex items-center gap-1.5">
          <Button size="icon" variant="ghost" onClick={() => setAnchor((a) => addWeeks(a, -1))} aria-label="Previous week">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button size="sm" onClick={() => setAnchor(weekStartOf(new Date()))}>
            This week
          </Button>
          <Button size="icon" variant="ghost" onClick={() => setAnchor((a) => addWeeks(a, 1))} aria-label="Next week">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-x-5 gap-y-2 text-[12.5px]">
        {BUCKETS.map((b) => (
          <span key={b.key} className="flex items-center gap-2 text-muted">
            <span className="h-2 w-2 rounded-sm" style={{ background: b.color }} />
            {b.label}
            <span className="tabular text-fg">{fmtDur(plannedByBucket[b.key])}</span>
          </span>
        ))}
        <span className="text-faint">Drag blocks to move them · click empty space to add</span>
      </div>

      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <div className="min-w-[780px]">
            <div className="grid grid-cols-[52px_1fr] border-b border-line">
              <div />
              <div className="grid grid-cols-7">
                {days.map((d, i) => {
                  const isToday = keys[i] === tk;
                  return (
                    <div key={keys[i]} className="border-l border-line px-2.5 py-3">
                      <div className={cn('text-[12px] font-medium', isToday ? 'text-accent' : 'text-faint')}>{format(d, 'EEE')}</div>
                      <div
                        className={cn(
                          'mt-0.5 inline-grid h-7 min-w-7 place-items-center rounded-full text-[17px] font-semibold tabular',
                          isToday && 'bg-accent px-1.5 text-white',
                        )}
                      >
                        {format(d, 'd')}
                      </div>
                      {dueByDay.get(keys[i]) ? (
                        <Link href="/classroom" className="ml-2 align-middle text-[11.5px] font-medium text-[#F0B04A] hover:underline">
                          {dueByDay.get(keys[i])} due
                        </Link>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            </div>

            <div ref={scrollRef} className="max-h-[calc(100dvh-280px)] min-h-[420px] overflow-y-auto">
              <div className="grid grid-cols-[52px_1fr]" style={{ height: HEIGHT }}>
                <div className="relative">
                  {Array.from({ length: END_H - START_H }, (_, i) => (
                    <span key={i} className="absolute right-2 -translate-y-1/2 text-[11px] text-faint tabular" style={{ top: i * 60 * PX }}>
                      {i === 0 ? '' : `${String(START_H + i).padStart(2, '0')}:00`}
                    </span>
                  ))}
                </div>
                <div ref={gridRef} className="relative grid grid-cols-7">
                  {keys.map((k) => {
                    const list = byDay.get(k) ?? [];
                    const lay = layoutDay(list);
                    const isToday = k === tk;
                    return (
                      <div
                        key={k}
                        onClick={(e) => onColumnClick(k, e)}
                        className={cn('relative border-l border-line', isToday && 'bg-accent/[0.035]')}
                        style={{
                          backgroundImage: `repeating-linear-gradient(to bottom, rgba(255,255,255,0.045) 0, rgba(255,255,255,0.045) 1px, transparent 1px, transparent ${60 * PX}px)`,
                        }}
                      >
                        {list.map((t) => {
                          const l = lay.get(t.id)!;
                          return <EventBlock key={t.id} task={t} colWidth={colWidth} lane={l.lane} lanes={l.lanes} />;
                        })}
                        {isToday && nowMin(now) >= START_H * 60 && nowMin(now) <= END_H * 60 && (
                          <div className="pointer-events-none absolute inset-x-0 z-20" style={{ top: (nowMin(now) - START_H * 60) * PX }}>
                            <div className="relative h-px bg-accent">
                              <span className="absolute -left-1 -top-[3px] h-[7px] w-[7px] rounded-full bg-accent" />
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
