'use client';

import { useMemo, useState } from 'react';
import { addDays, format } from 'date-fns';
import { ChevronLeft, ChevronRight, Play, Plus } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { useMaterialize, useNow } from '@/lib/hooks';
import { CATEGORIES } from '@/lib/categories';
import { dayKey, duration, fmtDur, nowMin, parseDay, toMin, todayKey } from '@/lib/date';
import { pct } from '@/lib/utils';
import { Timeline } from '@/components/timeline';
import { DueSoonCard } from '@/components/assignments';
import { Bar, Button, Card, Ring } from '@/components/ui';

export default function TodayPage() {
  const [key, setKey] = useState(todayKey());
  const date = parseDay(key);
  const isToday = key === todayKey();
  const keys = useMemo(() => [key], [key]);
  useMaterialize(keys);
  const now = useNow(30_000);

  const tasks = useStore((s) => s.tasks);
  const sessions = useStore((s) => s.focusSessions);
  const startFocus = useStore((s) => s.startFocus);
  const openCreate = useUI((s) => s.openCreate);
  const [hideClass, setHideClass] = useState(false);

  const day = tasks.filter((t) => t.date === key && t.category !== 'class');
  const planned = day.filter((t) => CATEGORIES[t.category].study).reduce((a, t) => a + duration(t.start, t.end), 0);
  const doneCount = day.filter((t) => t.done).length;
  const focused = sessions.filter((s) => s.date === key).reduce((a, s) => a + s.minutes, 0);
  const m = nowMin(now);
  const next = [...day]
    .sort((a, b) => a.start.localeCompare(b.start))
    .find((t) => !t.done && CATEGORIES[t.category].study && (!isToday || toMin(t.end) > m));

  const shift = (n: number) => setKey(dayKey(addDays(date, n)));

  return (
    <div>
      <div className="mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-1">
            <Button size="icon-sm" variant="ghost" onClick={() => shift(-1)} aria-label="Previous day">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="ghost" onClick={() => shift(1)} aria-label="Next day">
              <ChevronRight className="h-4 w-4" />
            </Button>
            {!isToday && (
              <button onClick={() => setKey(todayKey())} className="ml-1 text-[13px] text-accent hover:underline">
                Back to today
              </button>
            )}
          </div>
          <h1 className="mt-2 text-[30px] font-semibold tracking-[-0.03em] md:text-[38px]">
            {isToday ? 'Today' : format(date, 'EEEE')}
            <span className="ml-3 font-normal text-faint">{format(date, 'd MMMM')}</span>
          </h1>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => openCreate({ date: key })}>
            <Plus className="h-4 w-4" /> Add
          </Button>
          <Button
            variant="primary"
            disabled={!next}
            onClick={() =>
              next
                ? startFocus({ category: next.category, label: next.title, minutes: Math.min(90, Math.max(20, duration(next.start, next.end))), taskId: next.id })
                : undefined
            }
          >
            <Play className="h-4 w-4" /> Start focus
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
        <Card className="p-3 sm:p-4">
          <div className="mb-2 flex items-center justify-between px-2 pt-1">
            <span className="text-[13px] font-medium text-muted">Timeline</span>
            <button onClick={() => setHideClass((v) => !v)} className="text-[12.5px] text-faint hover:text-muted">
              {hideClass ? 'Show school hours' : 'Hide school hours'}
            </button>
          </div>
          <Timeline dateKey={key} hideClass={hideClass} />
        </Card>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-1 lg:content-start">
          <Card className="flex items-center gap-4 p-4">
            <Ring value={pct(doneCount, day.length)} size={60}>
              <span className="text-[13px] font-semibold tabular">{Math.round(pct(doneCount, day.length))}%</span>
            </Ring>
            <div>
              <div className="text-[13px] text-muted">Completed</div>
              <div className="text-[18px] font-semibold tabular">
                {doneCount}
                <span className="text-faint">/{day.length}</span>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="text-[13px] text-muted">Planned study</div>
            <div className="mt-1 text-[22px] font-semibold tabular tracking-[-0.02em]">{fmtDur(planned)}</div>
            <div className="mt-3 text-[13px] text-muted">Focused</div>
            <div className="mt-1 text-[22px] font-semibold tabular tracking-[-0.02em]">{fmtDur(focused)}</div>
            <Bar value={pct(focused, planned)} className="mt-3" />
          </Card>
          <div className="col-span-2 lg:col-span-1">
            <DueSoonCard dateKey={key} title={isToday ? 'Due today' : 'Due this day'} />
          </div>
          {next && (
            <Card className="col-span-2 p-4 lg:col-span-1">
              <div className="text-[13px] text-muted">{isToday && toMin(next.start) <= m ? 'Now' : 'Next'}</div>
              <div className="mt-1 truncate text-[15px] font-semibold">{next.title}</div>
              <div className="text-[13px] text-faint tabular">
                {next.start}–{next.end}
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
