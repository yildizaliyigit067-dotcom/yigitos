'use client';

import { useMemo, useState } from 'react';
import { differenceInCalendarDays, formatDistanceToNow, parseISO } from 'date-fns';
import { ClipboardList, Copy, Eye, EyeOff, LogOut, RefreshCw, ShieldAlert } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { ClassroomError, classroomClientId, isClassroomConfigured } from '@/lib/classroom/api';
import { disconnectClassroom, syncClassroom } from '@/lib/classroom/sync';
import { guessSubject, isDone, isOverdue, visibleAssignments } from '@/lib/classroom/helpers';
import { SUBJECTS } from '@/lib/seed';
import type { ClassroomAssignment, Subject } from '@/lib/types';
import { cn } from '@/lib/utils';
import { AssignmentRow } from '@/components/assignments';
import { Button, Card, CardHeader, Empty, Segmented, Stat } from '@/components/ui';

type Filter = 'upcoming' | 'missing' | 'nodue' | 'done';

function groupUpcoming(list: ClassroomAssignment[]) {
  const now = new Date();
  const groups: { label: string; items: ClassroomAssignment[] }[] = [
    { label: 'Today', items: [] },
    { label: 'Tomorrow', items: [] },
    { label: 'This week', items: [] },
    { label: 'Later', items: [] },
  ];
  for (const a of list) {
    const d = differenceInCalendarDays(parseISO(a.due!), now);
    groups[d <= 0 ? 0 : d === 1 ? 1 : d < 7 ? 2 : 3].items.push(a);
  }
  return groups.filter((g) => g.items.length);
}

function SetupCard() {
  return (
    <Card className="max-w-2xl">
      <CardHeader title="One-time setup" icon={ClipboardList} />
      <ol className="list-decimal space-y-2.5 pl-5 text-[13.5px] leading-relaxed text-muted marker:text-faint">
        <li>
          In Google Cloud Console create a project and enable the <span className="text-fg">Google Classroom API</span>.
        </li>
        <li>
          OAuth consent screen: <span className="text-fg">External</span>, status <span className="text-fg">Testing</span>, add your school email as a test user.
        </li>
        <li>
          Credentials → OAuth client ID → <span className="text-fg">Web application</span>. Authorized JavaScript origins: your Vercel URL and
          http://localhost:3000.
        </li>
        <li>
          In Vercel add the environment variable <code className="rounded bg-white/[0.06] px-1.5 py-0.5 text-[12.5px] text-fg">NEXT_PUBLIC_GOOGLE_CLIENT_ID</code> and redeploy.
        </li>
      </ol>
      <p className="mt-4 text-[12.5px] text-faint">Full steps are in the README. This page switches to the connect button once the ID is set.</p>
    </Card>
  );
}

function BlockedHelp() {
  const toast = useUI((s) => s.toast);
  const id = classroomClientId();
  const message = `Hello, I built a personal study planner that reads my own Google Classroom assignments (read-only: classroom.courses.readonly and classroom.coursework.me.readonly). Could you allow this OAuth app for my account in Admin console → Security → API controls → App access control? Client ID: ${id}`;
  return (
    <Card className="border-rose-400/20">
      <CardHeader title="Your school is blocking the connection" icon={ShieldAlert} />
      <p className="text-[13.5px] leading-relaxed text-muted">
        Google Workspace for Education blocks outside apps for student accounts unless the school’s admin allows them. Send this to your school’s IT team;
        once they mark the app as trusted, connecting will work.
      </p>
      <div className="mt-3 rounded-xl border border-line bg-white/[0.02] p-3 text-[12.5px] leading-relaxed text-muted">{message}</div>
      <Button
        size="sm"
        className="mt-3"
        onClick={() => {
          navigator.clipboard?.writeText(message);
          toast('Message copied');
        }}
      >
        <Copy className="h-3.5 w-3.5" /> Copy message
      </Button>
    </Card>
  );
}

export default function ClassroomPage() {
  const classroom = useStore((s) => s.classroom);
  const setCourseSubject = useStore((s) => s.setCourseSubject);
  const toggleHidden = useStore((s) => s.toggleCourseHidden);
  const toast = useUI((s) => s.toast);
  const [filter, setFilter] = useState<Filter>('upcoming');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ClassroomError | null>(null);

  const sync = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await syncClassroom(true);
      if (r) toast(`${r.count} assignments synced`);
    } catch (e) {
      setError(e instanceof ClassroomError ? e : new ClassroomError('Sync failed.'));
    } finally {
      setBusy(false);
    }
  };

  const visible = useMemo(() => visibleAssignments(classroom), [classroom]);
  const now = new Date();
  const upcoming = visible.filter((a) => !isDone(a) && a.due && !isOverdue(a, now)).sort((a, b) => a.due!.localeCompare(b.due!));
  const missing = visible.filter((a) => isOverdue(a, now)).sort((a, b) => b.due!.localeCompare(a.due!));
  const noDue = visible.filter((a) => !isDone(a) && !a.due).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const done = visible.filter(isDone).sort((a, b) => (b.due ?? b.updatedAt).localeCompare(a.due ?? a.updatedAt)).slice(0, 40);
  const dueWeek = upcoming.filter((a) => differenceInCalendarDays(parseISO(a.due!), now) < 7).length;

  const courses = useMemo(() => {
    const m = new Map<string, string>();
    for (const a of classroom.assignments) m.set(a.courseId, a.courseName);
    return [...m.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  }, [classroom.assignments]);

  const configured = isClassroomConfigured();
  const lists: Record<Filter, ClassroomAssignment[]> = { upcoming, missing, nodue: noDue, done };

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Classroom</h1>
          <p className="mt-1 text-[14px] text-muted">
            {classroom.connected
              ? `${classroom.email ?? 'School account'} · synced ${classroom.lastSyncAt ? formatDistanceToNow(new Date(classroom.lastSyncAt), { addSuffix: true }) : 'never'}`
              : 'Assignments from your school Google Classroom, next to everything else.'}
          </p>
        </div>
        {configured && classroom.connected && (
          <div className="flex gap-2">
            <Button
              variant="ghost"
              onClick={() => {
                if (confirm('Disconnect Google Classroom? Synced assignments will be removed from this device.')) disconnectClassroom();
              }}
            >
              <LogOut className="h-4 w-4" /> Disconnect
            </Button>
            <Button variant="primary" onClick={sync} disabled={busy}>
              <RefreshCw className={cn('h-4 w-4', busy && 'animate-spin')} /> {busy ? 'Syncing…' : 'Sync'}
            </Button>
          </div>
        )}
      </div>

      {!configured && <SetupCard />}

      {configured && !classroom.connected && (
        <Card className="max-w-2xl p-6 sm:p-8">
          <ClipboardList className="h-6 w-6 text-accent" />
          <h2 className="mt-4 text-[20px] font-semibold tracking-[-0.02em]">Connect your school account</h2>
          <p className="mt-2 text-[14px] leading-relaxed text-muted">
            Choose your school email in the Google window. YİĞİT OS only reads your classes, assignments, due dates and grades. It never turns in or changes
            anything.
          </p>
          <Button variant="primary" size="lg" className="mt-6" onClick={sync} disabled={busy}>
            {busy ? 'Connecting…' : 'Connect Google Classroom'}
          </Button>
        </Card>
      )}

      {error && (
        <div className="mt-4 space-y-4">
          <Card className="border-rose-400/20 p-4 text-[13.5px] text-rose-200">{error.message}</Card>
          {error.kind === 'blocked' && <BlockedHelp />}
        </div>
      )}

      {classroom.connected && (
        <>
          <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
            <Card className="p-4">
              <Stat label="Due this week" value={dueWeek} />
            </Card>
            <Card className="p-4">
              <Stat label="Missing" value={<span className={missing.length ? 'text-rose-300' : ''}>{missing.length}</span>} />
            </Card>
            <Card className="p-4">
              <Stat label="No due date" value={noDue.length} />
            </Card>
            <Card className="p-4">
              <Stat label="Courses" value={courses.length} />
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
            <Card className="min-w-0 p-3 sm:p-4">
              <div className="mb-3 overflow-x-auto px-1 no-scrollbar">
                <Segmented
                  id="classroom-filter"
                  value={filter}
                  onChange={setFilter}
                  options={[
                    { value: 'upcoming', label: `Upcoming ${upcoming.length || ''}` },
                    { value: 'missing', label: `Missing ${missing.length || ''}` },
                    { value: 'nodue', label: 'No due date' },
                    { value: 'done', label: 'Done' },
                  ]}
                />
              </div>
              {lists[filter].length === 0 ? (
                <Empty
                  title={
                    filter === 'upcoming'
                      ? 'Nothing coming up'
                      : filter === 'missing'
                        ? 'Nothing missing'
                        : filter === 'nodue'
                          ? 'Every open assignment has a due date'
                          : 'Nothing finished yet'
                  }
                  hint={filter === 'upcoming' ? 'Sync again after your teachers post new work.' : undefined}
                />
              ) : filter === 'upcoming' ? (
                groupUpcoming(upcoming).map((g) => (
                  <div key={g.label} className="mb-3 last:mb-0">
                    <p className="px-2 pb-1 pt-2 text-[12px] font-medium text-faint">{g.label}</p>
                    <ul>
                      {g.items.map((a) => (
                        <AssignmentRow key={a.id} a={a} />
                      ))}
                    </ul>
                  </div>
                ))
              ) : (
                <ul>
                  {lists[filter].map((a) => (
                    <AssignmentRow key={a.id} a={a} />
                  ))}
                </ul>
              )}
            </Card>

            <Card>
              <CardHeader title="Courses" />
              <p className="-mt-2 mb-3 text-[12px] text-faint">Link each class to a subject, or hide ones you don’t need.</p>
              <ul className="space-y-3">
                {courses.map(([id, name]) => {
                  const hidden = classroom.hiddenCourses.includes(id);
                  const value = classroom.courseSubjects[id] ?? guessSubject(name) ?? 'none';
                  return (
                    <li key={id} className={cn('space-y-1.5', hidden && 'opacity-45')}>
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-[13.5px] font-medium">{name}</span>
                        <button
                          onClick={() => toggleHidden(id)}
                          className="text-faint hover:text-fg"
                          aria-label={hidden ? 'Show course' : 'Hide course'}
                          title={hidden ? 'Show course' : 'Hide course'}
                        >
                          {hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                      <select
                        value={value}
                        onChange={(e) => setCourseSubject(id, e.target.value as Subject | 'none')}
                        className="field h-8 px-2 text-[12.5px]"
                        aria-label={`Subject for ${name}`}
                      >
                        <option value="none" className="bg-bg-card">
                          No subject
                        </option>
                        {SUBJECTS.map((s) => (
                          <option key={s} value={s} className="bg-bg-card">
                            {s}
                          </option>
                        ))}
                      </select>
                    </li>
                  );
                })}
              </ul>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
