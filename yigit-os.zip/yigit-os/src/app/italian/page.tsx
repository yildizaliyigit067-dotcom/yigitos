'use client';

import { useMemo, useState } from 'react';
import { format, subDays } from 'date-fns';
import { Bar as RBar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { BookOpen, Flame, Play, Plus, Trash2 } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useLog, useMaterialize } from '@/lib/hooks';
import { CATEGORIES } from '@/lib/categories';
import { dayKey, duration, fmtDur, parseDay, todayKey, weekKeys, weekStartOf } from '@/lib/date';
import { italianStreak, sumRange } from '@/lib/stats';
import { LEVELS, ROADMAP, VOCAB_TARGET } from '@/lib/seed';
import type { ItalianSkills } from '@/lib/types';
import { cn, pct } from '@/lib/utils';
import { ChartTooltip, axisProps, gridProps } from '@/components/charts';
import { Bar, Button, Card, CardHeader, Checkbox, Empty, Input, Ring, StatusChip } from '@/components/ui';

const GREEN = CATEGORIES.italian.color;

export default function ItalianPage() {
  const tk = todayKey();
  const week = useMemo(() => weekKeys(weekStartOf(new Date())), []);
  useMaterialize(week);
  const log = useLog();

  const s = useStore();
  const it = s.italian;
  const goal = s.settings.weeklyItalianGoalMin;
  const weekMin = sumRange(log, week[0], week[6]).italian;
  const streak = italianStreak(log);
  const month = new Date().getMonth();
  const phaseIdx = Math.max(0, ROADMAP.findIndex((r) => r.month === month));
  const phase = ROADMAP[phaseIdx];

  const todayTasks = s.tasks.filter((t) => t.date === tk && t.category === 'italian').sort((a, b) => a.start.localeCompare(b.start));

  const last14 = Array.from({ length: 14 }, (_, i) => {
    const d = subDays(new Date(), 13 - i);
    return { day: format(d, 'EEEEE'), date: format(d, 'd MMM'), minutes: log.get(dayKey(d))?.italian ?? 0 };
  });

  const [vocabInput, setVocabInput] = useState('');
  const [topic, setTopic] = useState('');
  const [test, setTest] = useState({ label: '', score: '', max: '100', date: tk });
  const grammarDone = s.italianTopics.filter((t) => t.status === 'completed').length;

  const skills: { key: keyof ItalianSkills; label: string }[] = [
    { key: 'listening', label: 'Listening' },
    { key: 'speaking', label: 'Speaking' },
    { key: 'reading', label: 'Reading' },
    { key: 'writing', label: 'Writing' },
  ];

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Italian 🇮🇹</h1>
          <p className="mt-1 text-[14px] text-muted">
            {phase.name}: {phase.phase}. {phase.goal}.
          </p>
        </div>
        <Button variant="primary" onClick={() => s.startFocus({ category: 'italian', label: 'Italian', minutes: 45 })}>
          <Play className="h-4 w-4" /> Italian focus
        </Button>
      </div>

      {/* Roadmap */}
      <div className="mb-6 grid grid-cols-2 gap-2 md:grid-cols-4">
        {ROADMAP.map((r, i) => (
          <div
            key={r.name}
            className={cn(
              'relative rounded-2xl border px-4 py-3.5',
              i === phaseIdx ? 'border-[#45CF98]/40 bg-[#45CF98]/[0.07]' : 'border-line bg-white/[0.015]',
            )}
          >
            <div className="flex items-center justify-between text-[12px]">
              <span className={i === phaseIdx ? 'text-[#7EE0B7]' : 'text-faint'}>{r.name}</span>
              {i < phaseIdx && <span className="text-faint">Done</span>}
              {i === phaseIdx && <span className="h-1.5 w-1.5 rounded-full" style={{ background: GREEN, boxShadow: `0 0 10px ${GREEN}` }} />}
            </div>
            <div className={cn('mt-1 text-[15px] font-semibold', i > phaseIdx && 'text-muted')}>{r.phase}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="This week" />
          <div className="flex flex-wrap items-center gap-6 sm:gap-10">
            <Ring value={pct(weekMin, goal)} size={112} stroke={7} color={GREEN}>
              <div className="text-center">
                <div className="text-[20px] font-semibold tabular tracking-[-0.02em]">{fmtDur(weekMin)}</div>
                <div className="text-[11px] text-faint">of {fmtDur(goal)}</div>
              </div>
            </Ring>
            <div className="grid flex-1 grid-cols-3 gap-4">
              <div>
                <div className="flex items-center gap-1.5 text-[12px] text-muted">
                  <Flame className="h-3.5 w-3.5" /> Streak
                </div>
                <div className="mt-1 text-[26px] font-semibold tabular tracking-[-0.02em]">{streak}</div>
                <div className="text-[12px] text-faint">days</div>
              </div>
              <div>
                <div className="text-[12px] text-muted">Level</div>
                <select
                  value={it.level}
                  onChange={(e) => s.setItalianLevel(e.target.value as typeof it.level)}
                  className="mt-1 bg-transparent text-[26px] font-semibold tracking-[-0.02em] focus:outline-none"
                >
                  {LEVELS.map((l) => (
                    <option key={l} value={l} className="bg-bg-card text-base">
                      {l}
                    </option>
                  ))}
                </select>
                <div className="text-[12px] text-faint">target B1</div>
              </div>
              <div>
                <div className="text-[12px] text-muted">Grammar</div>
                <div className="mt-1 text-[26px] font-semibold tabular tracking-[-0.02em]">
                  {grammarDone}
                  <span className="text-[16px] text-faint">/{s.italianTopics.length}</span>
                </div>
                <div className="text-[12px] text-faint">topics</div>
              </div>
            </div>
          </div>
          <div className="mt-6 h-[150px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={last14} margin={{ top: 4, right: 0, left: -28, bottom: 0 }}>
                <CartesianGrid {...gridProps} />
                <XAxis dataKey="day" {...axisProps} />
                <YAxis {...axisProps} allowDecimals={false} />
                <Tooltip cursor={{ fill: 'rgba(255,255,255,0.03)' }} content={<ChartTooltip labelKey="date" format={(v) => fmtDur(v)} />} />
                <RBar dataKey="minutes" name="Italian" fill={GREEN} radius={[4, 4, 0, 0]} maxBarSize={22} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <CardHeader title="Today’s Italian" />
          {todayTasks.length ? (
            <ul className="space-y-2">
              {todayTasks.map((t) => (
                <li key={t.id} className="flex items-center gap-3 rounded-xl border border-line bg-white/[0.02] p-3">
                  <Checkbox checked={t.done} onChange={() => s.toggleTask(t.id)} color={GREEN} />
                  <div className="min-w-0 flex-1">
                    <div className={cn('truncate text-[14px] font-medium', t.done && 'text-faint line-through')}>{t.title}</div>
                    <div className="text-[12px] text-faint tabular">
                      {t.start}–{t.end}
                      {t.notes ? ` · ${t.notes}` : ''}
                    </div>
                  </div>
                  {!t.done && (
                    <Button
                      size="icon-sm"
                      variant="ghost"
                      aria-label="Start focus"
                      onClick={() => s.startFocus({ category: 'italian', label: t.title, minutes: Math.min(90, Math.max(20, duration(t.start, t.end))), taskId: t.id })}
                    >
                      <Play className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="No Italian block today" hint="A 20-minute listening session still keeps the streak alive." />
          )}

          <div className="mt-6 border-t border-line pt-5">
            <div className="flex items-baseline justify-between">
              <span className="flex items-center gap-1.5 text-[13px] text-muted">
                <BookOpen className="h-3.5 w-3.5" /> Vocabulary
              </span>
              <span className="text-[13px] text-faint tabular">target {VOCAB_TARGET.toLocaleString()}</span>
            </div>
            <div className="mt-1 text-[28px] font-semibold tabular tracking-[-0.02em]">{it.vocab.toLocaleString()}</div>
            <Bar value={pct(it.vocab, VOCAB_TARGET)} color={GREEN} className="mt-2" />
            <form
              className="mt-3 flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                const n = parseInt(vocabInput, 10);
                if (!Number.isNaN(n)) s.addVocab(n);
                setVocabInput('');
              }}
            >
              <Input value={vocabInput} onChange={(e) => setVocabInput(e.target.value)} inputMode="numeric" placeholder="New words today" className="h-9" />
              <Button type="submit" size="md">
                Add
              </Button>
            </form>
          </div>
        </Card>

        <Card>
          <CardHeader title="Skills" />
          <div className="space-y-5">
            {skills.map((k) => (
              <div key={k.key}>
                <div className="mb-1.5 flex justify-between text-[13px]">
                  <span className="text-muted">{k.label}</span>
                  <span className="font-medium tabular">{it.skills[k.key]}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={it.skills[k.key]}
                  onChange={(e) => s.setSkill(k.key, Number(e.target.value))}
                  className="w-full"
                  aria-label={`${k.label} self-rating`}
                />
              </div>
            ))}
            <p className="text-[12px] text-faint">Rate yourself every Sunday during the weekly check.</p>
          </div>
        </Card>

        <Card>
          <CardHeader title="Grammar topics" />
          <ul className="max-h-[340px] space-y-1 overflow-y-auto pr-1">
            {s.italianTopics.map((t) => (
              <li key={t.id} className="group flex items-center gap-2 rounded-lg px-1 py-1.5">
                <span className={cn('flex-1 truncate text-[13.5px]', t.status === 'completed' && 'text-muted')}>{t.title}</span>
                <StatusChip status={t.status} onClick={() => s.cycleItalianTopic(t.id)} />
                <button onClick={() => s.deleteItalianTopic(t.id)} className="hidden text-faint hover:text-rose-300 group-hover:block" aria-label="Delete topic">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (topic.trim()) s.addItalianTopic(topic.trim());
              setTopic('');
            }}
          >
            <Input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Add a grammar topic" className="h-9" />
            <Button type="submit" size="icon" aria-label="Add topic">
              <Plus className="h-4 w-4" />
            </Button>
          </form>
        </Card>

        <Card>
          <CardHeader title="Weekly test scores" />
          {it.tests.length ? (
            <div className="h-[150px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={it.tests.map((t) => ({ ...t, pct: Math.round(pct(t.score, t.max)), d: format(parseDay(t.date), 'd MMM') }))} margin={{ top: 6, right: 6, left: -28, bottom: 0 }}>
                  <CartesianGrid {...gridProps} />
                  <XAxis dataKey="d" {...axisProps} />
                  <YAxis domain={[0, 100]} {...axisProps} />
                  <Tooltip content={<ChartTooltip labelKey="label" format={(v) => `${v}%`} />} />
                  <Line type="monotone" dataKey="pct" name="Score" stroke={GREEN} strokeWidth={2} dot={{ r: 3, fill: GREEN, strokeWidth: 0 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Empty title="No tests yet" hint="Log your Sunday test to see the trend." />
          )}
          <form
            className="mt-4 grid grid-cols-[1fr_64px_64px_auto] gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const score = Number(test.score);
              const max = Number(test.max) || 100;
              if (!test.score || Number.isNaN(score)) return;
              s.addTest({ label: test.label.trim() || `Week test ${format(parseDay(test.date), 'd MMM')}`, score, max, date: test.date });
              setTest({ ...test, label: '', score: '' });
            }}
          >
            <Input value={test.label} onChange={(e) => setTest({ ...test, label: e.target.value })} placeholder="Test name" className="h-9" />
            <Input value={test.score} onChange={(e) => setTest({ ...test, score: e.target.value })} placeholder="Score" inputMode="numeric" className="h-9 px-2" />
            <Input value={test.max} onChange={(e) => setTest({ ...test, max: e.target.value })} placeholder="Max" inputMode="numeric" className="h-9 px-2" />
            <Button type="submit" size="icon" aria-label="Add test">
              <Plus className="h-4 w-4" />
            </Button>
          </form>
          {it.tests.length > 0 && (
            <ul className="mt-3 space-y-1">
              {[...it.tests].reverse().slice(0, 4).map((t) => (
                <li key={t.id} className="group flex items-center justify-between text-[12.5px] text-muted">
                  <span className="truncate">{t.label}</span>
                  <span className="flex items-center gap-2 tabular">
                    {t.score}/{t.max}
                    <button onClick={() => s.deleteTest(t.id)} className="hidden text-faint hover:text-rose-300 group-hover:inline" aria-label="Delete test">
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
