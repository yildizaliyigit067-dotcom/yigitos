'use client';

import { useMemo, useState } from 'react';
import { format } from 'date-fns';
import { Play, Trash2 } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useMaterialize } from '@/lib/hooks';
import { CATEGORIES, FOCUS_CATEGORIES } from '@/lib/categories';
import { fmtDur, todayKey } from '@/lib/date';
import type { Category } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Button, Card, CardHeader, Empty, Stat } from '@/components/ui';

const DURATIONS = [20, 30, 45, 60, 90];

export default function FocusPage() {
  const tk = todayKey();
  const keys = useMemo(() => [tk], [tk]);
  useMaterialize(keys);
  const tasks = useStore((s) => s.tasks);
  const sessions = useStore((s) => s.focusSessions);
  const startFocus = useStore((s) => s.startFocus);
  const deleteSession = useStore((s) => s.deleteSession);

  const [category, setCategory] = useState<Category>('italian');
  const [minutes, setMinutes] = useState(45);
  const [taskId, setTaskId] = useState('');

  const todays = tasks.filter((t) => t.date === tk && !t.done && CATEGORIES[t.category].study).sort((a, b) => a.start.localeCompare(b.start));
  const linked = todays.find((t) => t.id === taskId);
  const todaySessions = sessions.filter((s) => s.date === tk);
  const recent = [...sessions].reverse().slice(0, 12);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Focus</h1>
        <p className="mt-1 text-[14px] text-muted">Pick an area and a length. Every finished session goes straight into your stats.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <Card className="p-6 sm:p-8">
          <div className="label mb-2.5">Area</div>
          <div className="flex flex-wrap gap-2">
            {FOCUS_CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setCategory(c);
                  setTaskId('');
                }}
                className={cn(
                  'flex h-10 items-center gap-2 rounded-xl border px-3.5 text-[14px] font-medium transition-colors',
                  category === c && !linked ? 'border-line-strong bg-white/[0.08] text-fg' : 'border-line text-muted hover:text-fg',
                )}
              >
                <span className="h-2 w-2 rounded-full" style={{ background: CATEGORIES[c].color }} />
                {c === 'personal' ? 'Other' : CATEGORIES[c].label}
              </button>
            ))}
          </div>

          {todays.length > 0 && (
            <>
              <div className="label mb-2.5 mt-7">Or work on a block from today</div>
              <div className="flex flex-wrap gap-2">
                {todays.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      setTaskId(t.id === taskId ? '' : t.id);
                      setCategory(t.category);
                    }}
                    className={cn(
                      'flex h-9 items-center gap-2 rounded-xl border px-3 text-[13px] font-medium transition-colors',
                      t.id === taskId ? 'border-line-strong bg-white/[0.08] text-fg' : 'border-line text-muted hover:text-fg',
                    )}
                  >
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: CATEGORIES[t.category].color }} />
                    <span className="tabular text-faint">{t.start}</span> {t.title}
                  </button>
                ))}
              </div>
            </>
          )}

          <div className="label mb-2.5 mt-7">Length</div>
          <div className="grid grid-cols-5 gap-2">
            {DURATIONS.map((d) => (
              <button
                key={d}
                onClick={() => setMinutes(d)}
                className={cn(
                  'rounded-2xl border py-4 text-center transition-colors',
                  minutes === d ? 'border-accent/60 bg-accent-soft text-fg' : 'border-line text-muted hover:border-line-strong hover:text-fg',
                )}
              >
                <div className="text-[22px] font-semibold tabular tracking-[-0.02em]">{d}</div>
                <div className="text-[11px]">min</div>
              </button>
            ))}
          </div>

          <Button
            variant="primary"
            size="lg"
            className="mt-8 h-12 w-full text-[15px]"
            onClick={() =>
              startFocus({
                category: linked?.category ?? category,
                label: linked?.title ?? (category === 'personal' ? 'Focus' : CATEGORIES[category].label),
                minutes,
                taskId: linked?.id,
              })
            }
          >
            <Play className="h-4 w-4" /> Start {minutes}-minute session
          </Button>
        </Card>

        <div className="space-y-4">
          <Card className="grid grid-cols-2 gap-4">
            <Stat label="Sessions today" value={todaySessions.length} />
            <Stat label="Focused today" value={fmtDur(todaySessions.reduce((a, s) => a + s.minutes, 0))} />
          </Card>
          <Card>
            <CardHeader title="Recent sessions" />
            {recent.length ? (
              <ul className="space-y-1">
                {recent.map((s) => (
                  <li key={s.id} className="group flex items-center gap-3 py-1.5 text-[13.5px]">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: CATEGORIES[s.category].color }} />
                    <span className="min-w-0 flex-1 truncate">{s.label}</span>
                    <span className="tabular text-muted">{fmtDur(s.minutes)}</span>
                    <span className="w-14 text-right text-[12px] tabular text-faint">{format(new Date(s.endedAt), 'd MMM')}</span>
                    <button
                      onClick={() => confirm('Delete this session from your stats?') && deleteSession(s.id)}
                      className="hidden text-faint hover:text-rose-300 group-hover:block"
                      aria-label="Delete session"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <Empty title="No sessions yet" hint="Your first finished session will show up here." />
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
