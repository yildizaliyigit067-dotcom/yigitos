'use client';

import { useState } from 'react';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { format } from 'date-fns';
import { Plus, Trash2 } from 'lucide-react';
import { useStore } from '@/lib/store';
import { CATEGORIES } from '@/lib/categories';
import { parseDay } from '@/lib/date';
import { SUBJECTS } from '@/lib/seed';
import { schoolProgress } from '@/lib/stats';
import type { Subject, TopicStatus } from '@/lib/types';
import { cn } from '@/lib/utils';
import { ChartTooltip, axisProps } from '@/components/charts';
import { Bar, Card, PageHeader, Ring, STATUS_META, Segmented, StatusChip } from '@/components/ui';

type Filter = 'all' | TopicStatus;
const AMBER = CATEGORIES.school.color;

function SubjectCard({ subject, filter }: { subject: Subject; filter: Filter }) {
  const topics = useStore((s) => s.schoolTopics).filter((t) => t.subject === subject);
  const cycle = useStore((s) => s.cycleSchoolTopic);
  const del = useStore((s) => s.deleteSchoolTopic);
  const add = useStore((s) => s.addSchoolTopic);
  const [title, setTitle] = useState('');
  const progress = schoolProgress(topics);
  const shown = filter === 'all' ? topics : topics.filter((t) => t.status === filter);
  if (filter !== 'all' && !shown.length) return null;

  return (
    <Card className="flex flex-col p-4 sm:p-5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h3 className="text-[15px] font-semibold tracking-[-0.01em]">{subject}</h3>
        <span className="text-[13px] font-medium tabular text-muted">{Math.round(progress)}%</span>
      </div>
      <Bar value={progress} color={progress >= 100 ? STATUS_META.completed.color : AMBER} />
      <ul className="mt-3 flex-1 space-y-0.5">
        {shown.map((t) => (
          <li key={t.id} className="group flex items-center gap-2 rounded-lg py-1">
            <span className={cn('flex-1 text-[13.5px] leading-snug', t.status === 'completed' && 'text-muted')}>{t.title}</span>
            <button onClick={() => del(t.id)} className="hidden text-faint hover:text-rose-300 group-hover:block" aria-label="Delete topic">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
            <StatusChip status={t.status} onClick={() => cycle(t.id)} />
          </li>
        ))}
      </ul>
      {filter === 'all' && (
        <form
          className="mt-3 flex items-center gap-2 border-t border-line pt-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (title.trim()) add(subject, title.trim());
            setTitle('');
          }}
        >
          <Plus className="h-3.5 w-3.5 shrink-0 text-faint" />
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Add a missed topic"
            className="h-7 flex-1 bg-transparent text-[13px] placeholder:text-faint focus:outline-none"
          />
        </form>
      )}
    </Card>
  );
}

export default function SchoolPage() {
  const topics = useStore((s) => s.schoolTopics);
  const history = useStore((s) => s.schoolHistory);
  const [filter, setFilter] = useState<Filter>('all');
  const progress = schoolProgress(topics);
  const counts = {
    not_started: topics.filter((t) => t.status === 'not_started').length,
    in_progress: topics.filter((t) => t.status === 'in_progress').length,
    completed: topics.filter((t) => t.status === 'completed').length,
  };
  const series = Object.entries(history)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([d, v]) => ({ d: format(parseDay(d), 'd MMM'), v }));

  return (
    <div>
      <PageHeader title="School catch-up" subtitle="Every topic you missed, one status at a time. Click a status to move it forward." />

      <div className="mb-6 grid gap-4 md:grid-cols-[auto_1fr]">
        <Card className="flex items-center gap-6">
          <Ring value={progress} size={104} stroke={7} color={AMBER}>
            <span className="text-[24px] font-semibold tabular tracking-[-0.03em]">{Math.round(progress)}%</span>
          </Ring>
          <div className="space-y-2">
            {(Object.keys(counts) as TopicStatus[]).map((k) => (
              <div key={k} className="flex items-center gap-2.5 text-[13px]">
                <span className="h-2 w-2 rounded-full" style={{ background: STATUS_META[k].color }} />
                <span className="w-24 text-muted">{STATUS_META[k].label}</span>
                <span className="font-medium tabular">{counts[k]}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="min-h-[150px] p-4">
          <div className="mb-2 text-[13px] text-muted">Progress over time</div>
          <div className="h-[110px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={series.length > 1 ? series : [...series, ...series]} margin={{ top: 4, right: 4, left: -30, bottom: 0 }}>
                <defs>
                  <linearGradient id="school-fill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={AMBER} stopOpacity={0.25} />
                    <stop offset="100%" stopColor={AMBER} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="d" {...axisProps} />
                <YAxis domain={[0, 100]} {...axisProps} />
                <Tooltip content={<ChartTooltip format={(v) => `${v}%`} />} />
                <Area type="monotone" dataKey="v" name="Progress" stroke={AMBER} strokeWidth={2} fill="url(#school-fill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <div className="mb-4 overflow-x-auto no-scrollbar">
        <Segmented
          id="school-filter"
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'all', label: 'All' },
            { value: 'not_started', label: 'Not started' },
            { value: 'in_progress', label: 'In progress' },
            { value: 'completed', label: 'Completed' },
          ]}
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {SUBJECTS.map((s) => (
          <SubjectCard key={s} subject={s} filter={filter} />
        ))}
      </div>
      <p className="mt-4 text-[12px] text-faint">
        The starting topics are a typical liceo second-year list. Replace them with the exact topics from your class register.
      </p>
    </div>
  );
}
