'use client';

import { useMemo, useState } from 'react';
import { addDays, addWeeks, endOfMonth, format, startOfMonth, subWeeks } from 'date-fns';
import { Bar as RBar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ArrowDownRight, ArrowUpRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useLog } from '@/lib/hooks';
import { BUCKETS } from '@/lib/categories';
import { dayKey, fmtDur, fmtHours, weekDays, weekStartOf } from '@/lib/date';
import { countDone, countSessions, schoolProgress, sumRange, totalOf } from '@/lib/stats';
import { pct } from '@/lib/utils';
import { ChartTooltip, axisProps, gridProps } from '@/components/charts';
import { Bar, Button, Card, CardHeader, Segmented } from '@/components/ui';

type Range = 'week' | 'trend';

function Delta({ now, prev }: { now: number; prev: number }) {
  if (!prev && !now) return <span className="text-faint">–</span>;
  const d = now - prev;
  if (Math.abs(d) < 0.5) return <span className="text-faint">same as last week</span>;
  const up = d > 0;
  const Icon = up ? ArrowUpRight : ArrowDownRight;
  return (
    <span className={up ? 'text-emerald-300/90' : 'text-rose-300/90'}>
      <Icon className="-mt-0.5 mr-0.5 inline h-3 w-3" />
      {prev ? `${Math.round(Math.abs(pct(d, prev)))}%` : 'new'}
    </span>
  );
}

export default function AnalyticsPage() {
  const log = useLog();
  const tasks = useStore((s) => s.tasks);
  const sessions = useStore((s) => s.focusSessions);
  const history = useStore((s) => s.schoolHistory);
  const topics = useStore((s) => s.schoolTopics);
  const [range, setRange] = useState<Range>('week');
  const [anchor, setAnchor] = useState(() => weekStartOf(new Date()));

  const days = useMemo(() => weekDays(anchor), [anchor]);
  const from = dayKey(days[0]);
  const to = dayKey(days[6]);
  const prevFrom = dayKey(subWeeks(days[0], 1));
  const prevTo = dayKey(subWeeks(days[6], 1));

  const cur = sumRange(log, from, to);
  const prev = sumRange(log, prevFrom, prevTo);
  const kpis = [
    ...BUCKETS.map((b) => ({ label: `${b.label} hours`, value: fmtHours(cur[b.key]), now: cur[b.key], prev: prev[b.key], color: b.color })),
    { label: 'Completed tasks', value: String(countDone(tasks, from, to)), now: countDone(tasks, from, to), prev: countDone(tasks, prevFrom, prevTo), color: '#C9CBD6' },
    { label: 'Focus sessions', value: String(countSessions(sessions, from, to)), now: countSessions(sessions, from, to), prev: countSessions(sessions, prevFrom, prevTo), color: '#5B7CFF' },
  ];

  const chartData = useMemo(() => {
    if (range === 'week') {
      return days.map((d) => {
        const k = dayKey(d);
        const v = log.get(k);
        return {
          name: format(d, 'EEE'),
          full: format(d, 'EEEE d MMM'),
          italian: (v?.italian ?? 0) / 60,
          school: (v?.school ?? 0) / 60,
          research: (v?.research ?? 0) / 60,
          itu: (v?.itu ?? 0) / 60,
          tasks: countDone(tasks, k, k),
          sessions: countSessions(sessions, k, k),
        };
      });
    }
    return Array.from({ length: 8 }, (_, i) => {
      const ws = subWeeks(anchor, 7 - i);
      const a = dayKey(ws);
      const b = dayKey(addDays(ws, 6));
      const v = sumRange(log, a, b);
      return {
        name: format(ws, 'd MMM'),
        full: `Week of ${format(ws, 'd MMM')}`,
        italian: v.italian / 60,
        school: v.school / 60,
        research: v.research / 60,
        itu: v.itu / 60,
        tasks: countDone(tasks, a, b),
        sessions: countSessions(sessions, a, b),
      };
    });
  }, [range, days, anchor, log, tasks, sessions]);

  // Month summary
  const ms = dayKey(startOfMonth(new Date()));
  const me = dayKey(endOfMonth(new Date()));
  const month = sumRange(log, ms, me);
  const hist = Object.entries(history).sort(([a], [b]) => a.localeCompare(b));
  const before = hist.filter(([d]) => d < ms).pop() ?? hist.find(([d]) => d >= ms);
  const schoolStart = before?.[1] ?? 0;
  const schoolNow = Math.round(schoolProgress(topics));
  const total = totalOf(cur);

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-[30px] font-semibold tracking-[-0.03em] md:text-[34px]">Analytics</h1>
          <p className="mt-1 text-[14px] text-muted">
            {format(days[0], 'd MMM')} – {format(days[6], 'd MMM yyyy')}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <Button size="icon" variant="ghost" onClick={() => setAnchor((a) => subWeeks(a, 1))} aria-label="Previous week">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button size="sm" onClick={() => setAnchor(weekStartOf(new Date()))}>
            This week
          </Button>
          <Button size="icon" variant="ghost" onClick={() => setAnchor((a) => addWeeks(a, 1))} aria-label="Next week">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card className="mb-4 p-5 sm:p-6">
        <p className="text-[13px] text-muted">{format(new Date(), 'MMMM')} so far</p>
        <p className="mt-2 max-w-3xl text-[20px] font-medium leading-snug tracking-[-0.015em] sm:text-[24px]">
          {fmtDur(month.italian)} of Italian, {fmtDur(month.research)} of research, {fmtDur(month.school)} of school work and {fmtDur(month.itu)} at İTÜ.
          <span className="text-muted"> School catch-up went from {schoolStart}% to {schoolNow}%.</span>
        </p>
      </Card>

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {kpis.map((k) => (
          <Card key={k.label} className="p-4">
            <div className="flex items-center gap-2 text-[12px] text-muted">
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: k.color }} />
              {k.label}
            </div>
            <div className="mt-2 text-[26px] font-semibold tabular tracking-[-0.03em]">{k.value}</div>
            <div className="mt-0.5 text-[12px]">
              <Delta now={k.now} prev={k.prev} />
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader
            title="Hours by area"
            action={
              <Segmented
                id="analytics-range"
                value={range}
                onChange={setRange}
                options={[
                  { value: 'week', label: 'Week' },
                  { value: 'trend', label: '8 weeks' },
                ]}
              />
            }
          />
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 8, right: 0, left: -24, bottom: 0 }}>
                <CartesianGrid {...gridProps} />
                <XAxis dataKey="name" {...axisProps} />
                <YAxis {...axisProps} width={48} tickFormatter={(v: number) => (v === 0 ? '0' : v < 1 ? `${Math.round(v * 60)}m` : `${Math.round(v * 10) / 10}h`)} />
                <Tooltip cursor={{ fill: 'rgba(255,255,255,0.03)' }} content={<ChartTooltip labelKey="full" format={(v) => fmtDur(v * 60)} />} />
                {BUCKETS.map((b, i) => (
                  <RBar key={b.key} dataKey={b.key} name={b.label} stackId="h" fill={b.color} maxBarSize={range === 'week' ? 36 : 28} radius={i === BUCKETS.length - 1 ? [4, 4, 0, 0] : 0} />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-muted">
            {BUCKETS.map((b) => (
              <span key={b.key} className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm" style={{ background: b.color }} />
                {b.label}
              </span>
            ))}
          </div>
        </Card>

        <Card>
          <CardHeader title="Where the week went" />
          <div className="text-[34px] font-semibold tabular tracking-[-0.035em]">{fmtDur(total)}</div>
          <div className="text-[12.5px] text-faint">logged this week</div>
          <div className="mt-6 space-y-4">
            {BUCKETS.map((b) => (
              <div key={b.key}>
                <div className="mb-1.5 flex justify-between text-[13px]">
                  <span className="text-muted">{b.label}</span>
                  <span className="tabular">
                    {fmtDur(cur[b.key])} <span className="text-faint">· {Math.round(pct(cur[b.key], total))}%</span>
                  </span>
                </div>
                <Bar value={pct(cur[b.key], total)} color={b.color} />
              </div>
            ))}
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader title="Completed tasks and focus sessions" />
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 8, right: 8, left: -28, bottom: 0 }}>
                <CartesianGrid {...gridProps} />
                <XAxis dataKey="name" {...axisProps} />
                <YAxis {...axisProps} allowDecimals={false} />
                <Tooltip content={<ChartTooltip labelKey="full" />} />
                <Line type="monotone" dataKey="tasks" name="Completed tasks" stroke="#C9CBD6" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                <Line type="monotone" dataKey="sessions" name="Focus sessions" stroke="#5B7CFF" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
}
