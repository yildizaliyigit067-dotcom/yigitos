export function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" opacity=".3" />
      <circle cx="12" cy="12" r="3.4" fill="currentColor" />
      <circle cx="18.1" cy="6.3" r="1.9" fill="#5B7CFF" />
    </svg>
  );
}
