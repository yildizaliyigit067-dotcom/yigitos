'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { PanelLeftClose, PanelLeftOpen, Search } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { cn } from '@/lib/utils';
import { Logo } from './logo';
import { NAV_BOTTOM, NAV_MAIN, isActive } from './nav';

function NavLink({ href, label, icon: Icon, collapsed }: { href: string; label: string; icon: typeof Search; collapsed: boolean }) {
  const pathname = usePathname();
  const active = isActive(pathname, href);
  return (
    <Link
      href={href}
      title={collapsed ? label : undefined}
      className={cn(
        'group relative flex h-9 items-center gap-3 rounded-[10px] px-2.5 text-[13.5px] font-medium transition-colors',
        active ? 'text-fg' : 'text-muted hover:bg-white/[0.035] hover:text-fg',
        collapsed && 'justify-center px-0',
      )}
    >
      {active && (
        <motion.span
          layoutId="nav-active"
          className="absolute inset-0 rounded-[10px] border border-line bg-white/[0.06]"
          transition={{ type: 'spring', bounce: 0.15, duration: 0.4 }}
        />
      )}
      <Icon className={cn('relative h-[17px] w-[17px] shrink-0', active ? 'text-fg' : 'text-faint group-hover:text-muted')} />
      {!collapsed && <span className="relative truncate">{label}</span>}
    </Link>
  );
}

export function Sidebar() {
  const collapsed = useStore((s) => s.sidebarCollapsed);
  const setCollapsed = useStore((s) => s.setSidebarCollapsed);
  const setPalette = useUI((s) => s.setPalette);

  return (
    <aside
      className={cn(
        'sticky top-0 hidden h-dvh shrink-0 flex-col border-r border-line bg-bg-raised/60 backdrop-blur-xl transition-[width] duration-300 ease-out md:flex',
        collapsed ? 'w-[68px]' : 'w-[236px]',
      )}
    >
      <div className={cn('flex h-16 items-center gap-2.5 px-5', collapsed && 'justify-center px-0')}>
        <Link href="/" className="flex items-center gap-2.5 text-fg">
          <Logo className="h-[22px] w-[22px]" />
          {!collapsed && <span className="text-[14px] font-semibold tracking-[0.06em]">YİĞİT OS</span>}
        </Link>
      </div>

      <div className={cn('px-3 pb-2', collapsed && 'px-2.5')}>
        <button
          onClick={() => setPalette(true)}
          className={cn(
            'flex h-9 w-full items-center gap-2.5 rounded-[10px] border border-line bg-white/[0.02] px-2.5 text-[13px] text-faint transition-colors hover:border-line-strong hover:text-muted',
            collapsed && 'justify-center px-0',
          )}
          title="Search and commands"
        >
          <Search className="h-4 w-4" />
          {!collapsed && (
            <>
              <span className="flex-1 text-left">Search</span>
              <span className="text-[11px]">⌘K</span>
            </>
          )}
        </button>
      </div>

      <nav className={cn('flex flex-1 flex-col gap-0.5 px-3 pt-2', collapsed && 'px-2.5')}>
        {NAV_MAIN.map((n) => (
          <NavLink key={n.href} {...n} collapsed={collapsed} />
        ))}
      </nav>

      <div className={cn('flex flex-col gap-0.5 border-t border-line px-3 py-3', collapsed && 'px-2.5')}>
        {NAV_BOTTOM.map((n) => (
          <NavLink key={n.href} {...n} collapsed={collapsed} />
        ))}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className={cn(
            'mt-1 flex h-9 items-center gap-3 rounded-[10px] px-2.5 text-[13px] text-faint transition-colors hover:bg-white/[0.035] hover:text-muted',
            collapsed && 'justify-center px-0',
          )}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <PanelLeftOpen className="h-[17px] w-[17px]" /> : <PanelLeftClose className="h-[17px] w-[17px]" />}
          {!collapsed && 'Collapse'}
        </button>
      </div>
    </aside>
  );
}
