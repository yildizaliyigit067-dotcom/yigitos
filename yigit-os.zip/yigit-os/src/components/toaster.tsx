'use client';

import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { useUI } from '@/lib/ui-store';

export function Toaster() {
  const toasts = useUI((s) => s.toasts);
  if (typeof document === 'undefined') return null;
  return createPortal(
    <div className="pointer-events-none fixed inset-x-0 bottom-[calc(env(safe-area-inset-bottom)+84px)] z-[90] flex flex-col items-center gap-2 px-4 md:bottom-6">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: 12, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.98 }}
            className="flex items-center gap-2.5 rounded-full border border-line-strong bg-[#17171B]/95 px-4 py-2 text-[13px] font-medium shadow-xl backdrop-blur-xl"
          >
            <Check className="h-3.5 w-3.5 text-accent" strokeWidth={3} />
            {t.message}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>,
    document.body,
  );
}
