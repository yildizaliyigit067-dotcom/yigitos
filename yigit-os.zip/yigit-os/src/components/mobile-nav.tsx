'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { CalendarRange, LayoutGrid, MoreHorizontal, Sun, Timer } from 'lucide-react';
import { useUI } from '@/lib/ui-store';
import { cn } from '@/lib/utils';
import { Dialog } from './dialog';
import { NAV_BOTTOM, NAV_MAIN, isActive } from './nav';

const PRIMARY = [
  { href: '/', label: 'Home', icon: LayoutGrid },
  { href: '/today', label: 'Today', icon: Sun },
  { href: '/planner', label: 'Planner', icon: CalendarRange },
  { href: '/focus', label: 'Focus', icon: Timer },
];

export function MobileNav() {
  const pathname = usePathname();
  const moreOpen = useUI((s) => s.moreOpen);
  const setMoreOpen = useUI((s) => s.setMoreOpen);
  const more = [...NAV_MAIN, ...NAV_BOTTOM].filter((n) => !PRIMARY.some((p) => p.href === n.href));
  const moreActive = more.some((n) => isActive(pathname, n.href));

  return (
    <>
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg/85 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl md:hidden">
        <div className="grid h-[60px] grid-cols-5">
          {PRIMARY.map(({ href, label, icon: Icon }) => {
            const active = isActive(pathname, href);
            return (
              <Link key={href} href={href} className={cn('flex flex-col items-center justify-center gap-1 text-[10.5px] font-medium', active ? 'text-fg' : 'text-faint')}>
                <Icon className={cn('h-[21px] w-[21px]', active && 'text-accent')} strokeWidth={active ? 2.2 : 1.8} />
                {label}
              </Link>
            );
          })}
          <button
            onClick={() => setMoreOpen(true)}
            className={cn('flex flex-col items-center justify-center gap-1 text-[10.5px] font-medium', moreActive ? 'text-fg' : 'text-faint')}
          >
            <MoreHorizontal className={cn('h-[21px] w-[21px]', moreActive && 'text-accent')} />
            More
          </button>
        </div>
      </nav>

      <Dialog open={moreOpen} onClose={() => setMoreOpen(false)} title="Go to">
        <div className="grid grid-cols-2 gap-2">
          {more.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setMoreOpen(false)}
              className={cn(
                'flex items-center gap-3 rounded-xl border border-line px-3.5 py-3.5 text-[14px] font-medium',
                isActive(pathname, href) ? 'bg-white/[0.07] text-fg' : 'bg-white/[0.02] text-muted',
              )}
            >
              <Icon className="h-[18px] w-[18px]" />
              {label}
            </Link>
          ))}
        </div>
      </Dialog>
    </>
  );
}
