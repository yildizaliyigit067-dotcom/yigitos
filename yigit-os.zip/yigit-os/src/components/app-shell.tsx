'use client';

import { useEffect, type ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { useMounted } from '@/lib/hooks';
import { syncClassroom } from '@/lib/classroom/sync';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { CommandPalette } from './command-palette';
import { FocusOverlay } from './focus-overlay';
import { Logo } from './logo';
import { MobileNav } from './mobile-nav';
import { Sidebar } from './sidebar';
import { TaskDialog } from './task-dialog';
import { Toaster } from './toaster';

export function AppShell({ children }: { children: ReactNode }) {
  const mounted = useMounted();
  const pathname = usePathname();
  const openCreate = useUI((s) => s.openCreate);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const ui = useUI.getState();
        ui.setPalette(!ui.palette);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Quietly refresh Classroom while a Google session from this browser session is still valid.
  useEffect(() => {
    if (!mounted) return;
    const run = () => {
      if (useStore.getState().classroom.connected) syncClassroom(false).catch(() => {});
    };
    run();
    const id = setInterval(run, 15 * 60_000);
    const onVisible = () => document.visibilityState === 'visible' && run();
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      clearInterval(id);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [mounted]);

  useEffect(() => {
    if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }
  }, []);

  if (!mounted) {
    return (
      <div className="grid h-dvh place-items-center">
        <Logo className="h-7 w-7 animate-shimmer text-faint" />
      </div>
    );
  }

  return (
    <div className="flex min-h-dvh">
      <Sidebar />
      <main className="min-w-0 flex-1">
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto w-full max-w-[1220px] px-4 pb-36 pt-[calc(env(safe-area-inset-top)+1.5rem)] sm:px-6 md:px-10 md:pb-16 md:pt-10"
        >
          {children}
        </motion.div>
      </main>

      <button
        onClick={() => openCreate()}
        className="fixed bottom-[calc(env(safe-area-inset-bottom)+76px)] right-4 z-30 flex h-12 w-12 items-center justify-center gap-2 rounded-full bg-accent text-[14px] font-semibold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.2),0_12px_30px_-8px_rgba(91,124,255,0.65)] transition-transform hover:bg-accent-hover active:scale-95 md:bottom-7 md:right-7 md:w-auto md:px-4"
        aria-label="Add"
      >
        <Plus className="h-5 w-5 md:h-[18px] md:w-[18px]" strokeWidth={2.5} />
        <span className="hidden md:inline">Add</span>
      </button>

      <MobileNav />
      <CommandPalette />
      <TaskDialog />
      <FocusOverlay />
      <Toaster />
    </div>
  );
}
