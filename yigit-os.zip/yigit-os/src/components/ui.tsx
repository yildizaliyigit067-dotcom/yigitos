'use client';

import {
  forwardRef,
  type ButtonHTMLAttributes,
  type ComponentType,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type TextareaHTMLAttributes,
} from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { cn, clamp } from '@/lib/utils';
import type { TopicStatus } from '@/lib/types';

export function Card({ className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card p-5', className)} {...rest} />;
}

export function CardHeader({
  title,
  icon: Icon,
  action,
  className,
}: {
  title: ReactNode;
  icon?: ComponentType<{ className?: string }>;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('mb-4 flex min-h-[28px] items-center justify-between gap-3', className)}>
      <div className="flex items-center gap-2 text-[13px] font-medium text-muted">
        {Icon && <Icon className="h-4 w-4 text-faint" />}
        {title}
      </div>
      {action}
    </div>
  );
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg' | 'icon' | 'icon-sm';
};

export const Button = forwardRef<HTMLButtonElement, BtnProps>(function Button(
  { className, variant = 'secondary', size = 'md', type = 'button', ...p },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cn(
        'inline-flex select-none items-center justify-center gap-2 whitespace-nowrap rounded-xl font-medium transition-[background,color,border-color,box-shadow,transform] duration-150 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60',
        {
          primary:
            'bg-accent text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.18),0_8px_24px_-10px_rgba(91,124,255,0.7)] hover:bg-accent-hover',
          secondary: 'border border-line bg-white/[0.03] text-fg hover:border-line-strong hover:bg-white/[0.06]',
          ghost: 'text-muted hover:bg-white/[0.05] hover:text-fg',
          danger: 'text-rose-300/90 hover:bg-rose-500/10 hover:text-rose-200',
        }[variant],
        {
          sm: 'h-8 px-3 text-[13px]',
          md: 'h-9 px-3.5 text-sm',
          lg: 'h-11 px-5 text-[15px]',
          icon: 'h-9 w-9',
          'icon-sm': 'h-7 w-7 rounded-lg',
        }[size],
        className,
      )}
      {...p}
    />
  );
});

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function Input(
  { className, ...p },
  ref,
) {
  return <input ref={ref} className={cn('field', className)} {...p} />;
});

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea(
  { className, ...p },
  ref,
) {
  return <textarea ref={ref} className={cn('field h-auto min-h-[88px] resize-y py-2.5 leading-relaxed', className)} {...p} />;
});

export function Bar({ value, color = 'var(--accent)', className }: { value: number; color?: string; className?: string }) {
  return (
    <div className={cn('h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]', className)}>
      <motion.div
        className="h-full rounded-full"
        style={{ background: color }}
        initial={{ width: 0 }}
        animate={{ width: `${clamp(value)}%` }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      />
    </div>
  );
}

export function Ring({
  value,
  size = 64,
  stroke = 5,
  color = 'var(--accent)',
  children,
  className,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  children?: ReactNode;
  className?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className={cn('relative shrink-0', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - clamp(value) / 100) }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function Checkbox({
  checked,
  onChange,
  color = 'var(--accent)',
  label,
  size = 20,
}: {
  checked: boolean;
  onChange: () => void;
  color?: string;
  label?: string;
  size?: number;
}) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      onClick={(e) => {
        e.stopPropagation();
        onChange();
      }}
      className="group grid shrink-0 place-items-center rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
      style={{ width: size + 8, height: size + 8 }}
    >
      <motion.span
        className="grid place-items-center rounded-full border"
        style={{ width: size, height: size }}
        animate={{
          backgroundColor: checked ? color : 'rgba(255,255,255,0)',
          borderColor: checked ? color : 'rgba(255,255,255,0.22)',
          scale: checked ? [1, 1.15, 1] : 1,
        }}
        transition={{ duration: 0.28 }}
      >
        <motion.span initial={false} animate={{ opacity: checked ? 1 : 0, scale: checked ? 1 : 0.5 }}>
          <Check className="text-white" style={{ width: size * 0.6, height: size * 0.6 }} strokeWidth={3} />
        </motion.span>
      </motion.span>
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  id,
  className,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode }[];
  id: string;
  className?: string;
}) {
  return (
    <div className={cn('inline-flex rounded-xl border border-line bg-white/[0.02] p-0.5', className)}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            'relative whitespace-nowrap rounded-[10px] px-3 py-1.5 text-[13px] font-medium transition-colors',
            value === o.value ? 'text-fg' : 'text-muted hover:text-fg',
          )}
        >
          {value === o.value && (
            <motion.span
              layoutId={`seg-${id}`}
              className="absolute inset-0 rounded-[10px] bg-white/[0.08]"
              transition={{ type: 'spring', bounce: 0.15, duration: 0.4 }}
            />
          )}
          <span className="relative">{o.label}</span>
        </button>
      ))}
    </div>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="rounded-md border border-line bg-white/[0.04] px-1.5 py-0.5 font-sans text-[11px] font-medium text-muted">
      {children}
    </kbd>
  );
}

export function Empty({ icon: Icon, title, hint, action }: { icon?: ComponentType<{ className?: string }>; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-line px-6 py-10 text-center">
      {Icon && <Icon className="mb-3 h-5 w-5 text-faint" />}
      <p className="text-sm font-medium text-fg">{title}</p>
      {hint && <p className="mt-1 max-w-xs text-[13px] text-muted">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-[28px] font-semibold leading-tight tracking-[-0.02em] md:text-[34px]">{title}</h1>
        {subtitle && <p className="mt-1.5 text-[14px] text-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export const STATUS_META: Record<TopicStatus, { label: string; color: string }> = {
  not_started: { label: 'Not started', color: '#F07070' },
  in_progress: { label: 'In progress', color: '#F0BE4A' },
  completed: { label: 'Completed', color: '#3FCF8E' },
};

export function StatusChip({ status, onClick }: { status: TopicStatus; onClick?: () => void }) {
  const m = STATUS_META[status];
  return (
    <button
      type="button"
      onClick={onClick}
      title="Change status"
      className="inline-flex h-7 shrink-0 items-center gap-1.5 rounded-lg border border-line bg-white/[0.02] px-2 text-[12px] font-medium text-muted transition-colors hover:border-line-strong hover:text-fg"
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: m.color, boxShadow: `0 0 8px ${m.color}` }} />
      {m.label}
    </button>
  );
}

export function Stat({ label, value, sub, className }: { label: string; value: ReactNode; sub?: ReactNode; className?: string }) {
  return (
    <div className={className}>
      <div className="text-[12px] text-muted">{label}</div>
      <div className="mt-1 text-2xl font-semibold tracking-[-0.02em] tabular">{value}</div>
      {sub && <div className="mt-0.5 text-[12px] text-faint">{sub}</div>}
    </div>
  );
}
