'use client';

import type { TooltipProps } from 'recharts';

export const axisProps = {
  tickLine: false,
  axisLine: false,
  tick: { fill: '#5C5C66', fontSize: 11.5 },
  tickMargin: 8,
} as const;

export const gridProps = { vertical: false, stroke: 'rgba(255,255,255,0.05)' } as const;

export function ChartTooltip({
  active,
  payload,
  label,
  labelKey,
  format = (v: number) => String(v),
}: TooltipProps<number, string> & { labelKey?: string; format?: (v: number) => string }) {
  if (!active || !payload?.length) return null;
  const title = labelKey ? (payload[0]?.payload as Record<string, unknown>)?.[labelKey] : label;
  const rows = payload.filter((p) => (p.value ?? 0) > 0 || payload.length === 1);
  return (
    <div className="min-w-[140px] rounded-xl border border-line-strong bg-[#151519]/95 px-3 py-2.5 text-[12.5px] shadow-2xl backdrop-blur-xl">
      <div className="mb-1.5 font-medium text-fg">{String(title ?? '')}</div>
      {rows.length === 0 && <div className="text-muted">Nothing logged</div>}
      {rows.map((p) => (
        <div key={String(p.dataKey)} className="flex items-center justify-between gap-4 py-0.5">
          <span className="flex items-center gap-2 text-muted">
            <span className="h-2 w-2 rounded-sm" style={{ background: p.color ?? (p.payload as { fill?: string })?.fill }} />
            {p.name}
          </span>
          <span className="font-medium tabular text-fg">{format(Number(p.value ?? 0))}</span>
        </div>
      ))}
    </div>
  );
}
