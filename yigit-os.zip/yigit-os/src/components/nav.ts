import {
  Activity,
  Building2,
  CalendarRange,
  ClipboardList,
  FlaskConical,
  GraduationCap,
  Languages,
  LayoutGrid,
  Settings,
  Sun,
  Timer,
} from 'lucide-react';

export const NAV_MAIN = [
  { href: '/', label: 'Overview', icon: LayoutGrid },
  { href: '/today', label: 'Today', icon: Sun },
  { href: '/planner', label: 'Planner', icon: CalendarRange },
  { href: '/italian', label: 'Italian', icon: Languages },
  { href: '/school', label: 'School', icon: GraduationCap },
  { href: '/classroom', label: 'Classroom', icon: ClipboardList },
  { href: '/research', label: 'Research', icon: FlaskConical },
  { href: '/itu', label: 'İTÜ Çekirdek', icon: Building2 },
  { href: '/analytics', label: 'Analytics', icon: Activity },
];

export const NAV_BOTTOM = [
  { href: '/focus', label: 'Focus', icon: Timer },
  { href: '/settings', label: 'Settings', icon: Settings },
];

export const isActive = (pathname: string, href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href));
