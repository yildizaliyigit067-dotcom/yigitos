'use client';

import { useMemo } from 'react';
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion';
import { Play, Plus } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { useNow } from '@/lib/hooks';
import { CATEGORIES } from '@/lib/categories';
import { duration, fmtDur, nowMin, toMin, todayKey } from '@/lib/date';
import type { Task } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Button, Checkbox } from './ui';

function Item({ task, state }: { task: Task; state: 'now' | 'next' | 'past' | 'done' | 'upcoming' }) {
  const toggle = useStore((s) => s.toggleTask);
  const startFocus = useStore((s) => s.startFocus);
  const openEdit = useUI((s) => s.openEdit);
  const cat = CATEGORIES[task.category];
  const dur = duration(task.start, task.end);
  const done = state === 'done';

  return (
    <motion.li
      layout
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0, marginTop: 0 }}
      transition={{ type: 'spring', bounce: 0.1, duration: 0.45 }}
      className="group relative"
    >
      <div
        onClick={() => openEdit(task.id)}
        className={cn(
          'relative flex cursor-pointer items-center gap-3 rounded-xl px-2 py-2.5 transition-colors hover:bg-white/[0.03] sm:gap-4 sm:px-3',
          state === 'now' && 'bg-white/[0.035]',
        )}
      >
        <span className={cn('w-11 shrink-0 text-[13px] tabular', done ? 'text-faint' : 'text-muted')}>{task.start}</span>
        <span
          className="h-9 w-[3px] shrink-0 rounded-full transition-opacity"
          style={{ background: cat.color, opacity: done ? 0.25 : state === 'past' ? 0.5 : 1 }}
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span
              className={cn(
                'truncate text-[14.5px] font-medium transition-colors',
                done ? 'text-faint line-through decoration-white/20' : 'text-fg',
              )}
            >
              {task.title}
            </span>
            {state === 'now' && <span className="rounded-md bg-accent-soft px-1.5 py-0.5 text-[11px] font-semibold text-accent">Now</span>}
            {state === 'next' && <span className="rounded-md bg-white/[0.06] px-1.5 py-0.5 text-[11px] font-semibold text-muted">Next</span>}
          </div>
          <div className="mt-0.5 truncate text-[12.5px] text-faint">
            {task.start}–{task.end} · {fmtDur(dur)} · {cat.label}
            {task.source === 'google' && ' · Google'}
          </div>
        </div>
        {!done && cat.study && (
          <Button
            size="icon-sm"
            variant="ghost"
            className="opacity-100 sm:opacity-0 sm:group-hover:opacity-100"
            aria-label="Start focus"
            title="Start focus"
            onClick={(e) => {
              e.stopPropagation();
              startFocus({ category: task.category, label: task.title, minutes: Math.min(90, Math.max(20, dur)), taskId: task.id });
            }}
          >
            <Play className="h-3.5 w-3.5" />
          </Button>
        )}
        <Checkbox checked={task.done} onChange={() => toggle(task.id)} color={cat.color} label={`Mark ${task.title} done`} />
      </div>
    </motion.li>
  );
}

export function Timeline({ dateKey, hideClass = false }: { dateKey: string; hideClass?: boolean }) {
  const tasks = useStore((s) => s.tasks);
  const openCreate = useUI((s) => s.openCreate);
  const now = useNow(30_000);
  const isToday = dateKey === todayKey();

  const { open, done } = useMemo(() => {
    const list = tasks
      .filter((t) => t.date === dateKey && !(hideClass && t.category === 'class'))
      .sort((a, b) => a.start.localeCompare(b.start));
    return { open: list.filter((t) => !t.done), done: list.filter((t) => t.done) };
  }, [tasks, dateKey, hideClass]);

  const m = nowMin(now);
  const nextId = isToday ? open.find((t) => toMin(t.start) > m)?.id : undefined;
  const stateOf = (t: Task): 'now' | 'next' | 'past' | 'upcoming' => {
    if (!isToday) return dateKey < todayKey() ? 'past' : 'upcoming';
    if (toMin(t.start) <= m && toMin(t.end) > m) return 'now';
    if (t.id === nextId) return 'next';
    return toMin(t.end) <= m ? 'past' : 'upcoming';
  };

  if (!open.length && !done.length) {
    return (
      <div className="flex flex-col items-center rounded-xl border border-dashed border-line px-6 py-10 text-center">
        <p className="text-sm font-medium">Nothing planned for this day</p>
        <p className="mt-1 text-[13px] text-muted">Add a block, or enjoy the free time.</p>
        <Button size="sm" className="mt-4" onClick={() => openCreate({ date: dateKey })}>
          <Plus className="h-4 w-4" /> Add to this day
        </Button>
      </div>
    );
  }

  return (
    <LayoutGroup>
      <ul className="space-y-0.5">
        <AnimatePresence initial={false}>
          {open.map((t) => (
            <Item key={t.id} task={t} state={stateOf(t)} />
          ))}
        </AnimatePresence>
      </ul>
      {open.length === 0 && (
        <motion.p layout className="px-3 py-4 text-[13.5px] text-muted">
          Everything on this day is done.
        </motion.p>
      )}
      {done.length > 0 && (
        <motion.div layout className="mt-4 border-t border-line pt-3">
          <p className="px-3 pb-1 text-[12px] font-medium text-faint">Completed · {done.length}</p>
          <ul className="space-y-0.5">
            <AnimatePresence initial={false}>
              {done.map((t) => (
                <Item key={t.id} task={t} state="done" />
              ))}
            </AnimatePresence>
          </ul>
        </motion.div>
      )}
    </LayoutGroup>
  );
}
