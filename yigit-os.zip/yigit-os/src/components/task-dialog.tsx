'use client';

import { useEffect, useRef, useState } from 'react';
import { Trash2 } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { CATEGORIES, CATEGORY_ORDER } from '@/lib/categories';
import { fromMin, nowMin, toMin, todayKey } from '@/lib/date';
import type { Category } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Dialog } from './dialog';
import { Button, Input, Textarea } from './ui';

interface Form {
  title: string;
  category: Category;
  date: string;
  start: string;
  end: string;
  notes: string;
}

const defaultStart = () => fromMin(Math.min(23 * 60, Math.ceil((nowMin() + 5) / 30) * 30));

export function TaskDialog() {
  const dialog = useUI((s) => s.dialog);
  const close = useUI((s) => s.closeDialog);
  const toast = useUI((s) => s.toast);
  const tasks = useStore((s) => s.tasks);
  const addTask = useStore((s) => s.addTask);
  const updateTask = useStore((s) => s.updateTask);
  const deleteTask = useStore((s) => s.deleteTask);
  const titleRef = useRef<HTMLInputElement>(null);

  const editing = dialog?.mode === 'edit' ? tasks.find((t) => t.id === dialog.taskId) : undefined;
  const [f, setF] = useState<Form>({ title: '', category: 'personal', date: todayKey(), start: '17:00', end: '17:45', notes: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    if (!dialog) return;
    setError('');
    if (dialog.mode === 'edit') {
      const t = useStore.getState().tasks.find((x) => x.id === dialog.taskId);
      if (t) setF({ title: t.title, category: t.category, date: t.date, start: t.start, end: t.end, notes: t.notes ?? '' });
    } else {
      const p = dialog.preset ?? {};
      const category = p.category ?? 'personal';
      const start = p.start ?? defaultStart();
      const end = p.end ?? fromMin(toMin(start) + (category === 'exam' ? 90 : 45));
      setF({ title: p.title ?? '', category, date: p.date ?? todayKey(), start, end, notes: p.notes ?? '' });
    }
    const id = setTimeout(() => titleRef.current?.focus(), 60);
    return () => clearTimeout(id);
  }, [dialog]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((x) => ({ ...x, [k]: v }));

  const save = () => {
    if (!f.title.trim()) return setError('Give it a title.');
    if (toMin(f.end) <= toMin(f.start)) return setError('End time must be after the start time.');
    const payload = { ...f, title: f.title.trim(), notes: f.notes.trim() || undefined };
    if (editing) {
      updateTask(editing.id, payload);
      toast('Changes saved');
    } else {
      addTask({ ...payload, assignmentId: dialog?.mode === 'create' ? dialog.preset?.assignmentId : undefined });
      toast(`${CATEGORIES[f.category].label} added`);
    }
    close();
  };

  return (
    <Dialog open={!!dialog} onClose={close} title={editing ? 'Edit' : 'Add to your plan'}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          save();
        }}
        className="space-y-4"
      >
        <div className="flex flex-wrap gap-1.5">
          {CATEGORY_ORDER.map((c) => {
            const active = f.category === c;
            return (
              <button
                key={c}
                type="button"
                onClick={() => set('category', c)}
                className={cn(
                  'flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-[12.5px] font-medium transition-colors',
                  active ? 'border-line-strong bg-white/[0.08] text-fg' : 'border-line text-muted hover:text-fg',
                )}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: CATEGORIES[c].color }} />
                {CATEGORIES[c].label}
              </button>
            );
          })}
        </div>

        <Input
          ref={titleRef}
          value={f.title}
          onChange={(e) => set('title', e.target.value)}
          placeholder={f.category === 'exam' ? 'Physics exam' : 'What needs to happen?'}
          className="h-12 text-[16px]"
        />

        <div className="grid grid-cols-[1.4fr_1fr_1fr] gap-2">
          <label className="space-y-1.5">
            <span className="label">Date</span>
            <Input type="date" value={f.date} onChange={(e) => set('date', e.target.value)} required />
          </label>
          <label className="space-y-1.5">
            <span className="label">Start</span>
            <Input type="time" value={f.start} onChange={(e) => set('start', e.target.value)} required />
          </label>
          <label className="space-y-1.5">
            <span className="label">End</span>
            <Input type="time" value={f.end} onChange={(e) => set('end', e.target.value)} required />
          </label>
        </div>

        <Textarea value={f.notes} onChange={(e) => set('notes', e.target.value)} placeholder="Notes" className="min-h-[72px]" />

        {error && <p className="text-[13px] text-rose-300">{error}</p>}

        <div className="flex items-center justify-between gap-2 pt-1">
          <div>
            {editing && (
              <Button
                variant="danger"
                size="sm"
                onClick={() => {
                  deleteTask(editing.id);
                  toast('Deleted');
                  close();
                }}
              >
                <Trash2 className="h-4 w-4" /> Delete
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={close}>
              Cancel
            </Button>
            <Button variant="primary" type="submit">
              {editing ? 'Save changes' : 'Add'}
            </Button>
          </div>
        </div>
      </form>
    </Dialog>
  );
}
