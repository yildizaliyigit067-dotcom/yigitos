'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Maximize2, Minimize2, Pause, Play } from 'lucide-react';
import { focusElapsed, useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { CATEGORIES } from '@/lib/categories';
import { fmtDur } from '@/lib/date';
import { Button, Checkbox } from './ui';

const fmtClock = (ms: number) => {
  const total = Math.max(0, Math.ceil(ms / 1000));
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
};

function chime() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    [659.25, 987.77].forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      const t = ctx.currentTime + i * 0.18;
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.18, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + 1.3);
    });
  } catch {
    /* audio unavailable */
  }
}

export function FocusOverlay() {
  const a = useStore((s) => s.activeFocus);
  const pause = useStore((s) => s.pauseFocus);
  const resume = useStore((s) => s.resumeFocus);
  const complete = useStore((s) => s.completeFocus);
  const cancel = useStore((s) => s.cancelFocus);
  const minimized = useUI((s) => s.focusMinimized);
  const setMinimized = useUI((s) => s.setFocusMinimized);
  const toast = useUI((s) => s.toast);
  const [now, setNow] = useState(() => Date.now());
  const [markDone, setMarkDone] = useState(true);
  const fired = useRef(false);

  useEffect(() => {
    fired.current = false;
    setMarkDone(true);
  }, [a?.startedAt]);

  useEffect(() => {
    if (!a) return;
    const id = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(id);
  }, [a]);

  const finish = useCallback(
    (auto: boolean) => {
      const s = complete(markDone);
      if (s) toast(`${auto ? 'Session complete. ' : ''}${fmtDur(s.minutes)} of ${s.label} logged`);
      setMinimized(false);
    },
    [complete, markDone, toast, setMinimized],
  );

  const remaining = a ? a.plannedMinutes * 60000 - focusElapsed(a, now) : 0;

  useEffect(() => {
    if (a && remaining <= 0 && !fired.current) {
      fired.current = true;
      chime();
      finish(true);
    }
  }, [a, remaining, finish]);

  // Keep the screen awake during a session.
  useEffect(() => {
    if (!a || minimized || !('wakeLock' in navigator)) return;
    let lock: WakeLockSentinel | null = null;
    navigator.wakeLock.request('screen').then((l) => (lock = l)).catch(() => {});
    return () => {
      lock?.release().catch(() => {});
    };
  }, [a, minimized]);

  useEffect(() => {
    if (!a || minimized) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMinimized(true);
      if (e.key === ' ' && (e.target as HTMLElement).tagName !== 'BUTTON') {
        e.preventDefault();
        if (a.pausedAt) resume();
        else pause();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [a, minimized, pause, resume, setMinimized]);

  if (typeof document === 'undefined') return null;
  const color = a ? CATEGORIES[a.category].color : '#fff';
  const progress = a ? 1 - Math.max(0, remaining) / (a.plannedMinutes * 60000) : 0;
  const paused = !!a?.pausedAt;

  return createPortal(
    <AnimatePresence>
      {a && minimized && (
        <motion.button
          key="pill"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -20, opacity: 0 }}
          onClick={() => setMinimized(false)}
          className="fixed left-1/2 top-[calc(env(safe-area-inset-top)+12px)] z-[65] flex -translate-x-1/2 items-center gap-2.5 rounded-full border border-line-strong bg-[#141418]/90 py-1.5 pl-3 pr-2 text-[13px] shadow-xl backdrop-blur-xl"
        >
          <span className="h-2 w-2 rounded-full" style={{ background: color, opacity: paused ? 0.4 : 1 }} />
          <span className="font-medium text-muted">{a.label}</span>
          <span className="font-semibold tabular text-fg">{fmtClock(remaining)}</span>
          <Maximize2 className="h-3.5 w-3.5 text-faint" />
        </motion.button>
      )}
      {a && !minimized && (
        <motion.div
          key="full"
          className="fixed inset-0 z-[70] flex flex-col bg-[#08080A]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div
            className="pointer-events-none absolute inset-0"
            style={{ background: `radial-gradient(900px 500px at 50% 40%, ${color}14, transparent 70%)` }}
          />
          <div className="relative flex items-center justify-between px-5 pt-[calc(env(safe-area-inset-top)+16px)]">
            <span className="text-[13px] text-faint">{paused ? 'Paused' : 'Focus session'}</span>
            <button onClick={() => setMinimized(true)} className="rounded-lg p-2 text-faint hover:bg-white/5 hover:text-fg" aria-label="Minimize">
              <Minimize2 className="h-4 w-4" />
            </button>
          </div>

          <div className="relative flex flex-1 flex-col items-center justify-center px-6">
            <div className="flex items-center gap-2.5 text-[13px] font-semibold tracking-[0.28em] text-muted">
              <span className="h-2 w-2 rounded-full" style={{ background: color, boxShadow: `0 0 14px ${color}` }} />
              {a.label.toUpperCase()}
            </div>
            <motion.div
              className="mt-4 font-light tabular leading-none tracking-[-0.045em] text-fg"
              style={{ fontSize: 'clamp(84px, 22vw, 210px)' }}
              animate={{ opacity: paused ? 0.45 : 1 }}
            >
              {fmtClock(remaining)}
            </motion.div>
            <div className="mt-8 h-[3px] w-full max-w-[420px] overflow-hidden rounded-full bg-white/[0.06]">
              <div className="h-full rounded-full transition-[width] duration-300" style={{ width: `${progress * 100}%`, background: color }} />
            </div>
            <p className="mt-3 text-[13px] text-faint tabular">{a.plannedMinutes} min session</p>

            <div className="mt-12 flex items-center gap-3">
              <Button size="lg" onClick={paused ? resume : pause} className="min-w-[132px]">
                {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                {paused ? 'Resume' : 'Pause'}
              </Button>
              <Button size="lg" variant="primary" onClick={() => finish(false)} className="min-w-[180px]">
                Complete session
              </Button>
            </div>

            {a.taskId && (
              <label className="mt-6 flex cursor-pointer items-center gap-1 text-[13px] text-muted">
                <Checkbox checked={markDone} onChange={() => setMarkDone((v) => !v)} size={16} color={color} />
                Mark the task as done
              </label>
            )}
          </div>

          <div className="relative flex justify-center pb-[calc(env(safe-area-inset-bottom)+24px)]">
            <button
              onClick={() => {
                if (confirm('Discard this session? Nothing will be logged.')) cancel();
              }}
              className="text-[13px] text-faint hover:text-muted"
            >
              Discard session
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
