'use client';

import { useEffect, useMemo, useRef, useState, type ComponentType } from 'react';
import { createPortal } from 'react-dom';
import { useRouter } from 'next/navigation';
import { AnimatePresence, motion } from 'framer-motion';
import { CornerDownLeft, Play, Plus, RefreshCw, Search } from 'lucide-react';
import { syncClassroom } from '@/lib/classroom/sync';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { CATEGORIES, FOCUS_CATEGORIES } from '@/lib/categories';
import type { Category } from '@/lib/types';
import { cn } from '@/lib/utils';
import { NAV_BOTTOM, NAV_MAIN } from './nav';

interface Cmd {
  id: string;
  label: string;
  group: string;
  icon: ComponentType<{ className?: string }>;
  run: () => void;
}

const detectCategory = (s: string): Category | null => {
  if (/exam|test|quiz|sınav/.test(s)) return 'exam';
  if (/italian|italiano|ital/.test(s)) return 'italian';
  if (/research|sprint|experiment/.test(s)) return 'research';
  if (/itu|itü|cekirdek|çekirdek|intern/.test(s)) return 'itu';
  if (/event|meeting|party/.test(s)) return 'event';
  if (/school|math|physics|chem|bio|latin|history|philosophy|homework/.test(s)) return 'school';
  return null;
};

const titleCase = (s: string) => s.replace(/(^|\s)\S/g, (c) => c.toUpperCase());

export function CommandPalette() {
  const open = useUI((s) => s.palette);
  const setOpen = useUI((s) => s.setPalette);
  const openCreate = useUI((s) => s.openCreate);
  const startFocus = useStore((s) => s.startFocus);
  const router = useRouter();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ('');
      setSel(0);
    }
  }, [open]);

  const commands = useMemo<Cmd[]>(() => {
    const close = () => setOpen(false);
    const base: Cmd[] = [
      ...[...NAV_MAIN, ...NAV_BOTTOM].map((n) => ({
        id: `nav-${n.href}`,
        label: `Open ${n.label}`,
        group: 'Go to',
        icon: n.icon,
        run: () => {
          router.push(n.href);
          close();
        },
      })),
      {
        id: 'classroom-sync',
        label: 'Sync Google Classroom',
        group: 'Classroom',
        icon: RefreshCw,
        run: () => {
          close();
          syncClassroom(true)
            .then((r) => r && useUI.getState().toast(`${r.count} assignments synced`))
            .catch((e) => useUI.getState().toast(e?.message ?? 'Classroom sync failed'));
        },
      },
      ...FOCUS_CATEGORIES.map((c) => ({
        id: `focus-${c}`,
        label: `Start ${CATEGORIES[c].label} focus`,
        group: 'Focus',
        icon: Play,
        run: () => {
          startFocus({ category: c, label: CATEGORIES[c].label, minutes: 45 });
          close();
        },
      })),
      ...(['personal', 'exam', 'italian', 'research', 'itu', 'school', 'event'] as Category[]).map((c) => ({
        id: `add-${c}`,
        label: `Add ${c === 'personal' ? 'task' : CATEGORIES[c].label.toLowerCase()}`,
        group: 'Create',
        icon: Plus,
        run: () => openCreate({ category: c }),
      })),
    ];

    const s = q.trim().toLowerCase();
    if (!s) return base;

    const smart: Cmd[] = [];
    const add = s.match(/^(add|new|create|ekle|\+)\s+(.+)$/);
    if (add) {
      const rest = add[2];
      const category = detectCategory(rest) ?? 'personal';
      const title = titleCase(rest);
      smart.push({
        id: 'smart-add',
        label: `Add “${title}”`,
        group: CATEGORIES[category].label,
        icon: Plus,
        run: () => openCreate({ category, title }),
      });
    }
    const focus = s.match(/^(start|focus|begin)\s+(.+)$/);
    if (focus) {
      const c = detectCategory(focus[2]);
      const category: Category = c && c !== 'exam' && c !== 'event' ? c : 'personal';
      const mins = Number(focus[2].match(/(\d{2,3})/)?.[1]);
      const minutes = [20, 30, 45, 60, 90].includes(mins) ? mins : 45;
      smart.push({
        id: 'smart-focus',
        label: `Start ${CATEGORIES[category].label} focus · ${minutes} min`,
        group: 'Focus',
        icon: Play,
        run: () => {
          startFocus({ category, label: CATEGORIES[category].label, minutes });
          close();
        },
      });
    }
    const words = s.split(/\s+/);
    const matches = base.filter((c) => words.every((w) => c.label.toLowerCase().includes(w)));
    return [...smart, ...matches];
  }, [q, router, setOpen, openCreate, startFocus]);

  useEffect(() => setSel(0), [q]);

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSel((i) => Math.min(commands.length - 1, i + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSel((i) => Math.max(0, i - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      commands[sel]?.run();
    } else if (e.key === 'Escape') setOpen(false);
  };

  if (typeof document === 'undefined') return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[80] flex items-start justify-center px-3 pt-[12vh]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
          <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" onClick={() => setOpen(false)} />
          <motion.div
            className="relative w-full max-w-[580px] overflow-hidden rounded-2xl border border-line-strong bg-[#121215]/95 shadow-2xl backdrop-blur-2xl"
            initial={{ y: -8, scale: 0.98 }}
            animate={{ y: 0, scale: 1 }}
            exit={{ y: -8, scale: 0.98 }}
            transition={{ type: 'spring', bounce: 0.1, duration: 0.3 }}
          >
            <div className="flex items-center gap-3 border-b border-line px-4">
              <Search className="h-4 w-4 text-faint" />
              <input
                ref={inputRef}
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={onKey}
                placeholder="Type a command — “add physics exam”, “start italian 30”"
                className="h-14 flex-1 bg-transparent text-[15px] text-fg placeholder:text-faint focus:outline-none"
              />
            </div>
            <div className="max-h-[52vh] overflow-y-auto p-2">
              {commands.length === 0 && <p className="px-3 py-6 text-center text-[13px] text-muted">No matching command. Try starting with “add” or “start”.</p>}
              {commands.map((c, i) => {
                const Icon = c.icon;
                return (
                  <button
                    key={c.id}
                    onMouseEnter={() => setSel(i)}
                    onClick={c.run}
                    className={cn(
                      'flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[14px]',
                      i === sel ? 'bg-white/[0.07] text-fg' : 'text-muted',
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0 text-faint" />
                    <span className="flex-1 truncate">{c.label}</span>
                    <span className="text-[11.5px] text-faint">{c.group}</span>
                    {i === sel && <CornerDownLeft className="h-3.5 w-3.5 text-faint" />}
                  </button>
                );
              })}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
