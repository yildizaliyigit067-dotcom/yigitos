'use client';

import Link from 'next/link';
import { format, parseISO, subDays } from 'date-fns';
import { CalendarPlus, ClipboardList, ExternalLink } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useUI } from '@/lib/ui-store';
import { dueLabel, isDone, isOverdue, statusOf, subjectOf, visibleAssignments } from '@/lib/classroom/helpers';
import { fromMin, nowMin, todayKey } from '@/lib/date';
import type { ClassroomAssignment } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Button, Card, CardHeader, Checkbox } from './ui';

export function usePlanAssignment() {
  const openCreate = useUI((s) => s.openCreate);
  return (a: ClassroomAssignment) => {
    const today = todayKey();
    let date = today;
    if (a.due) {
      const dayBefore = format(subDays(parseISO(a.due), 1), 'yyyy-MM-dd');
      date = dayBefore > today ? dayBefore : today;
    }
    // Today: after school (16:00) or the next half hour, whichever is later.
    const start = date === today ? fromMin(Math.min(21 * 60, Math.max(16 * 60, Math.ceil((nowMin() + 10) / 30) * 30))) : '17:00';
    openCreate({
      title: `${a.courseName}: ${a.title}`,
      category: 'school',
      date,
      start,
      notes: a.link,
      assignmentId: a.id,
    });
  };
}

export function AssignmentRow({ a, compact = false }: { a: ClassroomAssignment; compact?: boolean }) {
  const classroom = useStore((s) => s.classroom);
  const tasks = useStore((s) => s.tasks);
  const toggle = useStore((s) => s.toggleAssignmentDone);
  const plan = usePlanAssignment();
  const status = statusOf(a);
  const done = isDone(a);
  const turnedIn = a.state === 'TURNED_IN' || a.state === 'RETURNED';
  const overdue = isOverdue(a);
  const subject = subjectOf(a, classroom);
  const planned = tasks.find((t) => t.assignmentId === a.id && !t.done);

  return (
    <li className="group flex items-center gap-2 rounded-xl px-1.5 py-2 transition-colors hover:bg-white/[0.025] sm:gap-3 sm:px-2">
      <Checkbox
        checked={done}
        onChange={() => !turnedIn && toggle(a.id)}
        color={turnedIn ? '#3FCF8E' : 'var(--accent)'}
        size={18}
        label={turnedIn ? 'Turned in on Classroom' : `Mark ${a.title} done`}
      />
      <div className="min-w-0 flex-1">
        <a
          href={a.link}
          target="_blank"
          rel="noreferrer"
          className={cn('block truncate text-[14px] font-medium hover:underline decoration-white/30', done && 'text-faint line-through decoration-white/20')}
        >
          {a.title}
        </a>
        <div className="mt-0.5 truncate text-[12px] text-faint">
          {a.courseName}
          {subject && !compact && subject !== a.courseName && <span className="hidden sm:inline"> · {subject}</span>}
          {planned && !compact && <span className="text-accent"> · Planned {format(parseISO(planned.date), 'EEE')} {planned.start}</span>}
        </div>
      </div>
      <div className="flex max-w-[42%] shrink-0 flex-col items-end gap-0.5 text-right">
        <span className={cn('text-[12.5px] font-medium tabular', overdue ? 'text-rose-300' : done ? 'text-faint' : 'text-fg')}>{dueLabel(a.due)}</span>
        {!compact && (
          <span className="flex items-center gap-1.5 whitespace-nowrap text-[11.5px] text-muted">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: status.color }} />
            {status.label}
          </span>
        )}
      </div>
      {!compact && (
        <div className="flex shrink-0 gap-0.5">
          {!done && (
            <Button size="icon-sm" variant="ghost" onClick={() => plan(a)} aria-label="Plan a study block" title="Plan a study block">
              <CalendarPlus className="h-3.5 w-3.5" />
            </Button>
          )}
          <a
            href={a.link}
            target="_blank"
            rel="noreferrer"
            className="hidden h-7 w-7 place-items-center rounded-lg sm:grid text-muted hover:bg-white/[0.05] hover:text-fg"
            aria-label="Open in Classroom"
            title="Open in Classroom"
          >
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
      )}
    </li>
  );
}

/** Small card for Overview / Today. Renders nothing until Classroom is connected. */
export function DueSoonCard({ dateKey, title = 'Classroom · due soon' }: { dateKey?: string; title?: string }) {
  const classroom = useStore((s) => s.classroom);
  if (!classroom.connected) return null;
  const now = new Date();
  const horizon = format(new Date(now.getTime() + 7 * 86400000), "yyyy-MM-dd'T'23:59");
  const list = visibleAssignments(classroom)
    .filter((a) => !isDone(a) && a.due)
    .filter((a) => (dateKey ? a.due!.slice(0, 10) === dateKey || (dateKey === todayKey() && isOverdue(a, now)) : a.due! <= horizon))
    .sort((a, b) => a.due!.localeCompare(b.due!))
    .slice(0, 5);
  const overdue = list.filter((a) => isOverdue(a, now)).length;

  return (
    <Card className="p-4">
      <CardHeader
        className="mb-2 px-1"
        title={title}
        icon={ClipboardList}
        action={
          <Link href="/classroom" className="text-[12.5px] text-faint hover:text-muted">
            {overdue ? <span className="text-rose-300">{overdue} missing</span> : 'All'}
          </Link>
        }
      />
      {list.length ? (
        <ul className="space-y-0.5">
          {list.map((a) => (
            <AssignmentRow key={a.id} a={a} compact />
          ))}
        </ul>
      ) : (
        <p className="px-1 pb-1 text-[13px] text-muted">{dateKey ? 'Nothing due this day.' : 'Nothing due in the next 7 days.'}</p>
      )}
    </Card>
  );
}
