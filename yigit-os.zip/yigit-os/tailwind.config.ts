import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: { DEFAULT: '#0A0A0B', raised: '#0E0E10', card: '#121215', hover: '#18181C' },
        line: { DEFAULT: 'rgba(255,255,255,0.07)', strong: 'rgba(255,255,255,0.13)' },
        fg: '#EDEDEF',
        muted: '#8B8B95',
        faint: '#5C5C66',
        accent: { DEFAULT: '#5B7CFF', hover: '#6E8BFF', soft: 'rgba(91,124,255,0.14)' },
      },
      fontFamily: {
        sans: ['var(--font-geist-sans)', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['var(--font-geist-mono)', 'ui-monospace', 'monospace'],
      },
      borderRadius: { xl: '12px', '2xl': '16px', '3xl': '20px' },
      keyframes: {
        shimmer: { '0%': { opacity: '0.4' }, '50%': { opacity: '1' }, '100%': { opacity: '0.4' } },
      },
      animation: { shimmer: 'shimmer 1.6s ease-in-out infinite' },
    },
  },
  plugins: [],
};
export default config;
